#ifndef __included_mpls_api_json
#define __included_mpls_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_mpls_table_add_del;
extern vapi_msg_id_t vapi_msg_id_mpls_fib_dump;
extern vapi_msg_id_t vapi_msg_id_mpls_route_add_del;
extern vapi_msg_id_t vapi_msg_id_mpls_ip_bind_unbind_reply;
extern vapi_msg_id_t vapi_msg_id_mpls_ip_bind_unbind;
extern vapi_msg_id_t vapi_msg_id_mpls_tunnel_add_del;
extern vapi_msg_id_t vapi_msg_id_mpls_fib_details;
extern vapi_msg_id_t vapi_msg_id_mpls_tunnel_dump;
extern vapi_msg_id_t vapi_msg_id_mpls_table_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_mpls_tunnel_details;
extern vapi_msg_id_t vapi_msg_id_mpls_route_add_del_reply;
extern vapi_msg_id_t vapi_msg_id_mpls_tunnel_add_del_reply;

#define DEFINE_VAPI_MSG_IDS_MPLS_API_JSON\
  vapi_msg_id_t vapi_msg_id_mpls_table_add_del;\
  vapi_msg_id_t vapi_msg_id_mpls_fib_dump;\
  vapi_msg_id_t vapi_msg_id_mpls_route_add_del;\
  vapi_msg_id_t vapi_msg_id_mpls_ip_bind_unbind_reply;\
  vapi_msg_id_t vapi_msg_id_mpls_ip_bind_unbind;\
  vapi_msg_id_t vapi_msg_id_mpls_tunnel_add_del;\
  vapi_msg_id_t vapi_msg_id_mpls_fib_details;\
  vapi_msg_id_t vapi_msg_id_mpls_tunnel_dump;\
  vapi_msg_id_t vapi_msg_id_mpls_table_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_mpls_tunnel_details;\
  vapi_msg_id_t vapi_msg_id_mpls_route_add_del_reply;\
  vapi_msg_id_t vapi_msg_id_mpls_tunnel_add_del_reply;


typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u8 weight;
  u8 preference;
  u8 is_local;
  u8 is_drop;
  u8 is_unreach;
  u8 is_prohibit;
  u8 afi;
  u8 next_hop[16];
  u32 labels[16];
} vapi_type_fib_path2;

typedef struct __attribute__ ((__packed__)) {
  u32 mt_table_id;
  u8 mt_is_add;
  u8 mt_name[64]; 
} vapi_payload_mpls_table_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mpls_table_add_del payload;
} vapi_msg_mpls_table_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_mpls_fib_dump;

typedef struct __attribute__ ((__packed__)) {
  u32 mr_label;
  u8 mr_eos;
  u32 mr_table_id;
  u32 mr_classify_table_index;
  u8 mr_create_table_if_needed;
  u8 mr_is_add;
  u8 mr_is_classify;
  u8 mr_is_multicast;
  u8 mr_is_multipath;
  u8 mr_is_resolve_host;
  u8 mr_is_resolve_attached;
  u8 mr_is_interface_rx;
  u8 mr_is_rpf_id;
  u8 mr_next_hop_proto;
  u8 mr_next_hop_weight;
  u8 mr_next_hop_preference;
  u8 mr_next_hop[16];
  u8 mr_next_hop_n_out_labels;
  u32 mr_next_hop_sw_if_index;
  u32 mr_next_hop_table_id;
  u32 mr_next_hop_via_label;
  u32 mr_next_hop_out_label_stack[0]; 
} vapi_payload_mpls_route_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mpls_route_add_del payload;
} vapi_msg_mpls_route_add_del;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_mpls_ip_bind_unbind_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_ip_bind_unbind_reply payload;
} vapi_msg_mpls_ip_bind_unbind_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 mb_mpls_table_id;
  u32 mb_label;
  u32 mb_ip_table_id;
  u8 mb_create_table_if_needed;
  u8 mb_is_bind;
  u8 mb_is_ip4;
  u8 mb_address_length;
  u8 mb_address[16]; 
} vapi_payload_mpls_ip_bind_unbind;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mpls_ip_bind_unbind payload;
} vapi_msg_mpls_ip_bind_unbind;

typedef struct __attribute__ ((__packed__)) {
  u32 mt_sw_if_index;
  u8 mt_is_add;
  u8 mt_l2_only;
  u8 mt_is_multicast;
  u8 mt_next_hop_proto_is_ip4;
  u8 mt_next_hop_weight;
  u8 mt_next_hop_preference;
  u8 mt_next_hop[16];
  u8 mt_next_hop_n_out_labels;
  u32 mt_next_hop_sw_if_index;
  u32 mt_next_hop_table_id;
  u32 mt_next_hop_out_label_stack[0]; 
} vapi_payload_mpls_tunnel_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mpls_tunnel_add_del payload;
} vapi_msg_mpls_tunnel_add_del;

typedef struct __attribute__ ((__packed__)) {
  u32 table_id;
  u8 table_name[64];
  u8 eos_bit;
  u32 label;
  u32 count;
  vapi_type_fib_path2 path[0]; 
} vapi_payload_mpls_fib_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_fib_details payload;
} vapi_msg_mpls_fib_details;

typedef struct __attribute__ ((__packed__)) {
  i32 tunnel_index; 
} vapi_payload_mpls_tunnel_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_mpls_tunnel_dump payload;
} vapi_msg_mpls_tunnel_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_mpls_table_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_table_add_del_reply payload;
} vapi_msg_mpls_table_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 mt_sw_if_index;
  u8 mt_tunnel_index;
  u8 mt_l2_only;
  u8 mt_is_multicast;
  u32 mt_count;
  vapi_type_fib_path2 mt_paths[0]; 
} vapi_payload_mpls_tunnel_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_tunnel_details payload;
} vapi_msg_mpls_tunnel_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_mpls_route_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_route_add_del_reply payload;
} vapi_msg_mpls_route_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_mpls_tunnel_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_mpls_tunnel_add_del_reply payload;
} vapi_msg_mpls_tunnel_add_del_reply;


static inline void vapi_type_fib_path2_hton(vapi_type_fib_path2 *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
  do { unsigned i; for (i = 0; i < 16; ++i) { msg->labels[i] = htobe32(msg->labels[i]); } } while(0);
}

static inline void vapi_type_fib_path2_ntoh(vapi_type_fib_path2 *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
  do { unsigned i; for (i = 0; i < 16; ++i) { msg->labels[i] = be32toh(msg->labels[i]); } } while(0);
}

static inline void vapi_msg_mpls_table_add_del_payload_hton(vapi_payload_mpls_table_add_del *payload)
{
  payload->mt_table_id = htobe32(payload->mt_table_id);
}

static inline void vapi_msg_mpls_table_add_del_payload_ntoh(vapi_payload_mpls_table_add_del *payload)
{
  payload->mt_table_id = be32toh(payload->mt_table_id);
}

static inline uword vapi_calc_mpls_table_add_del_msg_size(vapi_msg_mpls_table_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_table_add_del_hton(vapi_msg_mpls_table_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_table_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mpls_table_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_table_add_del_ntoh(vapi_msg_mpls_table_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_table_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mpls_table_add_del_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_mpls_fib_dump_msg_size(vapi_msg_mpls_fib_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_fib_dump_hton(vapi_msg_mpls_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_fib_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_mpls_fib_dump_ntoh(vapi_msg_mpls_fib_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_fib_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_mpls_route_add_del_payload_hton(vapi_payload_mpls_route_add_del *payload)
{
  payload->mr_label = htobe32(payload->mr_label);
  payload->mr_table_id = htobe32(payload->mr_table_id);
  payload->mr_classify_table_index = htobe32(payload->mr_classify_table_index);
  payload->mr_next_hop_sw_if_index = htobe32(payload->mr_next_hop_sw_if_index);
  payload->mr_next_hop_table_id = htobe32(payload->mr_next_hop_table_id);
  payload->mr_next_hop_via_label = htobe32(payload->mr_next_hop_via_label);
  do { unsigned i; for (i = 0; i < payload->mr_next_hop_n_out_labels; ++i) { payload->mr_next_hop_out_label_stack[i] = htobe32(payload->mr_next_hop_out_label_stack[i]); } } while(0);
}

static inline void vapi_msg_mpls_route_add_del_payload_ntoh(vapi_payload_mpls_route_add_del *payload)
{
  payload->mr_label = be32toh(payload->mr_label);
  payload->mr_table_id = be32toh(payload->mr_table_id);
  payload->mr_classify_table_index = be32toh(payload->mr_classify_table_index);
  payload->mr_next_hop_sw_if_index = be32toh(payload->mr_next_hop_sw_if_index);
  payload->mr_next_hop_table_id = be32toh(payload->mr_next_hop_table_id);
  payload->mr_next_hop_via_label = be32toh(payload->mr_next_hop_via_label);
  do { unsigned i; for (i = 0; i < payload->mr_next_hop_n_out_labels; ++i) { payload->mr_next_hop_out_label_stack[i] = be32toh(payload->mr_next_hop_out_label_stack[i]); } } while(0);
}

static inline uword vapi_calc_mpls_route_add_del_msg_size(vapi_msg_mpls_route_add_del *msg)
{
  return sizeof(*msg)+ msg->payload.mr_next_hop_n_out_labels * sizeof(msg->payload.mr_next_hop_out_label_stack[0]);
}

static inline void vapi_msg_mpls_route_add_del_hton(vapi_msg_mpls_route_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_route_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mpls_route_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_route_add_del_ntoh(vapi_msg_mpls_route_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_route_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mpls_route_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_ip_bind_unbind_reply_payload_hton(vapi_payload_mpls_ip_bind_unbind_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_mpls_ip_bind_unbind_reply_payload_ntoh(vapi_payload_mpls_ip_bind_unbind_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_mpls_ip_bind_unbind_reply_msg_size(vapi_msg_mpls_ip_bind_unbind_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_ip_bind_unbind_reply_hton(vapi_msg_mpls_ip_bind_unbind_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_ip_bind_unbind_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_ip_bind_unbind_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_ip_bind_unbind_reply_ntoh(vapi_msg_mpls_ip_bind_unbind_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_ip_bind_unbind_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_ip_bind_unbind_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_ip_bind_unbind_payload_hton(vapi_payload_mpls_ip_bind_unbind *payload)
{
  payload->mb_mpls_table_id = htobe32(payload->mb_mpls_table_id);
  payload->mb_label = htobe32(payload->mb_label);
  payload->mb_ip_table_id = htobe32(payload->mb_ip_table_id);
}

static inline void vapi_msg_mpls_ip_bind_unbind_payload_ntoh(vapi_payload_mpls_ip_bind_unbind *payload)
{
  payload->mb_mpls_table_id = be32toh(payload->mb_mpls_table_id);
  payload->mb_label = be32toh(payload->mb_label);
  payload->mb_ip_table_id = be32toh(payload->mb_ip_table_id);
}

static inline uword vapi_calc_mpls_ip_bind_unbind_msg_size(vapi_msg_mpls_ip_bind_unbind *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_ip_bind_unbind_hton(vapi_msg_mpls_ip_bind_unbind *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_ip_bind_unbind'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mpls_ip_bind_unbind_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_ip_bind_unbind_ntoh(vapi_msg_mpls_ip_bind_unbind *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_ip_bind_unbind'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mpls_ip_bind_unbind_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_add_del_payload_hton(vapi_payload_mpls_tunnel_add_del *payload)
{
  payload->mt_sw_if_index = htobe32(payload->mt_sw_if_index);
  payload->mt_next_hop_sw_if_index = htobe32(payload->mt_next_hop_sw_if_index);
  payload->mt_next_hop_table_id = htobe32(payload->mt_next_hop_table_id);
  do { unsigned i; for (i = 0; i < payload->mt_next_hop_n_out_labels; ++i) { payload->mt_next_hop_out_label_stack[i] = htobe32(payload->mt_next_hop_out_label_stack[i]); } } while(0);
}

static inline void vapi_msg_mpls_tunnel_add_del_payload_ntoh(vapi_payload_mpls_tunnel_add_del *payload)
{
  payload->mt_sw_if_index = be32toh(payload->mt_sw_if_index);
  payload->mt_next_hop_sw_if_index = be32toh(payload->mt_next_hop_sw_if_index);
  payload->mt_next_hop_table_id = be32toh(payload->mt_next_hop_table_id);
  do { unsigned i; for (i = 0; i < payload->mt_next_hop_n_out_labels; ++i) { payload->mt_next_hop_out_label_stack[i] = be32toh(payload->mt_next_hop_out_label_stack[i]); } } while(0);
}

static inline uword vapi_calc_mpls_tunnel_add_del_msg_size(vapi_msg_mpls_tunnel_add_del *msg)
{
  return sizeof(*msg)+ msg->payload.mt_next_hop_n_out_labels * sizeof(msg->payload.mt_next_hop_out_label_stack[0]);
}

static inline void vapi_msg_mpls_tunnel_add_del_hton(vapi_msg_mpls_tunnel_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mpls_tunnel_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_add_del_ntoh(vapi_msg_mpls_tunnel_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mpls_tunnel_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_fib_details_payload_hton(vapi_payload_mpls_fib_details *payload)
{
  payload->table_id = htobe32(payload->table_id);
  payload->label = htobe32(payload->label);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_fib_path2_hton(&payload->path[i]); } } while(0);
}

static inline void vapi_msg_mpls_fib_details_payload_ntoh(vapi_payload_mpls_fib_details *payload)
{
  payload->table_id = be32toh(payload->table_id);
  payload->label = be32toh(payload->label);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_fib_path2_ntoh(&payload->path[i]); } } while(0);
}

static inline uword vapi_calc_mpls_fib_details_msg_size(vapi_msg_mpls_fib_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.path[0]);
}

static inline void vapi_msg_mpls_fib_details_hton(vapi_msg_mpls_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_fib_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_fib_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_fib_details_ntoh(vapi_msg_mpls_fib_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_fib_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_fib_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_dump_payload_hton(vapi_payload_mpls_tunnel_dump *payload)
{
  payload->tunnel_index = htobe32(payload->tunnel_index);
}

static inline void vapi_msg_mpls_tunnel_dump_payload_ntoh(vapi_payload_mpls_tunnel_dump *payload)
{
  payload->tunnel_index = be32toh(payload->tunnel_index);
}

static inline uword vapi_calc_mpls_tunnel_dump_msg_size(vapi_msg_mpls_tunnel_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_tunnel_dump_hton(vapi_msg_mpls_tunnel_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_mpls_tunnel_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_dump_ntoh(vapi_msg_mpls_tunnel_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_mpls_tunnel_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_table_add_del_reply_payload_hton(vapi_payload_mpls_table_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_mpls_table_add_del_reply_payload_ntoh(vapi_payload_mpls_table_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_mpls_table_add_del_reply_msg_size(vapi_msg_mpls_table_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_table_add_del_reply_hton(vapi_msg_mpls_table_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_table_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_table_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_table_add_del_reply_ntoh(vapi_msg_mpls_table_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_table_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_table_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_details_payload_hton(vapi_payload_mpls_tunnel_details *payload)
{
  payload->mt_count = htobe32(payload->mt_count);
  do { unsigned i; for (i = 0; i < be32toh(payload->mt_count); ++i) { vapi_type_fib_path2_hton(&payload->mt_paths[i]); } } while(0);
}

static inline void vapi_msg_mpls_tunnel_details_payload_ntoh(vapi_payload_mpls_tunnel_details *payload)
{
  payload->mt_count = be32toh(payload->mt_count);
  do { unsigned i; for (i = 0; i < payload->mt_count; ++i) { vapi_type_fib_path2_ntoh(&payload->mt_paths[i]); } } while(0);
}

static inline uword vapi_calc_mpls_tunnel_details_msg_size(vapi_msg_mpls_tunnel_details *msg)
{
  return sizeof(*msg)+ msg->payload.mt_count * sizeof(msg->payload.mt_paths[0]);
}

static inline void vapi_msg_mpls_tunnel_details_hton(vapi_msg_mpls_tunnel_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_tunnel_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_details_ntoh(vapi_msg_mpls_tunnel_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_tunnel_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_route_add_del_reply_payload_hton(vapi_payload_mpls_route_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_mpls_route_add_del_reply_payload_ntoh(vapi_payload_mpls_route_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_mpls_route_add_del_reply_msg_size(vapi_msg_mpls_route_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_route_add_del_reply_hton(vapi_msg_mpls_route_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_route_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_route_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_route_add_del_reply_ntoh(vapi_msg_mpls_route_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_route_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_route_add_del_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_add_del_reply_payload_hton(vapi_payload_mpls_tunnel_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_mpls_tunnel_add_del_reply_payload_ntoh(vapi_payload_mpls_tunnel_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_mpls_tunnel_add_del_reply_msg_size(vapi_msg_mpls_tunnel_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_mpls_tunnel_add_del_reply_hton(vapi_msg_mpls_tunnel_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_mpls_tunnel_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_mpls_tunnel_add_del_reply_ntoh(vapi_msg_mpls_tunnel_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_mpls_tunnel_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_mpls_tunnel_add_del_reply_payload_ntoh(&msg->payload);
}

static inline vapi_msg_mpls_table_add_del* vapi_alloc_mpls_table_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_mpls_table_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_table_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_table_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_table_add_del);

  return msg;
}

static inline vapi_error_e vapi_mpls_table_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_table_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_table_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_table_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_table_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mpls_fib_dump* vapi_alloc_mpls_fib_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_mpls_fib_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_fib_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_fib_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_fib_dump);

  return msg;
}

static inline vapi_error_e vapi_mpls_fib_dump(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_fib_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_fib_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_fib_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_fib_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mpls_route_add_del* vapi_alloc_mpls_route_add_del(struct vapi_ctx_s *ctx, size_t mr_next_hop_out_label_stack_array_size)
{
  vapi_msg_mpls_route_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_route_add_del) + sizeof(msg->payload.mr_next_hop_out_label_stack[0]) * mr_next_hop_out_label_stack_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_route_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_route_add_del);
  msg->payload.mr_next_hop_n_out_labels = mr_next_hop_out_label_stack_array_size;
  return msg;
}

static inline vapi_error_e vapi_mpls_route_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_route_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_route_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_route_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_route_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mpls_ip_bind_unbind* vapi_alloc_mpls_ip_bind_unbind(struct vapi_ctx_s *ctx)
{
  vapi_msg_mpls_ip_bind_unbind *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_ip_bind_unbind);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_ip_bind_unbind*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_ip_bind_unbind);

  return msg;
}

static inline vapi_error_e vapi_mpls_ip_bind_unbind(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_ip_bind_unbind *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_ip_bind_unbind_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_ip_bind_unbind_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_ip_bind_unbind_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mpls_tunnel_add_del* vapi_alloc_mpls_tunnel_add_del(struct vapi_ctx_s *ctx, size_t mt_next_hop_out_label_stack_array_size)
{
  vapi_msg_mpls_tunnel_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_tunnel_add_del) + sizeof(msg->payload.mt_next_hop_out_label_stack[0]) * mt_next_hop_out_label_stack_array_size;
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_tunnel_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_tunnel_add_del);
  msg->payload.mt_next_hop_n_out_labels = mt_next_hop_out_label_stack_array_size;
  return msg;
}

static inline vapi_error_e vapi_mpls_tunnel_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_tunnel_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_tunnel_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_tunnel_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_tunnel_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_mpls_tunnel_dump* vapi_alloc_mpls_tunnel_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_mpls_tunnel_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_mpls_tunnel_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_mpls_tunnel_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_mpls_tunnel_dump);

  return msg;
}

static inline vapi_error_e vapi_mpls_tunnel_dump(struct vapi_ctx_s *ctx,
  vapi_msg_mpls_tunnel_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_mpls_tunnel_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_mpls_tunnel_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_mpls_tunnel_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_mpls_table_add_del()
{
  static const char name[] = "mpls_table_add_del";
  static const char name_with_crc[] = "mpls_table_add_del_943bd589";
  static vapi_message_desc_t __vapi_metadata_mpls_table_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mpls_table_add_del, payload),
    sizeof(vapi_msg_mpls_table_add_del),
    (generic_swap_fn_t)vapi_msg_mpls_table_add_del_hton,
    (generic_swap_fn_t)vapi_msg_mpls_table_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_table_add_del = vapi_register_msg(&__vapi_metadata_mpls_table_add_del);
  VAPI_DBG("Assigned msg id %d to mpls_table_add_del", vapi_msg_id_mpls_table_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_fib_dump()
{
  static const char name[] = "mpls_fib_dump";
  static const char name_with_crc[] = "mpls_fib_dump_7e82659e";
  static vapi_message_desc_t __vapi_metadata_mpls_fib_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_mpls_fib_dump),
    (generic_swap_fn_t)vapi_msg_mpls_fib_dump_hton,
    (generic_swap_fn_t)vapi_msg_mpls_fib_dump_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_fib_dump = vapi_register_msg(&__vapi_metadata_mpls_fib_dump);
  VAPI_DBG("Assigned msg id %d to mpls_fib_dump", vapi_msg_id_mpls_fib_dump);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_route_add_del()
{
  static const char name[] = "mpls_route_add_del";
  static const char name_with_crc[] = "mpls_route_add_del_d509645a";
  static vapi_message_desc_t __vapi_metadata_mpls_route_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mpls_route_add_del, payload),
    sizeof(vapi_msg_mpls_route_add_del),
    (generic_swap_fn_t)vapi_msg_mpls_route_add_del_hton,
    (generic_swap_fn_t)vapi_msg_mpls_route_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_route_add_del = vapi_register_msg(&__vapi_metadata_mpls_route_add_del);
  VAPI_DBG("Assigned msg id %d to mpls_route_add_del", vapi_msg_id_mpls_route_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_ip_bind_unbind_reply()
{
  static const char name[] = "mpls_ip_bind_unbind_reply";
  static const char name_with_crc[] = "mpls_ip_bind_unbind_reply_5753d1ed";
  static vapi_message_desc_t __vapi_metadata_mpls_ip_bind_unbind_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_ip_bind_unbind_reply, payload),
    sizeof(vapi_msg_mpls_ip_bind_unbind_reply),
    (generic_swap_fn_t)vapi_msg_mpls_ip_bind_unbind_reply_hton,
    (generic_swap_fn_t)vapi_msg_mpls_ip_bind_unbind_reply_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_ip_bind_unbind_reply = vapi_register_msg(&__vapi_metadata_mpls_ip_bind_unbind_reply);
  VAPI_DBG("Assigned msg id %d to mpls_ip_bind_unbind_reply", vapi_msg_id_mpls_ip_bind_unbind_reply);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_ip_bind_unbind()
{
  static const char name[] = "mpls_ip_bind_unbind";
  static const char name_with_crc[] = "mpls_ip_bind_unbind_167f24bd";
  static vapi_message_desc_t __vapi_metadata_mpls_ip_bind_unbind = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mpls_ip_bind_unbind, payload),
    sizeof(vapi_msg_mpls_ip_bind_unbind),
    (generic_swap_fn_t)vapi_msg_mpls_ip_bind_unbind_hton,
    (generic_swap_fn_t)vapi_msg_mpls_ip_bind_unbind_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_ip_bind_unbind = vapi_register_msg(&__vapi_metadata_mpls_ip_bind_unbind);
  VAPI_DBG("Assigned msg id %d to mpls_ip_bind_unbind", vapi_msg_id_mpls_ip_bind_unbind);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_tunnel_add_del()
{
  static const char name[] = "mpls_tunnel_add_del";
  static const char name_with_crc[] = "mpls_tunnel_add_del_afb8f594";
  static vapi_message_desc_t __vapi_metadata_mpls_tunnel_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mpls_tunnel_add_del, payload),
    sizeof(vapi_msg_mpls_tunnel_add_del),
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_add_del_hton,
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_tunnel_add_del = vapi_register_msg(&__vapi_metadata_mpls_tunnel_add_del);
  VAPI_DBG("Assigned msg id %d to mpls_tunnel_add_del", vapi_msg_id_mpls_tunnel_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_fib_details()
{
  static const char name[] = "mpls_fib_details";
  static const char name_with_crc[] = "mpls_fib_details_2a1ab162";
  static vapi_message_desc_t __vapi_metadata_mpls_fib_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_fib_details, payload),
    sizeof(vapi_msg_mpls_fib_details),
    (generic_swap_fn_t)vapi_msg_mpls_fib_details_hton,
    (generic_swap_fn_t)vapi_msg_mpls_fib_details_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_fib_details = vapi_register_msg(&__vapi_metadata_mpls_fib_details);
  VAPI_DBG("Assigned msg id %d to mpls_fib_details", vapi_msg_id_mpls_fib_details);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_tunnel_dump()
{
  static const char name[] = "mpls_tunnel_dump";
  static const char name_with_crc[] = "mpls_tunnel_dump_be9ada9c";
  static vapi_message_desc_t __vapi_metadata_mpls_tunnel_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_mpls_tunnel_dump, payload),
    sizeof(vapi_msg_mpls_tunnel_dump),
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_dump_hton,
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_dump_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_tunnel_dump = vapi_register_msg(&__vapi_metadata_mpls_tunnel_dump);
  VAPI_DBG("Assigned msg id %d to mpls_tunnel_dump", vapi_msg_id_mpls_tunnel_dump);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_table_add_del_reply()
{
  static const char name[] = "mpls_table_add_del_reply";
  static const char name_with_crc[] = "mpls_table_add_del_reply_e1e78638";
  static vapi_message_desc_t __vapi_metadata_mpls_table_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_table_add_del_reply, payload),
    sizeof(vapi_msg_mpls_table_add_del_reply),
    (generic_swap_fn_t)vapi_msg_mpls_table_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_mpls_table_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_table_add_del_reply = vapi_register_msg(&__vapi_metadata_mpls_table_add_del_reply);
  VAPI_DBG("Assigned msg id %d to mpls_table_add_del_reply", vapi_msg_id_mpls_table_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_tunnel_details()
{
  static const char name[] = "mpls_tunnel_details";
  static const char name_with_crc[] = "mpls_tunnel_details_f43de2ca";
  static vapi_message_desc_t __vapi_metadata_mpls_tunnel_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_tunnel_details, payload),
    sizeof(vapi_msg_mpls_tunnel_details),
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_details_hton,
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_details_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_tunnel_details = vapi_register_msg(&__vapi_metadata_mpls_tunnel_details);
  VAPI_DBG("Assigned msg id %d to mpls_tunnel_details", vapi_msg_id_mpls_tunnel_details);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_route_add_del_reply()
{
  static const char name[] = "mpls_route_add_del_reply";
  static const char name_with_crc[] = "mpls_route_add_del_reply_21a12fe9";
  static vapi_message_desc_t __vapi_metadata_mpls_route_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_route_add_del_reply, payload),
    sizeof(vapi_msg_mpls_route_add_del_reply),
    (generic_swap_fn_t)vapi_msg_mpls_route_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_mpls_route_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_route_add_del_reply = vapi_register_msg(&__vapi_metadata_mpls_route_add_del_reply);
  VAPI_DBG("Assigned msg id %d to mpls_route_add_del_reply", vapi_msg_id_mpls_route_add_del_reply);
}

static void __attribute__((constructor)) __vapi_constructor_mpls_tunnel_add_del_reply()
{
  static const char name[] = "mpls_tunnel_add_del_reply";
  static const char name_with_crc[] = "mpls_tunnel_add_del_reply_bb483273";
  static vapi_message_desc_t __vapi_metadata_mpls_tunnel_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_mpls_tunnel_add_del_reply, payload),
    sizeof(vapi_msg_mpls_tunnel_add_del_reply),
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_mpls_tunnel_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_mpls_tunnel_add_del_reply = vapi_register_msg(&__vapi_metadata_mpls_tunnel_add_del_reply);
  VAPI_DBG("Assigned msg id %d to mpls_tunnel_add_del_reply", vapi_msg_id_mpls_tunnel_add_del_reply);
}


static inline void vapi_set_vapi_msg_mpls_ip_bind_unbind_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_ip_bind_unbind_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_ip_bind_unbind_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mpls_fib_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_fib_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_fib_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mpls_table_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_table_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_table_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mpls_tunnel_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_tunnel_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_tunnel_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mpls_route_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_route_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_route_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_mpls_tunnel_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_mpls_tunnel_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_mpls_tunnel_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
