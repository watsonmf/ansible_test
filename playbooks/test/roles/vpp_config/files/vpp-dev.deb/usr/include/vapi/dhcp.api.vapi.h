#ifndef __included_dhcp_api_json
#define __included_dhcp_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_dhcp_client_config_reply;
extern vapi_msg_id_t vapi_msg_id_dhcp_compl_event;
extern vapi_msg_id_t vapi_msg_id_dhcp_client_config;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_set_vss_reply;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_dump;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_config_reply;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_details;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_config;
extern vapi_msg_id_t vapi_msg_id_dhcp_proxy_set_vss;

#define DEFINE_VAPI_MSG_IDS_DHCP_API_JSON\
  vapi_msg_id_t vapi_msg_id_dhcp_client_config_reply;\
  vapi_msg_id_t vapi_msg_id_dhcp_compl_event;\
  vapi_msg_id_t vapi_msg_id_dhcp_client_config;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_set_vss_reply;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_dump;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_config_reply;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_details;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_config;\
  vapi_msg_id_t vapi_msg_id_dhcp_proxy_set_vss;


typedef struct __attribute__((__packed__)) {
  u32 server_vrf_id;
  u8 dhcp_server[16];
} vapi_type_dhcp_server;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_dhcp_client_config_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_dhcp_client_config_reply payload;
} vapi_msg_dhcp_client_config_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 client_index;
  u32 pid;
  u8 hostname[64];
  u8 is_ipv6;
  u8 mask_width;
  u8 host_address[16];
  u8 router_address[16];
  u8 host_mac[6]; 
} vapi_payload_dhcp_compl_event;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_dhcp_compl_event payload;
} vapi_msg_dhcp_compl_event;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 hostname[64];
  u8 client_id[64];
  u8 is_add;
  u8 want_dhcp_event;
  u32 pid; 
} vapi_payload_dhcp_client_config;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_dhcp_client_config payload;
} vapi_msg_dhcp_client_config;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_dhcp_proxy_set_vss_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_dhcp_proxy_set_vss_reply payload;
} vapi_msg_dhcp_proxy_set_vss_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_ip6; 
} vapi_payload_dhcp_proxy_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_dhcp_proxy_dump payload;
} vapi_msg_dhcp_proxy_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_dhcp_proxy_config_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_dhcp_proxy_config_reply payload;
} vapi_msg_dhcp_proxy_config_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 rx_vrf_id;
  u32 vss_oui;
  u32 vss_fib_id;
  u8 is_ipv6;
  u8 dhcp_src_address[16];
  u8 count;
  vapi_type_dhcp_server servers[0]; 
} vapi_payload_dhcp_proxy_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_dhcp_proxy_details payload;
} vapi_msg_dhcp_proxy_details;

typedef struct __attribute__ ((__packed__)) {
  u32 rx_vrf_id;
  u32 server_vrf_id;
  u8 is_ipv6;
  u8 is_add;
  u8 dhcp_server[16];
  u8 dhcp_src_address[16]; 
} vapi_payload_dhcp_proxy_config;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_dhcp_proxy_config payload;
} vapi_msg_dhcp_proxy_config;

typedef struct __attribute__ ((__packed__)) {
  u32 tbl_id;
  u32 oui;
  u32 fib_id;
  u8 is_ipv6;
  u8 is_add; 
} vapi_payload_dhcp_proxy_set_vss;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_dhcp_proxy_set_vss payload;
} vapi_msg_dhcp_proxy_set_vss;


static inline void vapi_type_dhcp_server_hton(vapi_type_dhcp_server *msg)
{
  msg->server_vrf_id = htobe32(msg->server_vrf_id);
}

static inline void vapi_type_dhcp_server_ntoh(vapi_type_dhcp_server *msg)
{
  msg->server_vrf_id = be32toh(msg->server_vrf_id);
}

static inline void vapi_msg_dhcp_client_config_reply_payload_hton(vapi_payload_dhcp_client_config_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_dhcp_client_config_reply_payload_ntoh(vapi_payload_dhcp_client_config_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_dhcp_client_config_reply_msg_size(vapi_msg_dhcp_client_config_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_client_config_reply_hton(vapi_msg_dhcp_client_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_client_config_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_dhcp_client_config_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_client_config_reply_ntoh(vapi_msg_dhcp_client_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_client_config_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_dhcp_client_config_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_compl_event_payload_hton(vapi_payload_dhcp_compl_event *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->client_index = htobe32(payload->client_index);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_dhcp_compl_event_payload_ntoh(vapi_payload_dhcp_compl_event *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->client_index = be32toh(payload->client_index);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_dhcp_compl_event_msg_size(vapi_msg_dhcp_compl_event *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_compl_event_hton(vapi_msg_dhcp_compl_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_compl_event'@%p to big endian", msg);

  vapi_msg_dhcp_compl_event_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_compl_event_ntoh(vapi_msg_dhcp_compl_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_compl_event'@%p to host byte order", msg);

  vapi_msg_dhcp_compl_event_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_client_config_payload_hton(vapi_payload_dhcp_client_config *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_dhcp_client_config_payload_ntoh(vapi_payload_dhcp_client_config *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_dhcp_client_config_msg_size(vapi_msg_dhcp_client_config *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_client_config_hton(vapi_msg_dhcp_client_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_client_config'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_dhcp_client_config_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_client_config_ntoh(vapi_msg_dhcp_client_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_client_config'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_dhcp_client_config_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_set_vss_reply_payload_hton(vapi_payload_dhcp_proxy_set_vss_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_dhcp_proxy_set_vss_reply_payload_ntoh(vapi_payload_dhcp_proxy_set_vss_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_dhcp_proxy_set_vss_reply_msg_size(vapi_msg_dhcp_proxy_set_vss_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_proxy_set_vss_reply_hton(vapi_msg_dhcp_proxy_set_vss_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_set_vss_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_set_vss_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_set_vss_reply_ntoh(vapi_msg_dhcp_proxy_set_vss_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_set_vss_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_set_vss_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_dump_payload_hton(vapi_payload_dhcp_proxy_dump *payload)
{

}

static inline void vapi_msg_dhcp_proxy_dump_payload_ntoh(vapi_payload_dhcp_proxy_dump *payload)
{

}

static inline uword vapi_calc_dhcp_proxy_dump_msg_size(vapi_msg_dhcp_proxy_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_proxy_dump_hton(vapi_msg_dhcp_proxy_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_dump_ntoh(vapi_msg_dhcp_proxy_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_config_reply_payload_hton(vapi_payload_dhcp_proxy_config_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_dhcp_proxy_config_reply_payload_ntoh(vapi_payload_dhcp_proxy_config_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_dhcp_proxy_config_reply_msg_size(vapi_msg_dhcp_proxy_config_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_proxy_config_reply_hton(vapi_msg_dhcp_proxy_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_config_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_config_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_config_reply_ntoh(vapi_msg_dhcp_proxy_config_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_config_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_config_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_details_payload_hton(vapi_payload_dhcp_proxy_details *payload)
{
  payload->rx_vrf_id = htobe32(payload->rx_vrf_id);
  payload->vss_oui = htobe32(payload->vss_oui);
  payload->vss_fib_id = htobe32(payload->vss_fib_id);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_dhcp_server_hton(&payload->servers[i]); } } while(0);
}

static inline void vapi_msg_dhcp_proxy_details_payload_ntoh(vapi_payload_dhcp_proxy_details *payload)
{
  payload->rx_vrf_id = be32toh(payload->rx_vrf_id);
  payload->vss_oui = be32toh(payload->vss_oui);
  payload->vss_fib_id = be32toh(payload->vss_fib_id);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_dhcp_server_ntoh(&payload->servers[i]); } } while(0);
}

static inline uword vapi_calc_dhcp_proxy_details_msg_size(vapi_msg_dhcp_proxy_details *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.servers[0]);
}

static inline void vapi_msg_dhcp_proxy_details_hton(vapi_msg_dhcp_proxy_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_details_ntoh(vapi_msg_dhcp_proxy_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_config_payload_hton(vapi_payload_dhcp_proxy_config *payload)
{
  payload->rx_vrf_id = htobe32(payload->rx_vrf_id);
  payload->server_vrf_id = htobe32(payload->server_vrf_id);
}

static inline void vapi_msg_dhcp_proxy_config_payload_ntoh(vapi_payload_dhcp_proxy_config *payload)
{
  payload->rx_vrf_id = be32toh(payload->rx_vrf_id);
  payload->server_vrf_id = be32toh(payload->server_vrf_id);
}

static inline uword vapi_calc_dhcp_proxy_config_msg_size(vapi_msg_dhcp_proxy_config *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_proxy_config_hton(vapi_msg_dhcp_proxy_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_config'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_config_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_config_ntoh(vapi_msg_dhcp_proxy_config *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_config'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_config_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_set_vss_payload_hton(vapi_payload_dhcp_proxy_set_vss *payload)
{
  payload->tbl_id = htobe32(payload->tbl_id);
  payload->oui = htobe32(payload->oui);
  payload->fib_id = htobe32(payload->fib_id);
}

static inline void vapi_msg_dhcp_proxy_set_vss_payload_ntoh(vapi_payload_dhcp_proxy_set_vss *payload)
{
  payload->tbl_id = be32toh(payload->tbl_id);
  payload->oui = be32toh(payload->oui);
  payload->fib_id = be32toh(payload->fib_id);
}

static inline uword vapi_calc_dhcp_proxy_set_vss_msg_size(vapi_msg_dhcp_proxy_set_vss *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_dhcp_proxy_set_vss_hton(vapi_msg_dhcp_proxy_set_vss *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_set_vss'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_dhcp_proxy_set_vss_payload_hton(&msg->payload);
}

static inline void vapi_msg_dhcp_proxy_set_vss_ntoh(vapi_msg_dhcp_proxy_set_vss *msg)
{
  VAPI_DBG("Swapping `vapi_msg_dhcp_proxy_set_vss'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_dhcp_proxy_set_vss_payload_ntoh(&msg->payload);
}

static inline vapi_msg_dhcp_client_config* vapi_alloc_dhcp_client_config(struct vapi_ctx_s *ctx)
{
  vapi_msg_dhcp_client_config *msg = NULL;
  const size_t size = sizeof(vapi_msg_dhcp_client_config);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_dhcp_client_config*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_dhcp_client_config);

  return msg;
}

static inline vapi_error_e vapi_dhcp_client_config(struct vapi_ctx_s *ctx,
  vapi_msg_dhcp_client_config *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_dhcp_client_config_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_dhcp_client_config_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_dhcp_client_config_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_dhcp_proxy_dump* vapi_alloc_dhcp_proxy_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_dhcp_proxy_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_dhcp_proxy_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_dhcp_proxy_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_dhcp_proxy_dump);

  return msg;
}

static inline vapi_error_e vapi_dhcp_proxy_dump(struct vapi_ctx_s *ctx,
  vapi_msg_dhcp_proxy_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_dhcp_proxy_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_dhcp_proxy_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_dhcp_proxy_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_dhcp_proxy_config* vapi_alloc_dhcp_proxy_config(struct vapi_ctx_s *ctx)
{
  vapi_msg_dhcp_proxy_config *msg = NULL;
  const size_t size = sizeof(vapi_msg_dhcp_proxy_config);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_dhcp_proxy_config*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_dhcp_proxy_config);

  return msg;
}

static inline vapi_error_e vapi_dhcp_proxy_config(struct vapi_ctx_s *ctx,
  vapi_msg_dhcp_proxy_config *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_dhcp_proxy_config_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_dhcp_proxy_config_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_dhcp_proxy_config_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_dhcp_proxy_set_vss* vapi_alloc_dhcp_proxy_set_vss(struct vapi_ctx_s *ctx)
{
  vapi_msg_dhcp_proxy_set_vss *msg = NULL;
  const size_t size = sizeof(vapi_msg_dhcp_proxy_set_vss);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_dhcp_proxy_set_vss*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_dhcp_proxy_set_vss);

  return msg;
}

static inline vapi_error_e vapi_dhcp_proxy_set_vss(struct vapi_ctx_s *ctx,
  vapi_msg_dhcp_proxy_set_vss *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_dhcp_proxy_set_vss_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_dhcp_proxy_set_vss_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_dhcp_proxy_set_vss_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_dhcp_client_config_reply()
{
  static const char name[] = "dhcp_client_config_reply";
  static const char name_with_crc[] = "dhcp_client_config_reply_d947f4c8";
  static vapi_message_desc_t __vapi_metadata_dhcp_client_config_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_dhcp_client_config_reply, payload),
    sizeof(vapi_msg_dhcp_client_config_reply),
    (generic_swap_fn_t)vapi_msg_dhcp_client_config_reply_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_client_config_reply_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_client_config_reply = vapi_register_msg(&__vapi_metadata_dhcp_client_config_reply);
  VAPI_DBG("Assigned msg id %d to dhcp_client_config_reply", vapi_msg_id_dhcp_client_config_reply);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_compl_event()
{
  static const char name[] = "dhcp_compl_event";
  static const char name_with_crc[] = "dhcp_compl_event_aafb5462";
  static vapi_message_desc_t __vapi_metadata_dhcp_compl_event = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_dhcp_compl_event, payload),
    sizeof(vapi_msg_dhcp_compl_event),
    (generic_swap_fn_t)vapi_msg_dhcp_compl_event_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_compl_event_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_compl_event = vapi_register_msg(&__vapi_metadata_dhcp_compl_event);
  VAPI_DBG("Assigned msg id %d to dhcp_compl_event", vapi_msg_id_dhcp_compl_event);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_client_config()
{
  static const char name[] = "dhcp_client_config";
  static const char name_with_crc[] = "dhcp_client_config_41c8a9f2";
  static vapi_message_desc_t __vapi_metadata_dhcp_client_config = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_dhcp_client_config, payload),
    sizeof(vapi_msg_dhcp_client_config),
    (generic_swap_fn_t)vapi_msg_dhcp_client_config_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_client_config_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_client_config = vapi_register_msg(&__vapi_metadata_dhcp_client_config);
  VAPI_DBG("Assigned msg id %d to dhcp_client_config", vapi_msg_id_dhcp_client_config);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_set_vss_reply()
{
  static const char name[] = "dhcp_proxy_set_vss_reply";
  static const char name_with_crc[] = "dhcp_proxy_set_vss_reply_5bb4e754";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_set_vss_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_dhcp_proxy_set_vss_reply, payload),
    sizeof(vapi_msg_dhcp_proxy_set_vss_reply),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_set_vss_reply_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_set_vss_reply_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_set_vss_reply = vapi_register_msg(&__vapi_metadata_dhcp_proxy_set_vss_reply);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_set_vss_reply", vapi_msg_id_dhcp_proxy_set_vss_reply);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_dump()
{
  static const char name[] = "dhcp_proxy_dump";
  static const char name_with_crc[] = "dhcp_proxy_dump_175bc073";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_dhcp_proxy_dump, payload),
    sizeof(vapi_msg_dhcp_proxy_dump),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_dump_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_dump_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_dump = vapi_register_msg(&__vapi_metadata_dhcp_proxy_dump);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_dump", vapi_msg_id_dhcp_proxy_dump);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_config_reply()
{
  static const char name[] = "dhcp_proxy_config_reply";
  static const char name_with_crc[] = "dhcp_proxy_config_reply_fe63196f";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_config_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_dhcp_proxy_config_reply, payload),
    sizeof(vapi_msg_dhcp_proxy_config_reply),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_config_reply_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_config_reply_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_config_reply = vapi_register_msg(&__vapi_metadata_dhcp_proxy_config_reply);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_config_reply", vapi_msg_id_dhcp_proxy_config_reply);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_details()
{
  static const char name[] = "dhcp_proxy_details";
  static const char name_with_crc[] = "dhcp_proxy_details_9727dbdd";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_dhcp_proxy_details, payload),
    sizeof(vapi_msg_dhcp_proxy_details),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_details_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_details_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_details = vapi_register_msg(&__vapi_metadata_dhcp_proxy_details);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_details", vapi_msg_id_dhcp_proxy_details);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_config()
{
  static const char name[] = "dhcp_proxy_config";
  static const char name_with_crc[] = "dhcp_proxy_config_3b4f2bc8";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_config = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_dhcp_proxy_config, payload),
    sizeof(vapi_msg_dhcp_proxy_config),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_config_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_config_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_config = vapi_register_msg(&__vapi_metadata_dhcp_proxy_config);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_config", vapi_msg_id_dhcp_proxy_config);
}

static void __attribute__((constructor)) __vapi_constructor_dhcp_proxy_set_vss()
{
  static const char name[] = "dhcp_proxy_set_vss";
  static const char name_with_crc[] = "dhcp_proxy_set_vss_be54d194";
  static vapi_message_desc_t __vapi_metadata_dhcp_proxy_set_vss = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_dhcp_proxy_set_vss, payload),
    sizeof(vapi_msg_dhcp_proxy_set_vss),
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_set_vss_hton,
    (generic_swap_fn_t)vapi_msg_dhcp_proxy_set_vss_ntoh,
    ~0,
  };

  vapi_msg_id_dhcp_proxy_set_vss = vapi_register_msg(&__vapi_metadata_dhcp_proxy_set_vss);
  VAPI_DBG("Assigned msg id %d to dhcp_proxy_set_vss", vapi_msg_id_dhcp_proxy_set_vss);
}


static inline void vapi_set_vapi_msg_dhcp_client_config_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_dhcp_client_config_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_dhcp_client_config_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_dhcp_compl_event_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_dhcp_compl_event *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_dhcp_compl_event, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_dhcp_proxy_set_vss_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_dhcp_proxy_set_vss_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_dhcp_proxy_set_vss_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_dhcp_proxy_config_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_dhcp_proxy_config_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_dhcp_proxy_config_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_dhcp_proxy_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_dhcp_proxy_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_dhcp_proxy_details, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
