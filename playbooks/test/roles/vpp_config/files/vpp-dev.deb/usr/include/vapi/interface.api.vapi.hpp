#ifndef __included_hpp_interface_api_json
#define __included_hpp_interface_api_json

#include <vapi/vapi.hpp>
#include <vapi/interface.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_vnet_interface_simple_counters>(vapi_msg_vnet_interface_simple_counters *msg)
{
  vapi_msg_vnet_interface_simple_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_interface_simple_counters>(vapi_msg_vnet_interface_simple_counters *msg)
{
  vapi_msg_vnet_interface_simple_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_interface_simple_counters>()
{
  return ::vapi_msg_id_vnet_interface_simple_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_interface_simple_counters>>()
{
  return ::vapi_msg_id_vnet_interface_simple_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_interface_simple_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_interface_simple_counters>(vapi_msg_id_vnet_interface_simple_counters);
}

template class Msg<vapi_msg_vnet_interface_simple_counters>;

using Vnet_interface_simple_counters = Msg<vapi_msg_vnet_interface_simple_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_table_reply>(vapi_msg_sw_interface_set_table_reply *msg)
{
  vapi_msg_sw_interface_set_table_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_table_reply>(vapi_msg_sw_interface_set_table_reply *msg)
{
  vapi_msg_sw_interface_set_table_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_table_reply>()
{
  return ::vapi_msg_id_sw_interface_set_table_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_table_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_table_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_table_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_table_reply>(vapi_msg_id_sw_interface_set_table_reply);
}

template class Msg<vapi_msg_sw_interface_set_table_reply>;

using Sw_interface_set_table_reply = Msg<vapi_msg_sw_interface_set_table_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_details>(vapi_msg_sw_interface_details *msg)
{
  vapi_msg_sw_interface_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_details>(vapi_msg_sw_interface_details *msg)
{
  vapi_msg_sw_interface_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_details>()
{
  return ::vapi_msg_id_sw_interface_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_details>>()
{
  return ::vapi_msg_id_sw_interface_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_details>(vapi_msg_id_sw_interface_details);
}

template class Msg<vapi_msg_sw_interface_details>;

using Sw_interface_details = Msg<vapi_msg_sw_interface_details>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_per_interface_simple_counters>(vapi_msg_vnet_per_interface_simple_counters *msg)
{
  vapi_msg_vnet_per_interface_simple_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_per_interface_simple_counters>(vapi_msg_vnet_per_interface_simple_counters *msg)
{
  vapi_msg_vnet_per_interface_simple_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_per_interface_simple_counters>()
{
  return ::vapi_msg_id_vnet_per_interface_simple_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_per_interface_simple_counters>>()
{
  return ::vapi_msg_id_vnet_per_interface_simple_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_per_interface_simple_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_per_interface_simple_counters>(vapi_msg_id_vnet_per_interface_simple_counters);
}

template class Msg<vapi_msg_vnet_per_interface_simple_counters>;

using Vnet_per_interface_simple_counters = Msg<vapi_msg_vnet_per_interface_simple_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_tag_add_del>(vapi_msg_sw_interface_tag_add_del *msg)
{
  vapi_msg_sw_interface_tag_add_del_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_tag_add_del>(vapi_msg_sw_interface_tag_add_del *msg)
{
  vapi_msg_sw_interface_tag_add_del_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_tag_add_del>()
{
  return ::vapi_msg_id_sw_interface_tag_add_del; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_tag_add_del>>()
{
  return ::vapi_msg_id_sw_interface_tag_add_del; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_tag_add_del()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_tag_add_del>(vapi_msg_id_sw_interface_tag_add_del);
}

template <> inline vapi_msg_sw_interface_tag_add_del* vapi_alloc<vapi_msg_sw_interface_tag_add_del>(Connection &con)
{
  vapi_msg_sw_interface_tag_add_del* result = vapi_alloc_sw_interface_tag_add_del(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_tag_add_del>;

template class Request<vapi_msg_sw_interface_tag_add_del, vapi_msg_sw_interface_tag_add_del_reply>;

using Sw_interface_tag_add_del = Request<vapi_msg_sw_interface_tag_add_del, vapi_msg_sw_interface_tag_add_del_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_event>(vapi_msg_sw_interface_event *msg)
{
  vapi_msg_sw_interface_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_event>(vapi_msg_sw_interface_event *msg)
{
  vapi_msg_sw_interface_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_event>()
{
  return ::vapi_msg_id_sw_interface_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_event>>()
{
  return ::vapi_msg_id_sw_interface_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_event>(vapi_msg_id_sw_interface_event);
}

template class Msg<vapi_msg_sw_interface_event>;

using Sw_interface_event = Msg<vapi_msg_sw_interface_event>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_get_table_reply>(vapi_msg_sw_interface_get_table_reply *msg)
{
  vapi_msg_sw_interface_get_table_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_get_table_reply>(vapi_msg_sw_interface_get_table_reply *msg)
{
  vapi_msg_sw_interface_get_table_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_get_table_reply>()
{
  return ::vapi_msg_id_sw_interface_get_table_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_get_table_reply>>()
{
  return ::vapi_msg_id_sw_interface_get_table_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_get_table_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_get_table_reply>(vapi_msg_id_sw_interface_get_table_reply);
}

template class Msg<vapi_msg_sw_interface_get_table_reply>;

using Sw_interface_get_table_reply = Msg<vapi_msg_sw_interface_get_table_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_dump>(vapi_msg_sw_interface_dump *msg)
{
  vapi_msg_sw_interface_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_dump>(vapi_msg_sw_interface_dump *msg)
{
  vapi_msg_sw_interface_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_dump>()
{
  return ::vapi_msg_id_sw_interface_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_dump>>()
{
  return ::vapi_msg_id_sw_interface_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_dump>(vapi_msg_id_sw_interface_dump);
}

template <> inline vapi_msg_sw_interface_dump* vapi_alloc<vapi_msg_sw_interface_dump>(Connection &con)
{
  vapi_msg_sw_interface_dump* result = vapi_alloc_sw_interface_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_dump>;

template class Dump<vapi_msg_sw_interface_dump, vapi_msg_sw_interface_details>;

using Sw_interface_dump = Dump<vapi_msg_sw_interface_dump, vapi_msg_sw_interface_details>;

template <> inline void vapi_swap_to_be<vapi_msg_want_interface_events_reply>(vapi_msg_want_interface_events_reply *msg)
{
  vapi_msg_want_interface_events_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_events_reply>(vapi_msg_want_interface_events_reply *msg)
{
  vapi_msg_want_interface_events_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_events_reply>()
{
  return ::vapi_msg_id_want_interface_events_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_events_reply>>()
{
  return ::vapi_msg_id_want_interface_events_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_events_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_events_reply>(vapi_msg_id_want_interface_events_reply);
}

template class Msg<vapi_msg_want_interface_events_reply>;

using Want_interface_events_reply = Msg<vapi_msg_want_interface_events_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_clear_stats_reply>(vapi_msg_sw_interface_clear_stats_reply *msg)
{
  vapi_msg_sw_interface_clear_stats_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_clear_stats_reply>(vapi_msg_sw_interface_clear_stats_reply *msg)
{
  vapi_msg_sw_interface_clear_stats_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_clear_stats_reply>()
{
  return ::vapi_msg_id_sw_interface_clear_stats_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_clear_stats_reply>>()
{
  return ::vapi_msg_id_sw_interface_clear_stats_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_clear_stats_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_clear_stats_reply>(vapi_msg_id_sw_interface_clear_stats_reply);
}

template class Msg<vapi_msg_sw_interface_clear_stats_reply>;

using Sw_interface_clear_stats_reply = Msg<vapi_msg_sw_interface_clear_stats_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_interface_combined_counters>(vapi_msg_vnet_interface_combined_counters *msg)
{
  vapi_msg_vnet_interface_combined_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_interface_combined_counters>(vapi_msg_vnet_interface_combined_counters *msg)
{
  vapi_msg_vnet_interface_combined_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_interface_combined_counters>()
{
  return ::vapi_msg_id_vnet_interface_combined_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_interface_combined_counters>>()
{
  return ::vapi_msg_id_vnet_interface_combined_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_interface_combined_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_interface_combined_counters>(vapi_msg_id_vnet_interface_combined_counters);
}

template class Msg<vapi_msg_vnet_interface_combined_counters>;

using Vnet_interface_combined_counters = Msg<vapi_msg_vnet_interface_combined_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_vnet_per_interface_combined_counters>(vapi_msg_vnet_per_interface_combined_counters *msg)
{
  vapi_msg_vnet_per_interface_combined_counters_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_vnet_per_interface_combined_counters>(vapi_msg_vnet_per_interface_combined_counters *msg)
{
  vapi_msg_vnet_per_interface_combined_counters_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_vnet_per_interface_combined_counters>()
{
  return ::vapi_msg_id_vnet_per_interface_combined_counters; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_vnet_per_interface_combined_counters>>()
{
  return ::vapi_msg_id_vnet_per_interface_combined_counters; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_vnet_per_interface_combined_counters()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_vnet_per_interface_combined_counters>(vapi_msg_id_vnet_per_interface_combined_counters);
}

template class Msg<vapi_msg_vnet_per_interface_combined_counters>;

using Vnet_per_interface_combined_counters = Msg<vapi_msg_vnet_per_interface_combined_counters>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_add_del_address>(vapi_msg_sw_interface_add_del_address *msg)
{
  vapi_msg_sw_interface_add_del_address_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_add_del_address>(vapi_msg_sw_interface_add_del_address *msg)
{
  vapi_msg_sw_interface_add_del_address_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_add_del_address>()
{
  return ::vapi_msg_id_sw_interface_add_del_address; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_add_del_address>>()
{
  return ::vapi_msg_id_sw_interface_add_del_address; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_add_del_address()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_add_del_address>(vapi_msg_id_sw_interface_add_del_address);
}

template <> inline vapi_msg_sw_interface_add_del_address* vapi_alloc<vapi_msg_sw_interface_add_del_address>(Connection &con)
{
  vapi_msg_sw_interface_add_del_address* result = vapi_alloc_sw_interface_add_del_address(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_add_del_address>;

template class Request<vapi_msg_sw_interface_add_del_address, vapi_msg_sw_interface_add_del_address_reply>;

using Sw_interface_add_del_address = Request<vapi_msg_sw_interface_add_del_address, vapi_msg_sw_interface_add_del_address_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mac_address_reply>(vapi_msg_sw_interface_set_mac_address_reply *msg)
{
  vapi_msg_sw_interface_set_mac_address_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mac_address_reply>(vapi_msg_sw_interface_set_mac_address_reply *msg)
{
  vapi_msg_sw_interface_set_mac_address_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mac_address_reply>()
{
  return ::vapi_msg_id_sw_interface_set_mac_address_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mac_address_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_mac_address_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mac_address_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mac_address_reply>(vapi_msg_id_sw_interface_set_mac_address_reply);
}

template class Msg<vapi_msg_sw_interface_set_mac_address_reply>;

using Sw_interface_set_mac_address_reply = Msg<vapi_msg_sw_interface_set_mac_address_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_unnumbered_reply>(vapi_msg_sw_interface_set_unnumbered_reply *msg)
{
  vapi_msg_sw_interface_set_unnumbered_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_unnumbered_reply>(vapi_msg_sw_interface_set_unnumbered_reply *msg)
{
  vapi_msg_sw_interface_set_unnumbered_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_unnumbered_reply>()
{
  return ::vapi_msg_id_sw_interface_set_unnumbered_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_unnumbered_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_unnumbered_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_unnumbered_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_unnumbered_reply>(vapi_msg_id_sw_interface_set_unnumbered_reply);
}

template class Msg<vapi_msg_sw_interface_set_unnumbered_reply>;

using Sw_interface_set_unnumbered_reply = Msg<vapi_msg_sw_interface_set_unnumbered_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_get_table>(vapi_msg_sw_interface_get_table *msg)
{
  vapi_msg_sw_interface_get_table_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_get_table>(vapi_msg_sw_interface_get_table *msg)
{
  vapi_msg_sw_interface_get_table_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_get_table>()
{
  return ::vapi_msg_id_sw_interface_get_table; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_get_table>>()
{
  return ::vapi_msg_id_sw_interface_get_table; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_get_table()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_get_table>(vapi_msg_id_sw_interface_get_table);
}

template <> inline vapi_msg_sw_interface_get_table* vapi_alloc<vapi_msg_sw_interface_get_table>(Connection &con)
{
  vapi_msg_sw_interface_get_table* result = vapi_alloc_sw_interface_get_table(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_get_table>;

template class Request<vapi_msg_sw_interface_get_table, vapi_msg_sw_interface_get_table_reply>;

using Sw_interface_get_table = Request<vapi_msg_sw_interface_get_table, vapi_msg_sw_interface_get_table_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mtu>(vapi_msg_sw_interface_set_mtu *msg)
{
  vapi_msg_sw_interface_set_mtu_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mtu>(vapi_msg_sw_interface_set_mtu *msg)
{
  vapi_msg_sw_interface_set_mtu_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mtu>()
{
  return ::vapi_msg_id_sw_interface_set_mtu; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mtu>>()
{
  return ::vapi_msg_id_sw_interface_set_mtu; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mtu()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mtu>(vapi_msg_id_sw_interface_set_mtu);
}

template <> inline vapi_msg_sw_interface_set_mtu* vapi_alloc<vapi_msg_sw_interface_set_mtu>(Connection &con)
{
  vapi_msg_sw_interface_set_mtu* result = vapi_alloc_sw_interface_set_mtu(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_mtu>;

template class Request<vapi_msg_sw_interface_set_mtu, vapi_msg_sw_interface_set_mtu_reply>;

using Sw_interface_set_mtu = Request<vapi_msg_sw_interface_set_mtu, vapi_msg_sw_interface_set_mtu_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_clear_stats>(vapi_msg_sw_interface_clear_stats *msg)
{
  vapi_msg_sw_interface_clear_stats_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_clear_stats>(vapi_msg_sw_interface_clear_stats *msg)
{
  vapi_msg_sw_interface_clear_stats_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_clear_stats>()
{
  return ::vapi_msg_id_sw_interface_clear_stats; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_clear_stats>>()
{
  return ::vapi_msg_id_sw_interface_clear_stats; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_clear_stats()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_clear_stats>(vapi_msg_id_sw_interface_clear_stats);
}

template <> inline vapi_msg_sw_interface_clear_stats* vapi_alloc<vapi_msg_sw_interface_clear_stats>(Connection &con)
{
  vapi_msg_sw_interface_clear_stats* result = vapi_alloc_sw_interface_clear_stats(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_clear_stats>;

template class Request<vapi_msg_sw_interface_clear_stats, vapi_msg_sw_interface_clear_stats_reply>;

using Sw_interface_clear_stats = Request<vapi_msg_sw_interface_clear_stats, vapi_msg_sw_interface_clear_stats_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mtu_reply>(vapi_msg_sw_interface_set_mtu_reply *msg)
{
  vapi_msg_sw_interface_set_mtu_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mtu_reply>(vapi_msg_sw_interface_set_mtu_reply *msg)
{
  vapi_msg_sw_interface_set_mtu_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mtu_reply>()
{
  return ::vapi_msg_id_sw_interface_set_mtu_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mtu_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_mtu_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mtu_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mtu_reply>(vapi_msg_id_sw_interface_set_mtu_reply);
}

template class Msg<vapi_msg_sw_interface_set_mtu_reply>;

using Sw_interface_set_mtu_reply = Msg<vapi_msg_sw_interface_set_mtu_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_mac_address>(vapi_msg_sw_interface_set_mac_address *msg)
{
  vapi_msg_sw_interface_set_mac_address_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_mac_address>(vapi_msg_sw_interface_set_mac_address *msg)
{
  vapi_msg_sw_interface_set_mac_address_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_mac_address>()
{
  return ::vapi_msg_id_sw_interface_set_mac_address; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_mac_address>>()
{
  return ::vapi_msg_id_sw_interface_set_mac_address; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_mac_address()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_mac_address>(vapi_msg_id_sw_interface_set_mac_address);
}

template <> inline vapi_msg_sw_interface_set_mac_address* vapi_alloc<vapi_msg_sw_interface_set_mac_address>(Connection &con)
{
  vapi_msg_sw_interface_set_mac_address* result = vapi_alloc_sw_interface_set_mac_address(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_mac_address>;

template class Request<vapi_msg_sw_interface_set_mac_address, vapi_msg_sw_interface_set_mac_address_reply>;

using Sw_interface_set_mac_address = Request<vapi_msg_sw_interface_set_mac_address, vapi_msg_sw_interface_set_mac_address_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_unnumbered>(vapi_msg_sw_interface_set_unnumbered *msg)
{
  vapi_msg_sw_interface_set_unnumbered_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_unnumbered>(vapi_msg_sw_interface_set_unnumbered *msg)
{
  vapi_msg_sw_interface_set_unnumbered_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_unnumbered>()
{
  return ::vapi_msg_id_sw_interface_set_unnumbered; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_unnumbered>>()
{
  return ::vapi_msg_id_sw_interface_set_unnumbered; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_unnumbered()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_unnumbered>(vapi_msg_id_sw_interface_set_unnumbered);
}

template <> inline vapi_msg_sw_interface_set_unnumbered* vapi_alloc<vapi_msg_sw_interface_set_unnumbered>(Connection &con)
{
  vapi_msg_sw_interface_set_unnumbered* result = vapi_alloc_sw_interface_set_unnumbered(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_unnumbered>;

template class Request<vapi_msg_sw_interface_set_unnumbered, vapi_msg_sw_interface_set_unnumbered_reply>;

using Sw_interface_set_unnumbered = Request<vapi_msg_sw_interface_set_unnumbered, vapi_msg_sw_interface_set_unnumbered_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_flags>(vapi_msg_sw_interface_set_flags *msg)
{
  vapi_msg_sw_interface_set_flags_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_flags>(vapi_msg_sw_interface_set_flags *msg)
{
  vapi_msg_sw_interface_set_flags_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_flags>()
{
  return ::vapi_msg_id_sw_interface_set_flags; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_flags>>()
{
  return ::vapi_msg_id_sw_interface_set_flags; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_flags()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_flags>(vapi_msg_id_sw_interface_set_flags);
}

template <> inline vapi_msg_sw_interface_set_flags* vapi_alloc<vapi_msg_sw_interface_set_flags>(Connection &con)
{
  vapi_msg_sw_interface_set_flags* result = vapi_alloc_sw_interface_set_flags(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_flags>;

template class Request<vapi_msg_sw_interface_set_flags, vapi_msg_sw_interface_set_flags_reply>;

using Sw_interface_set_flags = Request<vapi_msg_sw_interface_set_flags, vapi_msg_sw_interface_set_flags_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_add_del_address_reply>(vapi_msg_sw_interface_add_del_address_reply *msg)
{
  vapi_msg_sw_interface_add_del_address_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_add_del_address_reply>(vapi_msg_sw_interface_add_del_address_reply *msg)
{
  vapi_msg_sw_interface_add_del_address_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_add_del_address_reply>()
{
  return ::vapi_msg_id_sw_interface_add_del_address_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_add_del_address_reply>>()
{
  return ::vapi_msg_id_sw_interface_add_del_address_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_add_del_address_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_add_del_address_reply>(vapi_msg_id_sw_interface_add_del_address_reply);
}

template class Msg<vapi_msg_sw_interface_add_del_address_reply>;

using Sw_interface_add_del_address_reply = Msg<vapi_msg_sw_interface_add_del_address_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_flags_reply>(vapi_msg_sw_interface_set_flags_reply *msg)
{
  vapi_msg_sw_interface_set_flags_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_flags_reply>(vapi_msg_sw_interface_set_flags_reply *msg)
{
  vapi_msg_sw_interface_set_flags_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_flags_reply>()
{
  return ::vapi_msg_id_sw_interface_set_flags_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_flags_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_flags_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_flags_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_flags_reply>(vapi_msg_id_sw_interface_set_flags_reply);
}

template class Msg<vapi_msg_sw_interface_set_flags_reply>;

using Sw_interface_set_flags_reply = Msg<vapi_msg_sw_interface_set_flags_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_want_interface_events>(vapi_msg_want_interface_events *msg)
{
  vapi_msg_want_interface_events_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_want_interface_events>(vapi_msg_want_interface_events *msg)
{
  vapi_msg_want_interface_events_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_want_interface_events>()
{
  return ::vapi_msg_id_want_interface_events; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_want_interface_events>>()
{
  return ::vapi_msg_id_want_interface_events; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_want_interface_events()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_want_interface_events>(vapi_msg_id_want_interface_events);
}

template <> inline vapi_msg_want_interface_events* vapi_alloc<vapi_msg_want_interface_events>(Connection &con)
{
  vapi_msg_want_interface_events* result = vapi_alloc_want_interface_events(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_want_interface_events>;

template class Request<vapi_msg_want_interface_events, vapi_msg_want_interface_events_reply>;

using Want_interface_events = Request<vapi_msg_want_interface_events, vapi_msg_want_interface_events_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_table>(vapi_msg_sw_interface_set_table *msg)
{
  vapi_msg_sw_interface_set_table_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_table>(vapi_msg_sw_interface_set_table *msg)
{
  vapi_msg_sw_interface_set_table_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_table>()
{
  return ::vapi_msg_id_sw_interface_set_table; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_table>>()
{
  return ::vapi_msg_id_sw_interface_set_table; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_table()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_table>(vapi_msg_id_sw_interface_set_table);
}

template <> inline vapi_msg_sw_interface_set_table* vapi_alloc<vapi_msg_sw_interface_set_table>(Connection &con)
{
  vapi_msg_sw_interface_set_table* result = vapi_alloc_sw_interface_set_table(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_table>;

template class Request<vapi_msg_sw_interface_set_table, vapi_msg_sw_interface_set_table_reply>;

using Sw_interface_set_table = Request<vapi_msg_sw_interface_set_table, vapi_msg_sw_interface_set_table_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_tag_add_del_reply>(vapi_msg_sw_interface_tag_add_del_reply *msg)
{
  vapi_msg_sw_interface_tag_add_del_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_tag_add_del_reply>(vapi_msg_sw_interface_tag_add_del_reply *msg)
{
  vapi_msg_sw_interface_tag_add_del_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_tag_add_del_reply>()
{
  return ::vapi_msg_id_sw_interface_tag_add_del_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_tag_add_del_reply>>()
{
  return ::vapi_msg_id_sw_interface_tag_add_del_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_tag_add_del_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_tag_add_del_reply>(vapi_msg_id_sw_interface_tag_add_del_reply);
}

template class Msg<vapi_msg_sw_interface_tag_add_del_reply>;

using Sw_interface_tag_add_del_reply = Msg<vapi_msg_sw_interface_tag_add_del_reply>;
}
#endif
