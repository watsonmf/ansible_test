/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/lldp/lldp.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/lldp/lldp.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_LLDP_CONFIG, vl_api_lldp_config_t_handler)
vl_msg_id(VL_API_LLDP_CONFIG_REPLY, vl_api_lldp_config_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_LLDP, vl_api_sw_interface_set_lldp_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_LLDP_REPLY, vl_api_sw_interface_set_lldp_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_lldp_config_t, 1)
vl_msg_name(vl_api_lldp_config_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_lldp_t, 1)
vl_msg_name(vl_api_sw_interface_set_lldp_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_lldp \
_(VL_API_LLDP_CONFIG, lldp_config, 3035001d) \
_(VL_API_LLDP_CONFIG_REPLY, lldp_config_reply, d70f52db) \
_(VL_API_SW_INTERFACE_SET_LLDP, sw_interface_set_lldp, 506efa2d) \
_(VL_API_SW_INTERFACE_SET_LLDP_REPLY, sw_interface_set_lldp_reply, 4082ecce) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_lldp_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 system_name[256];
    u32 tx_hold;
    u32 tx_interval;
}) vl_api_lldp_config_t;

typedef VL_API_PACKED(struct _vl_api_lldp_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_lldp_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_lldp {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 port_desc[256];
    u8 enable;
}) vl_api_sw_interface_set_lldp_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_lldp_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_lldp_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_lldp_config_t_print (vl_api_lldp_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_lldp_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 256; _i++) {
            vl_print(handle, "system_name[%d]: %u\n", _i, a->system_name[_i]);
        }
    }
    vl_print(handle, "tx_hold: %u\n", (unsigned) a->tx_hold);
    vl_print(handle, "tx_interval: %u\n", (unsigned) a->tx_interval);
    return handle;
}

static inline void *vl_api_lldp_config_reply_t_print (vl_api_lldp_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_lldp_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_lldp_t_print (vl_api_sw_interface_set_lldp_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_lldp_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 256; _i++) {
            vl_print(handle, "port_desc[%d]: %u\n", _i, a->port_desc[_i]);
        }
    }
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_set_lldp_reply_t_print (vl_api_sw_interface_set_lldp_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_lldp_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_lldp_config_t_endian (vl_api_lldp_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->system_name[0..255] = a->system_name[0..255] (no-op) */
    a->tx_hold = clib_net_to_host_u32(a->tx_hold);
    a->tx_interval = clib_net_to_host_u32(a->tx_interval);
}

static inline void vl_api_lldp_config_reply_t_endian (vl_api_lldp_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_lldp_t_endian (vl_api_sw_interface_set_lldp_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->port_desc[0..255] = a->port_desc[0..255] (no-op) */
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_lldp_reply_t_endian (vl_api_sw_interface_set_lldp_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(lldp.api, 0x224c7aad)

#endif

