#ifndef __included_hpp_dhcp_api_json
#define __included_hpp_dhcp_api_json

#include <vapi/vapi.hpp>
#include <vapi/dhcp.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_dhcp_client_config_reply>(vapi_msg_dhcp_client_config_reply *msg)
{
  vapi_msg_dhcp_client_config_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_client_config_reply>(vapi_msg_dhcp_client_config_reply *msg)
{
  vapi_msg_dhcp_client_config_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_client_config_reply>()
{
  return ::vapi_msg_id_dhcp_client_config_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_client_config_reply>>()
{
  return ::vapi_msg_id_dhcp_client_config_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_client_config_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_client_config_reply>(vapi_msg_id_dhcp_client_config_reply);
}

template class Msg<vapi_msg_dhcp_client_config_reply>;

using Dhcp_client_config_reply = Msg<vapi_msg_dhcp_client_config_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_dhcp_compl_event>(vapi_msg_dhcp_compl_event *msg)
{
  vapi_msg_dhcp_compl_event_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_compl_event>(vapi_msg_dhcp_compl_event *msg)
{
  vapi_msg_dhcp_compl_event_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_compl_event>()
{
  return ::vapi_msg_id_dhcp_compl_event; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_compl_event>>()
{
  return ::vapi_msg_id_dhcp_compl_event; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_compl_event()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_compl_event>(vapi_msg_id_dhcp_compl_event);
}

template class Msg<vapi_msg_dhcp_compl_event>;

using Dhcp_compl_event = Msg<vapi_msg_dhcp_compl_event>;
template <> inline void vapi_swap_to_be<vapi_msg_dhcp_client_config>(vapi_msg_dhcp_client_config *msg)
{
  vapi_msg_dhcp_client_config_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_client_config>(vapi_msg_dhcp_client_config *msg)
{
  vapi_msg_dhcp_client_config_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_client_config>()
{
  return ::vapi_msg_id_dhcp_client_config; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_client_config>>()
{
  return ::vapi_msg_id_dhcp_client_config; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_client_config()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_client_config>(vapi_msg_id_dhcp_client_config);
}

template <> inline vapi_msg_dhcp_client_config* vapi_alloc<vapi_msg_dhcp_client_config>(Connection &con)
{
  vapi_msg_dhcp_client_config* result = vapi_alloc_dhcp_client_config(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_dhcp_client_config>;

template class Request<vapi_msg_dhcp_client_config, vapi_msg_dhcp_client_config_reply>;

using Dhcp_client_config = Request<vapi_msg_dhcp_client_config, vapi_msg_dhcp_client_config_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_set_vss_reply>(vapi_msg_dhcp_proxy_set_vss_reply *msg)
{
  vapi_msg_dhcp_proxy_set_vss_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_set_vss_reply>(vapi_msg_dhcp_proxy_set_vss_reply *msg)
{
  vapi_msg_dhcp_proxy_set_vss_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_set_vss_reply>()
{
  return ::vapi_msg_id_dhcp_proxy_set_vss_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_set_vss_reply>>()
{
  return ::vapi_msg_id_dhcp_proxy_set_vss_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_set_vss_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_set_vss_reply>(vapi_msg_id_dhcp_proxy_set_vss_reply);
}

template class Msg<vapi_msg_dhcp_proxy_set_vss_reply>;

using Dhcp_proxy_set_vss_reply = Msg<vapi_msg_dhcp_proxy_set_vss_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_dump>(vapi_msg_dhcp_proxy_dump *msg)
{
  vapi_msg_dhcp_proxy_dump_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_dump>(vapi_msg_dhcp_proxy_dump *msg)
{
  vapi_msg_dhcp_proxy_dump_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_dump>()
{
  return ::vapi_msg_id_dhcp_proxy_dump; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_dump>>()
{
  return ::vapi_msg_id_dhcp_proxy_dump; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_dump()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_dump>(vapi_msg_id_dhcp_proxy_dump);
}

template <> inline vapi_msg_dhcp_proxy_dump* vapi_alloc<vapi_msg_dhcp_proxy_dump>(Connection &con)
{
  vapi_msg_dhcp_proxy_dump* result = vapi_alloc_dhcp_proxy_dump(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_dhcp_proxy_dump>;

template class Dump<vapi_msg_dhcp_proxy_dump, vapi_msg_dhcp_proxy_details>;

using Dhcp_proxy_dump = Dump<vapi_msg_dhcp_proxy_dump, vapi_msg_dhcp_proxy_details>;

template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_config_reply>(vapi_msg_dhcp_proxy_config_reply *msg)
{
  vapi_msg_dhcp_proxy_config_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_config_reply>(vapi_msg_dhcp_proxy_config_reply *msg)
{
  vapi_msg_dhcp_proxy_config_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_config_reply>()
{
  return ::vapi_msg_id_dhcp_proxy_config_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_config_reply>>()
{
  return ::vapi_msg_id_dhcp_proxy_config_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_config_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_config_reply>(vapi_msg_id_dhcp_proxy_config_reply);
}

template class Msg<vapi_msg_dhcp_proxy_config_reply>;

using Dhcp_proxy_config_reply = Msg<vapi_msg_dhcp_proxy_config_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_details>(vapi_msg_dhcp_proxy_details *msg)
{
  vapi_msg_dhcp_proxy_details_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_details>(vapi_msg_dhcp_proxy_details *msg)
{
  vapi_msg_dhcp_proxy_details_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_details>()
{
  return ::vapi_msg_id_dhcp_proxy_details; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_details>>()
{
  return ::vapi_msg_id_dhcp_proxy_details; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_details()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_details>(vapi_msg_id_dhcp_proxy_details);
}

template class Msg<vapi_msg_dhcp_proxy_details>;

using Dhcp_proxy_details = Msg<vapi_msg_dhcp_proxy_details>;
template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_config>(vapi_msg_dhcp_proxy_config *msg)
{
  vapi_msg_dhcp_proxy_config_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_config>(vapi_msg_dhcp_proxy_config *msg)
{
  vapi_msg_dhcp_proxy_config_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_config>()
{
  return ::vapi_msg_id_dhcp_proxy_config; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_config>>()
{
  return ::vapi_msg_id_dhcp_proxy_config; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_config()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_config>(vapi_msg_id_dhcp_proxy_config);
}

template <> inline vapi_msg_dhcp_proxy_config* vapi_alloc<vapi_msg_dhcp_proxy_config>(Connection &con)
{
  vapi_msg_dhcp_proxy_config* result = vapi_alloc_dhcp_proxy_config(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_dhcp_proxy_config>;

template class Request<vapi_msg_dhcp_proxy_config, vapi_msg_dhcp_proxy_config_reply>;

using Dhcp_proxy_config = Request<vapi_msg_dhcp_proxy_config, vapi_msg_dhcp_proxy_config_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_dhcp_proxy_set_vss>(vapi_msg_dhcp_proxy_set_vss *msg)
{
  vapi_msg_dhcp_proxy_set_vss_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_dhcp_proxy_set_vss>(vapi_msg_dhcp_proxy_set_vss *msg)
{
  vapi_msg_dhcp_proxy_set_vss_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_dhcp_proxy_set_vss>()
{
  return ::vapi_msg_id_dhcp_proxy_set_vss; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_dhcp_proxy_set_vss>>()
{
  return ::vapi_msg_id_dhcp_proxy_set_vss; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_dhcp_proxy_set_vss()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_dhcp_proxy_set_vss>(vapi_msg_id_dhcp_proxy_set_vss);
}

template <> inline vapi_msg_dhcp_proxy_set_vss* vapi_alloc<vapi_msg_dhcp_proxy_set_vss>(Connection &con)
{
  vapi_msg_dhcp_proxy_set_vss* result = vapi_alloc_dhcp_proxy_set_vss(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_dhcp_proxy_set_vss>;

template class Request<vapi_msg_dhcp_proxy_set_vss, vapi_msg_dhcp_proxy_set_vss_reply>;

using Dhcp_proxy_set_vss = Request<vapi_msg_dhcp_proxy_set_vss, vapi_msg_dhcp_proxy_set_vss_reply>;

}
#endif
