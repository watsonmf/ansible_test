#ifndef __included_interface_api_json
#define __included_interface_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_vnet_interface_simple_counters;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_table_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_details;
extern vapi_msg_id_t vapi_msg_id_vnet_per_interface_simple_counters;
extern vapi_msg_id_t vapi_msg_id_sw_interface_tag_add_del;
extern vapi_msg_id_t vapi_msg_id_sw_interface_event;
extern vapi_msg_id_t vapi_msg_id_sw_interface_get_table_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_dump;
extern vapi_msg_id_t vapi_msg_id_want_interface_events_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_clear_stats_reply;
extern vapi_msg_id_t vapi_msg_id_vnet_interface_combined_counters;
extern vapi_msg_id_t vapi_msg_id_vnet_per_interface_combined_counters;
extern vapi_msg_id_t vapi_msg_id_sw_interface_add_del_address;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mac_address_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_unnumbered_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_get_table;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mtu;
extern vapi_msg_id_t vapi_msg_id_sw_interface_clear_stats;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mtu_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_mac_address;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_unnumbered;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_flags;
extern vapi_msg_id_t vapi_msg_id_sw_interface_add_del_address_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_flags_reply;
extern vapi_msg_id_t vapi_msg_id_want_interface_events;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_table;
extern vapi_msg_id_t vapi_msg_id_sw_interface_tag_add_del_reply;

#define DEFINE_VAPI_MSG_IDS_INTERFACE_API_JSON\
  vapi_msg_id_t vapi_msg_id_vnet_interface_simple_counters;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_table_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_details;\
  vapi_msg_id_t vapi_msg_id_vnet_per_interface_simple_counters;\
  vapi_msg_id_t vapi_msg_id_sw_interface_tag_add_del;\
  vapi_msg_id_t vapi_msg_id_sw_interface_event;\
  vapi_msg_id_t vapi_msg_id_sw_interface_get_table_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_dump;\
  vapi_msg_id_t vapi_msg_id_want_interface_events_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_clear_stats_reply;\
  vapi_msg_id_t vapi_msg_id_vnet_interface_combined_counters;\
  vapi_msg_id_t vapi_msg_id_vnet_per_interface_combined_counters;\
  vapi_msg_id_t vapi_msg_id_sw_interface_add_del_address;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mac_address_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_unnumbered_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_get_table;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mtu;\
  vapi_msg_id_t vapi_msg_id_sw_interface_clear_stats;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mtu_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_mac_address;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_unnumbered;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_flags;\
  vapi_msg_id_t vapi_msg_id_sw_interface_add_del_address_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_flags_reply;\
  vapi_msg_id_t vapi_msg_id_want_interface_events;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_table;\
  vapi_msg_id_t vapi_msg_id_sw_interface_tag_add_del_reply;


typedef struct __attribute__((__packed__)) {
  u64 packets;
  u64 bytes;
} vapi_type_vlib_counter;

typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u64 drop;
  u64 punt;
  u64 rx_ip4;
  u64 rx_ip6;
  u64 rx_no_buffer;
  u64 rx_miss;
  u64 rx_error;
  u64 tx_error;
  u64 rx_mpls;
} vapi_type_vnet_simple_counter;

typedef struct __attribute__((__packed__)) {
  u32 sw_if_index;
  u64 rx_packets;
  u64 rx_bytes;
  u64 tx_packets;
  u64 tx_bytes;
} vapi_type_vnet_combined_counter;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u8 vnet_counter_type;
  u32 first_sw_if_index;
  u32 count;
  u64 data[0]; 
} vapi_payload_vnet_interface_simple_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_interface_simple_counters payload;
} vapi_msg_vnet_interface_simple_counters;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_table_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_table_reply payload;
} vapi_msg_sw_interface_set_table_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 sup_sw_if_index;
  u32 l2_address_length;
  u8 l2_address[8];
  u8 interface_name[64];
  u8 admin_up_down;
  u8 link_up_down;
  u8 link_duplex;
  u8 link_speed;
  u16 link_mtu;
  u32 sub_id;
  u8 sub_dot1ad;
  u8 sub_dot1ah;
  u8 sub_number_of_tags;
  u16 sub_outer_vlan_id;
  u16 sub_inner_vlan_id;
  u8 sub_exact_match;
  u8 sub_default;
  u8 sub_outer_vlan_id_any;
  u8 sub_inner_vlan_id_any;
  u32 vtr_op;
  u32 vtr_push_dot1q;
  u32 vtr_tag1;
  u32 vtr_tag2;
  u8 tag[64];
  u16 outer_tag;
  u8 b_dmac[6];
  u8 b_smac[6];
  u16 b_vlanid;
  u32 i_sid; 
} vapi_payload_sw_interface_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_details payload;
} vapi_msg_sw_interface_details;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 count;
  u32 timestamp;
  vapi_type_vnet_simple_counter data[0]; 
} vapi_payload_vnet_per_interface_simple_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_per_interface_simple_counters payload;
} vapi_msg_vnet_per_interface_simple_counters;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u32 sw_if_index;
  u8 tag[64]; 
} vapi_payload_sw_interface_tag_add_del;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_tag_add_del payload;
} vapi_msg_sw_interface_tag_add_del;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 client_index;
  u32 pid;
  u32 sw_if_index;
  u8 admin_up_down;
  u8 link_up_down;
  u8 deleted; 
} vapi_payload_sw_interface_event;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_sw_interface_event payload;
} vapi_msg_sw_interface_event;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 vrf_id; 
} vapi_payload_sw_interface_get_table_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_get_table_reply payload;
} vapi_msg_sw_interface_get_table_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 name_filter_valid;
  u8 name_filter[49]; 
} vapi_payload_sw_interface_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_dump payload;
} vapi_msg_sw_interface_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_want_interface_events_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_want_interface_events_reply payload;
} vapi_msg_want_interface_events_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_clear_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_clear_stats_reply payload;
} vapi_msg_sw_interface_clear_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u8 vnet_counter_type;
  u32 first_sw_if_index;
  u32 count;
  vapi_type_vlib_counter data[0]; 
} vapi_payload_vnet_interface_combined_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_interface_combined_counters payload;
} vapi_msg_vnet_interface_combined_counters;

typedef struct __attribute__ ((__packed__)) {
  u16 _vl_msg_id;
  u32 count;
  u32 timestamp;
  vapi_type_vnet_combined_counter data[0]; 
} vapi_payload_vnet_per_interface_combined_counters;

typedef struct __attribute__ ((__packed__)) {

  vapi_payload_vnet_per_interface_combined_counters payload;
} vapi_msg_vnet_per_interface_combined_counters;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_add;
  u8 is_ipv6;
  u8 del_all;
  u8 address_length;
  u8 address[16]; 
} vapi_payload_sw_interface_add_del_address;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_add_del_address payload;
} vapi_msg_sw_interface_add_del_address;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_mac_address_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_mac_address_reply payload;
} vapi_msg_sw_interface_set_mac_address_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_unnumbered_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_unnumbered_reply payload;
} vapi_msg_sw_interface_set_unnumbered_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_ipv6; 
} vapi_payload_sw_interface_get_table;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_get_table payload;
} vapi_msg_sw_interface_get_table;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u16 mtu; 
} vapi_payload_sw_interface_set_mtu;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_mtu payload;
} vapi_msg_sw_interface_set_mtu;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_sw_interface_clear_stats;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_clear_stats payload;
} vapi_msg_sw_interface_clear_stats;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_mtu_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_mtu_reply payload;
} vapi_msg_sw_interface_set_mtu_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 mac_address[6]; 
} vapi_payload_sw_interface_set_mac_address;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_mac_address payload;
} vapi_msg_sw_interface_set_mac_address;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 unnumbered_sw_if_index;
  u8 is_add; 
} vapi_payload_sw_interface_set_unnumbered;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_unnumbered payload;
} vapi_msg_sw_interface_set_unnumbered;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 admin_up_down; 
} vapi_payload_sw_interface_set_flags;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_flags payload;
} vapi_msg_sw_interface_set_flags;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_add_del_address_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_add_del_address_reply payload;
} vapi_msg_sw_interface_add_del_address_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_flags_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_flags_reply payload;
} vapi_msg_sw_interface_set_flags_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 enable_disable;
  u32 pid; 
} vapi_payload_want_interface_events;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_want_interface_events payload;
} vapi_msg_want_interface_events;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_ipv6;
  u32 vrf_id; 
} vapi_payload_sw_interface_set_table;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_table payload;
} vapi_msg_sw_interface_set_table;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_tag_add_del_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_tag_add_del_reply payload;
} vapi_msg_sw_interface_tag_add_del_reply;


static inline void vapi_type_vlib_counter_hton(vapi_type_vlib_counter *msg)
{
  msg->packets = htobe64(msg->packets);
  msg->bytes = htobe64(msg->bytes);
}

static inline void vapi_type_vlib_counter_ntoh(vapi_type_vlib_counter *msg)
{
  msg->packets = be64toh(msg->packets);
  msg->bytes = be64toh(msg->bytes);
}

static inline void vapi_type_vnet_simple_counter_hton(vapi_type_vnet_simple_counter *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
  msg->drop = htobe64(msg->drop);
  msg->punt = htobe64(msg->punt);
  msg->rx_ip4 = htobe64(msg->rx_ip4);
  msg->rx_ip6 = htobe64(msg->rx_ip6);
  msg->rx_no_buffer = htobe64(msg->rx_no_buffer);
  msg->rx_miss = htobe64(msg->rx_miss);
  msg->rx_error = htobe64(msg->rx_error);
  msg->tx_error = htobe64(msg->tx_error);
  msg->rx_mpls = htobe64(msg->rx_mpls);
}

static inline void vapi_type_vnet_simple_counter_ntoh(vapi_type_vnet_simple_counter *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
  msg->drop = be64toh(msg->drop);
  msg->punt = be64toh(msg->punt);
  msg->rx_ip4 = be64toh(msg->rx_ip4);
  msg->rx_ip6 = be64toh(msg->rx_ip6);
  msg->rx_no_buffer = be64toh(msg->rx_no_buffer);
  msg->rx_miss = be64toh(msg->rx_miss);
  msg->rx_error = be64toh(msg->rx_error);
  msg->tx_error = be64toh(msg->tx_error);
  msg->rx_mpls = be64toh(msg->rx_mpls);
}

static inline void vapi_type_vnet_combined_counter_hton(vapi_type_vnet_combined_counter *msg)
{
  msg->sw_if_index = htobe32(msg->sw_if_index);
  msg->rx_packets = htobe64(msg->rx_packets);
  msg->rx_bytes = htobe64(msg->rx_bytes);
  msg->tx_packets = htobe64(msg->tx_packets);
  msg->tx_bytes = htobe64(msg->tx_bytes);
}

static inline void vapi_type_vnet_combined_counter_ntoh(vapi_type_vnet_combined_counter *msg)
{
  msg->sw_if_index = be32toh(msg->sw_if_index);
  msg->rx_packets = be64toh(msg->rx_packets);
  msg->rx_bytes = be64toh(msg->rx_bytes);
  msg->tx_packets = be64toh(msg->tx_packets);
  msg->tx_bytes = be64toh(msg->tx_bytes);
}

static inline void vapi_msg_vnet_interface_simple_counters_payload_hton(vapi_payload_vnet_interface_simple_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->first_sw_if_index = htobe32(payload->first_sw_if_index);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { payload->data[i] = htobe64(payload->data[i]); } } while(0);
}

static inline void vapi_msg_vnet_interface_simple_counters_payload_ntoh(vapi_payload_vnet_interface_simple_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->first_sw_if_index = be32toh(payload->first_sw_if_index);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { payload->data[i] = be64toh(payload->data[i]); } } while(0);
}

static inline uword vapi_calc_vnet_interface_simple_counters_msg_size(vapi_msg_vnet_interface_simple_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.data[0]);
}

static inline void vapi_msg_vnet_interface_simple_counters_hton(vapi_msg_vnet_interface_simple_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_interface_simple_counters'@%p to big endian", msg);

  vapi_msg_vnet_interface_simple_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_interface_simple_counters_ntoh(vapi_msg_vnet_interface_simple_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_interface_simple_counters'@%p to host byte order", msg);

  vapi_msg_vnet_interface_simple_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_table_reply_payload_hton(vapi_payload_sw_interface_set_table_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_table_reply_payload_ntoh(vapi_payload_sw_interface_set_table_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_table_reply_msg_size(vapi_msg_sw_interface_set_table_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_table_reply_hton(vapi_msg_sw_interface_set_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_table_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_table_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_table_reply_ntoh(vapi_msg_sw_interface_set_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_table_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_table_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_details_payload_hton(vapi_payload_sw_interface_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->sup_sw_if_index = htobe32(payload->sup_sw_if_index);
  payload->l2_address_length = htobe32(payload->l2_address_length);
  payload->link_mtu = htobe16(payload->link_mtu);
  payload->sub_id = htobe32(payload->sub_id);
  payload->sub_outer_vlan_id = htobe16(payload->sub_outer_vlan_id);
  payload->sub_inner_vlan_id = htobe16(payload->sub_inner_vlan_id);
  payload->vtr_op = htobe32(payload->vtr_op);
  payload->vtr_push_dot1q = htobe32(payload->vtr_push_dot1q);
  payload->vtr_tag1 = htobe32(payload->vtr_tag1);
  payload->vtr_tag2 = htobe32(payload->vtr_tag2);
  payload->outer_tag = htobe16(payload->outer_tag);
  payload->b_vlanid = htobe16(payload->b_vlanid);
  payload->i_sid = htobe32(payload->i_sid);
}

static inline void vapi_msg_sw_interface_details_payload_ntoh(vapi_payload_sw_interface_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->sup_sw_if_index = be32toh(payload->sup_sw_if_index);
  payload->l2_address_length = be32toh(payload->l2_address_length);
  payload->link_mtu = be16toh(payload->link_mtu);
  payload->sub_id = be32toh(payload->sub_id);
  payload->sub_outer_vlan_id = be16toh(payload->sub_outer_vlan_id);
  payload->sub_inner_vlan_id = be16toh(payload->sub_inner_vlan_id);
  payload->vtr_op = be32toh(payload->vtr_op);
  payload->vtr_push_dot1q = be32toh(payload->vtr_push_dot1q);
  payload->vtr_tag1 = be32toh(payload->vtr_tag1);
  payload->vtr_tag2 = be32toh(payload->vtr_tag2);
  payload->outer_tag = be16toh(payload->outer_tag);
  payload->b_vlanid = be16toh(payload->b_vlanid);
  payload->i_sid = be32toh(payload->i_sid);
}

static inline uword vapi_calc_sw_interface_details_msg_size(vapi_msg_sw_interface_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_details_hton(vapi_msg_sw_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_details_ntoh(vapi_msg_sw_interface_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_per_interface_simple_counters_payload_hton(vapi_payload_vnet_per_interface_simple_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->count = htobe32(payload->count);
  payload->timestamp = htobe32(payload->timestamp);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_vnet_simple_counter_hton(&payload->data[i]); } } while(0);
}

static inline void vapi_msg_vnet_per_interface_simple_counters_payload_ntoh(vapi_payload_vnet_per_interface_simple_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->count = be32toh(payload->count);
  payload->timestamp = be32toh(payload->timestamp);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_vnet_simple_counter_ntoh(&payload->data[i]); } } while(0);
}

static inline uword vapi_calc_vnet_per_interface_simple_counters_msg_size(vapi_msg_vnet_per_interface_simple_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.data[0]);
}

static inline void vapi_msg_vnet_per_interface_simple_counters_hton(vapi_msg_vnet_per_interface_simple_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_per_interface_simple_counters'@%p to big endian", msg);

  vapi_msg_vnet_per_interface_simple_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_per_interface_simple_counters_ntoh(vapi_msg_vnet_per_interface_simple_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_per_interface_simple_counters'@%p to host byte order", msg);

  vapi_msg_vnet_per_interface_simple_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_tag_add_del_payload_hton(vapi_payload_sw_interface_tag_add_del *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_tag_add_del_payload_ntoh(vapi_payload_sw_interface_tag_add_del *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_tag_add_del_msg_size(vapi_msg_sw_interface_tag_add_del *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_tag_add_del_hton(vapi_msg_sw_interface_tag_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_tag_add_del'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_tag_add_del_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_tag_add_del_ntoh(vapi_msg_sw_interface_tag_add_del *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_tag_add_del'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_tag_add_del_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_event_payload_hton(vapi_payload_sw_interface_event *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->client_index = htobe32(payload->client_index);
  payload->pid = htobe32(payload->pid);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_event_payload_ntoh(vapi_payload_sw_interface_event *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->client_index = be32toh(payload->client_index);
  payload->pid = be32toh(payload->pid);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_event_msg_size(vapi_msg_sw_interface_event *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_event_hton(vapi_msg_sw_interface_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_event'@%p to big endian", msg);

  vapi_msg_sw_interface_event_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_event_ntoh(vapi_msg_sw_interface_event *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_event'@%p to host byte order", msg);

  vapi_msg_sw_interface_event_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_get_table_reply_payload_hton(vapi_payload_sw_interface_get_table_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_sw_interface_get_table_reply_payload_ntoh(vapi_payload_sw_interface_get_table_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_sw_interface_get_table_reply_msg_size(vapi_msg_sw_interface_get_table_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_get_table_reply_hton(vapi_msg_sw_interface_get_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_get_table_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_get_table_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_get_table_reply_ntoh(vapi_msg_sw_interface_get_table_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_get_table_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_get_table_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_dump_payload_hton(vapi_payload_sw_interface_dump *payload)
{

}

static inline void vapi_msg_sw_interface_dump_payload_ntoh(vapi_payload_sw_interface_dump *payload)
{

}

static inline uword vapi_calc_sw_interface_dump_msg_size(vapi_msg_sw_interface_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_dump_hton(vapi_msg_sw_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_dump_ntoh(vapi_msg_sw_interface_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_events_reply_payload_hton(vapi_payload_want_interface_events_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_want_interface_events_reply_payload_ntoh(vapi_payload_want_interface_events_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_want_interface_events_reply_msg_size(vapi_msg_want_interface_events_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_events_reply_hton(vapi_msg_want_interface_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_events_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_want_interface_events_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_events_reply_ntoh(vapi_msg_want_interface_events_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_events_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_want_interface_events_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_clear_stats_reply_payload_hton(vapi_payload_sw_interface_clear_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_clear_stats_reply_payload_ntoh(vapi_payload_sw_interface_clear_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_clear_stats_reply_msg_size(vapi_msg_sw_interface_clear_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_clear_stats_reply_hton(vapi_msg_sw_interface_clear_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_clear_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_clear_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_clear_stats_reply_ntoh(vapi_msg_sw_interface_clear_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_clear_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_clear_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_interface_combined_counters_payload_hton(vapi_payload_vnet_interface_combined_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->first_sw_if_index = htobe32(payload->first_sw_if_index);
  payload->count = htobe32(payload->count);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_vlib_counter_hton(&payload->data[i]); } } while(0);
}

static inline void vapi_msg_vnet_interface_combined_counters_payload_ntoh(vapi_payload_vnet_interface_combined_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->first_sw_if_index = be32toh(payload->first_sw_if_index);
  payload->count = be32toh(payload->count);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_vlib_counter_ntoh(&payload->data[i]); } } while(0);
}

static inline uword vapi_calc_vnet_interface_combined_counters_msg_size(vapi_msg_vnet_interface_combined_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.data[0]);
}

static inline void vapi_msg_vnet_interface_combined_counters_hton(vapi_msg_vnet_interface_combined_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_interface_combined_counters'@%p to big endian", msg);

  vapi_msg_vnet_interface_combined_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_interface_combined_counters_ntoh(vapi_msg_vnet_interface_combined_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_interface_combined_counters'@%p to host byte order", msg);

  vapi_msg_vnet_interface_combined_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_vnet_per_interface_combined_counters_payload_hton(vapi_payload_vnet_per_interface_combined_counters *payload)
{
  payload->_vl_msg_id = htobe16(payload->_vl_msg_id);
  payload->count = htobe32(payload->count);
  payload->timestamp = htobe32(payload->timestamp);
  do { unsigned i; for (i = 0; i < be32toh(payload->count); ++i) { vapi_type_vnet_combined_counter_hton(&payload->data[i]); } } while(0);
}

static inline void vapi_msg_vnet_per_interface_combined_counters_payload_ntoh(vapi_payload_vnet_per_interface_combined_counters *payload)
{
  payload->_vl_msg_id = be16toh(payload->_vl_msg_id);
  payload->count = be32toh(payload->count);
  payload->timestamp = be32toh(payload->timestamp);
  do { unsigned i; for (i = 0; i < payload->count; ++i) { vapi_type_vnet_combined_counter_ntoh(&payload->data[i]); } } while(0);
}

static inline uword vapi_calc_vnet_per_interface_combined_counters_msg_size(vapi_msg_vnet_per_interface_combined_counters *msg)
{
  return sizeof(*msg)+ msg->payload.count * sizeof(msg->payload.data[0]);
}

static inline void vapi_msg_vnet_per_interface_combined_counters_hton(vapi_msg_vnet_per_interface_combined_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_per_interface_combined_counters'@%p to big endian", msg);

  vapi_msg_vnet_per_interface_combined_counters_payload_hton(&msg->payload);
}

static inline void vapi_msg_vnet_per_interface_combined_counters_ntoh(vapi_msg_vnet_per_interface_combined_counters *msg)
{
  VAPI_DBG("Swapping `vapi_msg_vnet_per_interface_combined_counters'@%p to host byte order", msg);

  vapi_msg_vnet_per_interface_combined_counters_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_add_del_address_payload_hton(vapi_payload_sw_interface_add_del_address *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_add_del_address_payload_ntoh(vapi_payload_sw_interface_add_del_address *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_add_del_address_msg_size(vapi_msg_sw_interface_add_del_address *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_add_del_address_hton(vapi_msg_sw_interface_add_del_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_add_del_address'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_add_del_address_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_add_del_address_ntoh(vapi_msg_sw_interface_add_del_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_add_del_address'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_add_del_address_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mac_address_reply_payload_hton(vapi_payload_sw_interface_set_mac_address_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_mac_address_reply_payload_ntoh(vapi_payload_sw_interface_set_mac_address_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_mac_address_reply_msg_size(vapi_msg_sw_interface_set_mac_address_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mac_address_reply_hton(vapi_msg_sw_interface_set_mac_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mac_address_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mac_address_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mac_address_reply_ntoh(vapi_msg_sw_interface_set_mac_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mac_address_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mac_address_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_unnumbered_reply_payload_hton(vapi_payload_sw_interface_set_unnumbered_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_unnumbered_reply_payload_ntoh(vapi_payload_sw_interface_set_unnumbered_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_unnumbered_reply_msg_size(vapi_msg_sw_interface_set_unnumbered_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_unnumbered_reply_hton(vapi_msg_sw_interface_set_unnumbered_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_unnumbered_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_unnumbered_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_unnumbered_reply_ntoh(vapi_msg_sw_interface_set_unnumbered_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_unnumbered_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_unnumbered_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_get_table_payload_hton(vapi_payload_sw_interface_get_table *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_get_table_payload_ntoh(vapi_payload_sw_interface_get_table *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_get_table_msg_size(vapi_msg_sw_interface_get_table *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_get_table_hton(vapi_msg_sw_interface_get_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_get_table'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_get_table_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_get_table_ntoh(vapi_msg_sw_interface_get_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_get_table'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_get_table_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mtu_payload_hton(vapi_payload_sw_interface_set_mtu *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->mtu = htobe16(payload->mtu);
}

static inline void vapi_msg_sw_interface_set_mtu_payload_ntoh(vapi_payload_sw_interface_set_mtu *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->mtu = be16toh(payload->mtu);
}

static inline uword vapi_calc_sw_interface_set_mtu_msg_size(vapi_msg_sw_interface_set_mtu *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mtu_hton(vapi_msg_sw_interface_set_mtu *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mtu'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mtu_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mtu_ntoh(vapi_msg_sw_interface_set_mtu *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mtu'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mtu_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_clear_stats_payload_hton(vapi_payload_sw_interface_clear_stats *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_clear_stats_payload_ntoh(vapi_payload_sw_interface_clear_stats *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_clear_stats_msg_size(vapi_msg_sw_interface_clear_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_clear_stats_hton(vapi_msg_sw_interface_clear_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_clear_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_clear_stats_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_clear_stats_ntoh(vapi_msg_sw_interface_clear_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_clear_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_clear_stats_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mtu_reply_payload_hton(vapi_payload_sw_interface_set_mtu_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_mtu_reply_payload_ntoh(vapi_payload_sw_interface_set_mtu_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_mtu_reply_msg_size(vapi_msg_sw_interface_set_mtu_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mtu_reply_hton(vapi_msg_sw_interface_set_mtu_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mtu_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mtu_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mtu_reply_ntoh(vapi_msg_sw_interface_set_mtu_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mtu_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mtu_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mac_address_payload_hton(vapi_payload_sw_interface_set_mac_address *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_set_mac_address_payload_ntoh(vapi_payload_sw_interface_set_mac_address *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_mac_address_msg_size(vapi_msg_sw_interface_set_mac_address *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_mac_address_hton(vapi_msg_sw_interface_set_mac_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mac_address'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_mac_address_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_mac_address_ntoh(vapi_msg_sw_interface_set_mac_address *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_mac_address'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_mac_address_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_unnumbered_payload_hton(vapi_payload_sw_interface_set_unnumbered *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->unnumbered_sw_if_index = htobe32(payload->unnumbered_sw_if_index);
}

static inline void vapi_msg_sw_interface_set_unnumbered_payload_ntoh(vapi_payload_sw_interface_set_unnumbered *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->unnumbered_sw_if_index = be32toh(payload->unnumbered_sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_unnumbered_msg_size(vapi_msg_sw_interface_set_unnumbered *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_unnumbered_hton(vapi_msg_sw_interface_set_unnumbered *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_unnumbered'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_unnumbered_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_unnumbered_ntoh(vapi_msg_sw_interface_set_unnumbered *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_unnumbered'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_unnumbered_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_flags_payload_hton(vapi_payload_sw_interface_set_flags *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_sw_interface_set_flags_payload_ntoh(vapi_payload_sw_interface_set_flags *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_sw_interface_set_flags_msg_size(vapi_msg_sw_interface_set_flags *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_flags_hton(vapi_msg_sw_interface_set_flags *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_flags'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_flags_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_flags_ntoh(vapi_msg_sw_interface_set_flags *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_flags'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_flags_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_add_del_address_reply_payload_hton(vapi_payload_sw_interface_add_del_address_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_add_del_address_reply_payload_ntoh(vapi_payload_sw_interface_add_del_address_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_add_del_address_reply_msg_size(vapi_msg_sw_interface_add_del_address_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_add_del_address_reply_hton(vapi_msg_sw_interface_add_del_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_add_del_address_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_add_del_address_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_add_del_address_reply_ntoh(vapi_msg_sw_interface_add_del_address_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_add_del_address_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_add_del_address_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_flags_reply_payload_hton(vapi_payload_sw_interface_set_flags_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_flags_reply_payload_ntoh(vapi_payload_sw_interface_set_flags_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_flags_reply_msg_size(vapi_msg_sw_interface_set_flags_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_flags_reply_hton(vapi_msg_sw_interface_set_flags_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_flags_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_flags_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_flags_reply_ntoh(vapi_msg_sw_interface_set_flags_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_flags_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_flags_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_want_interface_events_payload_hton(vapi_payload_want_interface_events *payload)
{
  payload->enable_disable = htobe32(payload->enable_disable);
  payload->pid = htobe32(payload->pid);
}

static inline void vapi_msg_want_interface_events_payload_ntoh(vapi_payload_want_interface_events *payload)
{
  payload->enable_disable = be32toh(payload->enable_disable);
  payload->pid = be32toh(payload->pid);
}

static inline uword vapi_calc_want_interface_events_msg_size(vapi_msg_want_interface_events *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_want_interface_events_hton(vapi_msg_want_interface_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_events'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_want_interface_events_payload_hton(&msg->payload);
}

static inline void vapi_msg_want_interface_events_ntoh(vapi_msg_want_interface_events *msg)
{
  VAPI_DBG("Swapping `vapi_msg_want_interface_events'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_want_interface_events_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_table_payload_hton(vapi_payload_sw_interface_set_table *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->vrf_id = htobe32(payload->vrf_id);
}

static inline void vapi_msg_sw_interface_set_table_payload_ntoh(vapi_payload_sw_interface_set_table *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->vrf_id = be32toh(payload->vrf_id);
}

static inline uword vapi_calc_sw_interface_set_table_msg_size(vapi_msg_sw_interface_set_table *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_table_hton(vapi_msg_sw_interface_set_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_table'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_table_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_table_ntoh(vapi_msg_sw_interface_set_table *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_table'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_table_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_tag_add_del_reply_payload_hton(vapi_payload_sw_interface_tag_add_del_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_tag_add_del_reply_payload_ntoh(vapi_payload_sw_interface_tag_add_del_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_tag_add_del_reply_msg_size(vapi_msg_sw_interface_tag_add_del_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_tag_add_del_reply_hton(vapi_msg_sw_interface_tag_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_tag_add_del_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_tag_add_del_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_tag_add_del_reply_ntoh(vapi_msg_sw_interface_tag_add_del_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_tag_add_del_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_tag_add_del_reply_payload_ntoh(&msg->payload);
}

static inline vapi_msg_sw_interface_tag_add_del* vapi_alloc_sw_interface_tag_add_del(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_tag_add_del *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_tag_add_del);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_tag_add_del*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_tag_add_del);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_tag_add_del(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_tag_add_del *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_tag_add_del_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_tag_add_del_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_tag_add_del_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_dump* vapi_alloc_sw_interface_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_dump);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_dump(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_add_del_address* vapi_alloc_sw_interface_add_del_address(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_add_del_address *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_add_del_address);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_add_del_address*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_add_del_address);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_add_del_address(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_add_del_address *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_add_del_address_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_add_del_address_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_add_del_address_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_get_table* vapi_alloc_sw_interface_get_table(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_get_table *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_get_table);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_get_table*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_get_table);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_get_table(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_get_table *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_get_table_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_get_table_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_get_table_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_mtu* vapi_alloc_sw_interface_set_mtu(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_mtu *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_mtu);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_mtu*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_mtu);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_mtu(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_mtu *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_mtu_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_mtu_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_mtu_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_clear_stats* vapi_alloc_sw_interface_clear_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_clear_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_clear_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_clear_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_clear_stats);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_clear_stats(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_clear_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_clear_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_clear_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_clear_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_mac_address* vapi_alloc_sw_interface_set_mac_address(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_mac_address *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_mac_address);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_mac_address*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_mac_address);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_mac_address(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_mac_address *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_mac_address_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_mac_address_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_mac_address_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_unnumbered* vapi_alloc_sw_interface_set_unnumbered(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_unnumbered *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_unnumbered);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_unnumbered*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_unnumbered);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_unnumbered(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_unnumbered *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_unnumbered_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_unnumbered_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_unnumbered_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_flags* vapi_alloc_sw_interface_set_flags(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_flags *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_flags);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_flags*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_flags);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_flags(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_flags *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_flags_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_flags_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_flags_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_want_interface_events* vapi_alloc_want_interface_events(struct vapi_ctx_s *ctx)
{
  vapi_msg_want_interface_events *msg = NULL;
  const size_t size = sizeof(vapi_msg_want_interface_events);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_want_interface_events*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_want_interface_events);

  return msg;
}

static inline vapi_error_e vapi_want_interface_events(struct vapi_ctx_s *ctx,
  vapi_msg_want_interface_events *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_want_interface_events_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_want_interface_events_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_want_interface_events_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_table* vapi_alloc_sw_interface_set_table(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_table *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_table);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_table*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_table);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_table(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_table *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_table_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_table_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_table_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_vnet_interface_simple_counters()
{
  static const char name[] = "vnet_interface_simple_counters";
  static const char name_with_crc[] = "vnet_interface_simple_counters_302f0983";
  static vapi_message_desc_t __vapi_metadata_vnet_interface_simple_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_interface_simple_counters, payload),
    sizeof(vapi_msg_vnet_interface_simple_counters),
    (generic_swap_fn_t)vapi_msg_vnet_interface_simple_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_interface_simple_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_interface_simple_counters = vapi_register_msg(&__vapi_metadata_vnet_interface_simple_counters);
  VAPI_DBG("Assigned msg id %d to vnet_interface_simple_counters", vapi_msg_id_vnet_interface_simple_counters);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_table_reply()
{
  static const char name[] = "sw_interface_set_table_reply";
  static const char name_with_crc[] = "sw_interface_set_table_reply_99df273c";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_table_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_table_reply, payload),
    sizeof(vapi_msg_sw_interface_set_table_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_table_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_table_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_table_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_table_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_table_reply", vapi_msg_id_sw_interface_set_table_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_details()
{
  static const char name[] = "sw_interface_details";
  static const char name_with_crc[] = "sw_interface_details_e2d855bb";
  static vapi_message_desc_t __vapi_metadata_sw_interface_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_details, payload),
    sizeof(vapi_msg_sw_interface_details),
    (generic_swap_fn_t)vapi_msg_sw_interface_details_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_details_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_details = vapi_register_msg(&__vapi_metadata_sw_interface_details);
  VAPI_DBG("Assigned msg id %d to sw_interface_details", vapi_msg_id_sw_interface_details);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_per_interface_simple_counters()
{
  static const char name[] = "vnet_per_interface_simple_counters";
  static const char name_with_crc[] = "vnet_per_interface_simple_counters_7df05633";
  static vapi_message_desc_t __vapi_metadata_vnet_per_interface_simple_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_per_interface_simple_counters, payload),
    sizeof(vapi_msg_vnet_per_interface_simple_counters),
    (generic_swap_fn_t)vapi_msg_vnet_per_interface_simple_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_per_interface_simple_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_per_interface_simple_counters = vapi_register_msg(&__vapi_metadata_vnet_per_interface_simple_counters);
  VAPI_DBG("Assigned msg id %d to vnet_per_interface_simple_counters", vapi_msg_id_vnet_per_interface_simple_counters);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_tag_add_del()
{
  static const char name[] = "sw_interface_tag_add_del";
  static const char name_with_crc[] = "sw_interface_tag_add_del_50ae8d92";
  static vapi_message_desc_t __vapi_metadata_sw_interface_tag_add_del = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_tag_add_del, payload),
    sizeof(vapi_msg_sw_interface_tag_add_del),
    (generic_swap_fn_t)vapi_msg_sw_interface_tag_add_del_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_tag_add_del_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_tag_add_del = vapi_register_msg(&__vapi_metadata_sw_interface_tag_add_del);
  VAPI_DBG("Assigned msg id %d to sw_interface_tag_add_del", vapi_msg_id_sw_interface_tag_add_del);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_event()
{
  static const char name[] = "sw_interface_event";
  static const char name_with_crc[] = "sw_interface_event_bf7f46f2";
  static vapi_message_desc_t __vapi_metadata_sw_interface_event = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_sw_interface_event, payload),
    sizeof(vapi_msg_sw_interface_event),
    (generic_swap_fn_t)vapi_msg_sw_interface_event_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_event_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_event = vapi_register_msg(&__vapi_metadata_sw_interface_event);
  VAPI_DBG("Assigned msg id %d to sw_interface_event", vapi_msg_id_sw_interface_event);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_get_table_reply()
{
  static const char name[] = "sw_interface_get_table_reply";
  static const char name_with_crc[] = "sw_interface_get_table_reply_ab44111d";
  static vapi_message_desc_t __vapi_metadata_sw_interface_get_table_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_get_table_reply, payload),
    sizeof(vapi_msg_sw_interface_get_table_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_get_table_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_get_table_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_get_table_reply = vapi_register_msg(&__vapi_metadata_sw_interface_get_table_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_get_table_reply", vapi_msg_id_sw_interface_get_table_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_dump()
{
  static const char name[] = "sw_interface_dump";
  static const char name_with_crc[] = "sw_interface_dump_9a2f9d4d";
  static vapi_message_desc_t __vapi_metadata_sw_interface_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_dump, payload),
    sizeof(vapi_msg_sw_interface_dump),
    (generic_swap_fn_t)vapi_msg_sw_interface_dump_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_dump_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_dump = vapi_register_msg(&__vapi_metadata_sw_interface_dump);
  VAPI_DBG("Assigned msg id %d to sw_interface_dump", vapi_msg_id_sw_interface_dump);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_events_reply()
{
  static const char name[] = "want_interface_events_reply";
  static const char name_with_crc[] = "want_interface_events_reply_33788c73";
  static vapi_message_desc_t __vapi_metadata_want_interface_events_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_want_interface_events_reply, payload),
    sizeof(vapi_msg_want_interface_events_reply),
    (generic_swap_fn_t)vapi_msg_want_interface_events_reply_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_events_reply_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_events_reply = vapi_register_msg(&__vapi_metadata_want_interface_events_reply);
  VAPI_DBG("Assigned msg id %d to want_interface_events_reply", vapi_msg_id_want_interface_events_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_clear_stats_reply()
{
  static const char name[] = "sw_interface_clear_stats_reply";
  static const char name_with_crc[] = "sw_interface_clear_stats_reply_21f50dd9";
  static vapi_message_desc_t __vapi_metadata_sw_interface_clear_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_clear_stats_reply, payload),
    sizeof(vapi_msg_sw_interface_clear_stats_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_clear_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_clear_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_clear_stats_reply = vapi_register_msg(&__vapi_metadata_sw_interface_clear_stats_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_clear_stats_reply", vapi_msg_id_sw_interface_clear_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_interface_combined_counters()
{
  static const char name[] = "vnet_interface_combined_counters";
  static const char name_with_crc[] = "vnet_interface_combined_counters_d82426e3";
  static vapi_message_desc_t __vapi_metadata_vnet_interface_combined_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_interface_combined_counters, payload),
    sizeof(vapi_msg_vnet_interface_combined_counters),
    (generic_swap_fn_t)vapi_msg_vnet_interface_combined_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_interface_combined_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_interface_combined_counters = vapi_register_msg(&__vapi_metadata_vnet_interface_combined_counters);
  VAPI_DBG("Assigned msg id %d to vnet_interface_combined_counters", vapi_msg_id_vnet_interface_combined_counters);
}

static void __attribute__((constructor)) __vapi_constructor_vnet_per_interface_combined_counters()
{
  static const char name[] = "vnet_per_interface_combined_counters";
  static const char name_with_crc[] = "vnet_per_interface_combined_counters_bf35dfbe";
  static vapi_message_desc_t __vapi_metadata_vnet_per_interface_combined_counters = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    false,
    0,
    offsetof(vapi_msg_vnet_per_interface_combined_counters, payload),
    sizeof(vapi_msg_vnet_per_interface_combined_counters),
    (generic_swap_fn_t)vapi_msg_vnet_per_interface_combined_counters_hton,
    (generic_swap_fn_t)vapi_msg_vnet_per_interface_combined_counters_ntoh,
    ~0,
  };

  vapi_msg_id_vnet_per_interface_combined_counters = vapi_register_msg(&__vapi_metadata_vnet_per_interface_combined_counters);
  VAPI_DBG("Assigned msg id %d to vnet_per_interface_combined_counters", vapi_msg_id_vnet_per_interface_combined_counters);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_add_del_address()
{
  static const char name[] = "sw_interface_add_del_address";
  static const char name_with_crc[] = "sw_interface_add_del_address_4e24d2df";
  static vapi_message_desc_t __vapi_metadata_sw_interface_add_del_address = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_add_del_address, payload),
    sizeof(vapi_msg_sw_interface_add_del_address),
    (generic_swap_fn_t)vapi_msg_sw_interface_add_del_address_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_add_del_address_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_add_del_address = vapi_register_msg(&__vapi_metadata_sw_interface_add_del_address);
  VAPI_DBG("Assigned msg id %d to sw_interface_add_del_address", vapi_msg_id_sw_interface_add_del_address);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mac_address_reply()
{
  static const char name[] = "sw_interface_set_mac_address_reply";
  static const char name_with_crc[] = "sw_interface_set_mac_address_reply_9dc8a452";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mac_address_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_mac_address_reply, payload),
    sizeof(vapi_msg_sw_interface_set_mac_address_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mac_address_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mac_address_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mac_address_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_mac_address_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mac_address_reply", vapi_msg_id_sw_interface_set_mac_address_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_unnumbered_reply()
{
  static const char name[] = "sw_interface_set_unnumbered_reply";
  static const char name_with_crc[] = "sw_interface_set_unnumbered_reply_5b2275e1";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_unnumbered_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_unnumbered_reply, payload),
    sizeof(vapi_msg_sw_interface_set_unnumbered_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_unnumbered_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_unnumbered_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_unnumbered_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_unnumbered_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_unnumbered_reply", vapi_msg_id_sw_interface_set_unnumbered_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_get_table()
{
  static const char name[] = "sw_interface_get_table";
  static const char name_with_crc[] = "sw_interface_get_table_f5a1d557";
  static vapi_message_desc_t __vapi_metadata_sw_interface_get_table = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_get_table, payload),
    sizeof(vapi_msg_sw_interface_get_table),
    (generic_swap_fn_t)vapi_msg_sw_interface_get_table_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_get_table_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_get_table = vapi_register_msg(&__vapi_metadata_sw_interface_get_table);
  VAPI_DBG("Assigned msg id %d to sw_interface_get_table", vapi_msg_id_sw_interface_get_table);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mtu()
{
  static const char name[] = "sw_interface_set_mtu";
  static const char name_with_crc[] = "sw_interface_set_mtu_535dab1d";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mtu = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_mtu, payload),
    sizeof(vapi_msg_sw_interface_set_mtu),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mtu_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mtu_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mtu = vapi_register_msg(&__vapi_metadata_sw_interface_set_mtu);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mtu", vapi_msg_id_sw_interface_set_mtu);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_clear_stats()
{
  static const char name[] = "sw_interface_clear_stats";
  static const char name_with_crc[] = "sw_interface_clear_stats_9600fd50";
  static vapi_message_desc_t __vapi_metadata_sw_interface_clear_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_clear_stats, payload),
    sizeof(vapi_msg_sw_interface_clear_stats),
    (generic_swap_fn_t)vapi_msg_sw_interface_clear_stats_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_clear_stats_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_clear_stats = vapi_register_msg(&__vapi_metadata_sw_interface_clear_stats);
  VAPI_DBG("Assigned msg id %d to sw_interface_clear_stats", vapi_msg_id_sw_interface_clear_stats);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mtu_reply()
{
  static const char name[] = "sw_interface_set_mtu_reply";
  static const char name_with_crc[] = "sw_interface_set_mtu_reply_0cc22552";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mtu_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_mtu_reply, payload),
    sizeof(vapi_msg_sw_interface_set_mtu_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mtu_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mtu_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mtu_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_mtu_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mtu_reply", vapi_msg_id_sw_interface_set_mtu_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_mac_address()
{
  static const char name[] = "sw_interface_set_mac_address";
  static const char name_with_crc[] = "sw_interface_set_mac_address_e4f22660";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_mac_address = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_mac_address, payload),
    sizeof(vapi_msg_sw_interface_set_mac_address),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mac_address_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_mac_address_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_mac_address = vapi_register_msg(&__vapi_metadata_sw_interface_set_mac_address);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_mac_address", vapi_msg_id_sw_interface_set_mac_address);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_unnumbered()
{
  static const char name[] = "sw_interface_set_unnumbered";
  static const char name_with_crc[] = "sw_interface_set_unnumbered_ee0047b0";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_unnumbered = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_unnumbered, payload),
    sizeof(vapi_msg_sw_interface_set_unnumbered),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_unnumbered_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_unnumbered_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_unnumbered = vapi_register_msg(&__vapi_metadata_sw_interface_set_unnumbered);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_unnumbered", vapi_msg_id_sw_interface_set_unnumbered);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_flags()
{
  static const char name[] = "sw_interface_set_flags";
  static const char name_with_crc[] = "sw_interface_set_flags_f890584a";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_flags = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_flags, payload),
    sizeof(vapi_msg_sw_interface_set_flags),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_flags_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_flags_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_flags = vapi_register_msg(&__vapi_metadata_sw_interface_set_flags);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_flags", vapi_msg_id_sw_interface_set_flags);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_add_del_address_reply()
{
  static const char name[] = "sw_interface_add_del_address_reply";
  static const char name_with_crc[] = "sw_interface_add_del_address_reply_abe29452";
  static vapi_message_desc_t __vapi_metadata_sw_interface_add_del_address_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_add_del_address_reply, payload),
    sizeof(vapi_msg_sw_interface_add_del_address_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_add_del_address_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_add_del_address_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_add_del_address_reply = vapi_register_msg(&__vapi_metadata_sw_interface_add_del_address_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_add_del_address_reply", vapi_msg_id_sw_interface_add_del_address_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_flags_reply()
{
  static const char name[] = "sw_interface_set_flags_reply";
  static const char name_with_crc[] = "sw_interface_set_flags_reply_dfbf3afa";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_flags_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_flags_reply, payload),
    sizeof(vapi_msg_sw_interface_set_flags_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_flags_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_flags_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_flags_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_flags_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_flags_reply", vapi_msg_id_sw_interface_set_flags_reply);
}

static void __attribute__((constructor)) __vapi_constructor_want_interface_events()
{
  static const char name[] = "want_interface_events";
  static const char name_with_crc[] = "want_interface_events_a0cbf57e";
  static vapi_message_desc_t __vapi_metadata_want_interface_events = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_want_interface_events, payload),
    sizeof(vapi_msg_want_interface_events),
    (generic_swap_fn_t)vapi_msg_want_interface_events_hton,
    (generic_swap_fn_t)vapi_msg_want_interface_events_ntoh,
    ~0,
  };

  vapi_msg_id_want_interface_events = vapi_register_msg(&__vapi_metadata_want_interface_events);
  VAPI_DBG("Assigned msg id %d to want_interface_events", vapi_msg_id_want_interface_events);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_table()
{
  static const char name[] = "sw_interface_set_table";
  static const char name_with_crc[] = "sw_interface_set_table_a94df510";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_table = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_table, payload),
    sizeof(vapi_msg_sw_interface_set_table),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_table_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_table_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_table = vapi_register_msg(&__vapi_metadata_sw_interface_set_table);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_table", vapi_msg_id_sw_interface_set_table);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_tag_add_del_reply()
{
  static const char name[] = "sw_interface_tag_add_del_reply";
  static const char name_with_crc[] = "sw_interface_tag_add_del_reply_761cbcb0";
  static vapi_message_desc_t __vapi_metadata_sw_interface_tag_add_del_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_tag_add_del_reply, payload),
    sizeof(vapi_msg_sw_interface_tag_add_del_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_tag_add_del_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_tag_add_del_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_tag_add_del_reply = vapi_register_msg(&__vapi_metadata_sw_interface_tag_add_del_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_tag_add_del_reply", vapi_msg_id_sw_interface_tag_add_del_reply);
}


static inline void vapi_set_vapi_msg_vnet_interface_simple_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_interface_simple_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_interface_simple_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_table_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_table_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_table_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_per_interface_simple_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_per_interface_simple_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_per_interface_simple_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_event_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_event *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_event, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_get_table_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_get_table_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_get_table_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_want_interface_events_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_want_interface_events_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_want_interface_events_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_clear_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_clear_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_clear_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_interface_combined_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_interface_combined_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_interface_combined_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_vnet_per_interface_combined_counters_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_vnet_per_interface_combined_counters *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_vnet_per_interface_combined_counters, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_mac_address_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_mac_address_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_mac_address_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_unnumbered_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_unnumbered_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_unnumbered_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_mtu_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_mtu_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_mtu_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_add_del_address_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_add_del_address_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_add_del_address_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_flags_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_flags_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_flags_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_tag_add_del_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_tag_add_del_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_tag_add_del_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
