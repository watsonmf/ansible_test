/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vnet/srv6/sr.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/srv6/sr.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_SR_LOCALSID_ADD_DEL, vl_api_sr_localsid_add_del_t_handler)
vl_msg_id(VL_API_SR_LOCALSID_ADD_DEL_REPLY, vl_api_sr_localsid_add_del_reply_t_handler)
vl_msg_id(VL_API_SR_POLICY_ADD, vl_api_sr_policy_add_t_handler)
vl_msg_id(VL_API_SR_POLICY_ADD_REPLY, vl_api_sr_policy_add_reply_t_handler)
vl_msg_id(VL_API_SR_POLICY_MOD, vl_api_sr_policy_mod_t_handler)
vl_msg_id(VL_API_SR_POLICY_MOD_REPLY, vl_api_sr_policy_mod_reply_t_handler)
vl_msg_id(VL_API_SR_POLICY_DEL, vl_api_sr_policy_del_t_handler)
vl_msg_id(VL_API_SR_POLICY_DEL_REPLY, vl_api_sr_policy_del_reply_t_handler)
vl_msg_id(VL_API_SR_STEERING_ADD_DEL, vl_api_sr_steering_add_del_t_handler)
vl_msg_id(VL_API_SR_STEERING_ADD_DEL_REPLY, vl_api_sr_steering_add_del_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_sr_localsid_add_del_t, 1)
vl_msg_name(vl_api_sr_localsid_add_del_reply_t, 1)
vl_msg_name(vl_api_sr_policy_add_t, 1)
vl_msg_name(vl_api_sr_policy_add_reply_t, 1)
vl_msg_name(vl_api_sr_policy_mod_t, 1)
vl_msg_name(vl_api_sr_policy_mod_reply_t, 1)
vl_msg_name(vl_api_sr_policy_del_t, 1)
vl_msg_name(vl_api_sr_policy_del_reply_t, 1)
vl_msg_name(vl_api_sr_steering_add_del_t, 1)
vl_msg_name(vl_api_sr_steering_add_del_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_sr \
_(VL_API_SR_LOCALSID_ADD_DEL, sr_localsid_add_del, ccf1dfb7) \
_(VL_API_SR_LOCALSID_ADD_DEL_REPLY, sr_localsid_add_del_reply, 8ed0f725) \
_(VL_API_SR_POLICY_ADD, sr_policy_add, d2c9c4a7) \
_(VL_API_SR_POLICY_ADD_REPLY, sr_policy_add_reply, 1fa4bf69) \
_(VL_API_SR_POLICY_MOD, sr_policy_mod, 66016cd3) \
_(VL_API_SR_POLICY_MOD_REPLY, sr_policy_mod_reply, e53e8c2a) \
_(VL_API_SR_POLICY_DEL, sr_policy_del, cc9e015e) \
_(VL_API_SR_POLICY_DEL_REPLY, sr_policy_del_reply, 3315338b) \
_(VL_API_SR_STEERING_ADD_DEL, sr_steering_add_del, 61da4dae) \
_(VL_API_SR_STEERING_ADD_DEL_REPLY, sr_steering_add_del_reply, 8461b882) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_sr_localsid_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_del;
    u8 localsid_addr[16];
    u8 end_psp;
    u8 behavior;
    u32 sw_if_index;
    u32 vlan_index;
    u32 fib_table;
    u8 nh_addr[16];
}) vl_api_sr_localsid_add_del_t;

typedef VL_API_PACKED(struct _vl_api_sr_localsid_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sr_localsid_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 bsid_addr[16];
    u32 weight;
    u8 is_encap;
    u8 type;
    u32 fib_table;
    u8 n_segments;
    u8 segments[0];
}) vl_api_sr_policy_add_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sr_policy_add_reply_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_mod {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 bsid_addr[16];
    u32 sr_policy_index;
    u32 fib_table;
    u8 operation;
    u32 sl_index;
    u32 weight;
    u8 n_segments;
    u8 segments[0];
}) vl_api_sr_policy_mod_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_mod_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sr_policy_mod_reply_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 bsid_addr[16];
    u32 sr_policy_index;
}) vl_api_sr_policy_del_t;

typedef VL_API_PACKED(struct _vl_api_sr_policy_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sr_policy_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_sr_steering_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_del;
    u8 bsid_addr[16];
    u32 sr_policy_index;
    u32 table_id;
    u8 prefix_addr[16];
    u32 mask_width;
    u32 sw_if_index;
    u8 traffic_type;
}) vl_api_sr_steering_add_del_t;

typedef VL_API_PACKED(struct _vl_api_sr_steering_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sr_steering_add_del_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_sr_localsid_add_del_t_print (vl_api_sr_localsid_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_localsid_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_del: %u\n", (unsigned) a->is_del);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "localsid_addr[%d]: %u\n", _i, a->localsid_addr[_i]);
        }
    }
    vl_print(handle, "end_psp: %u\n", (unsigned) a->end_psp);
    vl_print(handle, "behavior: %u\n", (unsigned) a->behavior);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "vlan_index: %u\n", (unsigned) a->vlan_index);
    vl_print(handle, "fib_table: %u\n", (unsigned) a->fib_table);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "nh_addr[%d]: %u\n", _i, a->nh_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sr_localsid_add_del_reply_t_print (vl_api_sr_localsid_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_localsid_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sr_policy_add_t_print (vl_api_sr_policy_add_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_add_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "bsid_addr[%d]: %u\n", _i, a->bsid_addr[_i]);
        }
    }
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    vl_print(handle, "is_encap: %u\n", (unsigned) a->is_encap);
    vl_print(handle, "type: %u\n", (unsigned) a->type);
    vl_print(handle, "fib_table: %u\n", (unsigned) a->fib_table);
    vl_print(handle, "n_segments: %u\n", (unsigned) a->n_segments);
    return handle;
}

static inline void *vl_api_sr_policy_add_reply_t_print (vl_api_sr_policy_add_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_add_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sr_policy_mod_t_print (vl_api_sr_policy_mod_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_mod_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "bsid_addr[%d]: %u\n", _i, a->bsid_addr[_i]);
        }
    }
    vl_print(handle, "sr_policy_index: %u\n", (unsigned) a->sr_policy_index);
    vl_print(handle, "fib_table: %u\n", (unsigned) a->fib_table);
    vl_print(handle, "operation: %u\n", (unsigned) a->operation);
    vl_print(handle, "sl_index: %u\n", (unsigned) a->sl_index);
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    vl_print(handle, "n_segments: %u\n", (unsigned) a->n_segments);
    return handle;
}

static inline void *vl_api_sr_policy_mod_reply_t_print (vl_api_sr_policy_mod_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_mod_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sr_policy_del_t_print (vl_api_sr_policy_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "bsid_addr[%d]: %u\n", _i, a->bsid_addr[_i]);
        }
    }
    vl_print(handle, "sr_policy_index: %u\n", (unsigned) a->sr_policy_index);
    return handle;
}

static inline void *vl_api_sr_policy_del_reply_t_print (vl_api_sr_policy_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_policy_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sr_steering_add_del_t_print (vl_api_sr_steering_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_steering_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_del: %u\n", (unsigned) a->is_del);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "bsid_addr[%d]: %u\n", _i, a->bsid_addr[_i]);
        }
    }
    vl_print(handle, "sr_policy_index: %u\n", (unsigned) a->sr_policy_index);
    vl_print(handle, "table_id: %u\n", (unsigned) a->table_id);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "prefix_addr[%d]: %u\n", _i, a->prefix_addr[_i]);
        }
    }
    vl_print(handle, "mask_width: %u\n", (unsigned) a->mask_width);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "traffic_type: %u\n", (unsigned) a->traffic_type);
    return handle;
}

static inline void *vl_api_sr_steering_add_del_reply_t_print (vl_api_sr_steering_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sr_steering_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_sr_localsid_add_del_t_endian (vl_api_sr_localsid_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_del = a->is_del (no-op) */
    /* a->localsid_addr[0..15] = a->localsid_addr[0..15] (no-op) */
    /* a->end_psp = a->end_psp (no-op) */
    /* a->behavior = a->behavior (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->vlan_index = clib_net_to_host_u32(a->vlan_index);
    a->fib_table = clib_net_to_host_u32(a->fib_table);
    /* a->nh_addr[0..15] = a->nh_addr[0..15] (no-op) */
}

static inline void vl_api_sr_localsid_add_del_reply_t_endian (vl_api_sr_localsid_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sr_policy_add_t_endian (vl_api_sr_policy_add_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->bsid_addr[0..15] = a->bsid_addr[0..15] (no-op) */
    a->weight = clib_net_to_host_u32(a->weight);
    /* a->is_encap = a->is_encap (no-op) */
    /* a->type = a->type (no-op) */
    a->fib_table = clib_net_to_host_u32(a->fib_table);
    /* a->n_segments = a->n_segments (no-op) */
}

static inline void vl_api_sr_policy_add_reply_t_endian (vl_api_sr_policy_add_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sr_policy_mod_t_endian (vl_api_sr_policy_mod_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->bsid_addr[0..15] = a->bsid_addr[0..15] (no-op) */
    a->sr_policy_index = clib_net_to_host_u32(a->sr_policy_index);
    a->fib_table = clib_net_to_host_u32(a->fib_table);
    /* a->operation = a->operation (no-op) */
    a->sl_index = clib_net_to_host_u32(a->sl_index);
    a->weight = clib_net_to_host_u32(a->weight);
    /* a->n_segments = a->n_segments (no-op) */
}

static inline void vl_api_sr_policy_mod_reply_t_endian (vl_api_sr_policy_mod_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sr_policy_del_t_endian (vl_api_sr_policy_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->bsid_addr[0..15] = a->bsid_addr[0..15] (no-op) */
    a->sr_policy_index = clib_net_to_host_u32(a->sr_policy_index);
}

static inline void vl_api_sr_policy_del_reply_t_endian (vl_api_sr_policy_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sr_steering_add_del_t_endian (vl_api_sr_steering_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_del = a->is_del (no-op) */
    /* a->bsid_addr[0..15] = a->bsid_addr[0..15] (no-op) */
    a->sr_policy_index = clib_net_to_host_u32(a->sr_policy_index);
    a->table_id = clib_net_to_host_u32(a->table_id);
    /* a->prefix_addr[0..15] = a->prefix_addr[0..15] (no-op) */
    a->mask_width = clib_net_to_host_u32(a->mask_width);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->traffic_type = a->traffic_type (no-op) */
}

static inline void vl_api_sr_steering_add_del_reply_t_endian (vl_api_sr_steering_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(sr.api, 0x430b3265)

#endif

