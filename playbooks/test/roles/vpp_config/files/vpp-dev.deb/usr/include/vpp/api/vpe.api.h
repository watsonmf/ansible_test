/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vpp/api/vpe.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vpp/api/vpe.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_CREATE_VLAN_SUBIF, vl_api_create_vlan_subif_t_handler)
vl_msg_id(VL_API_CREATE_VLAN_SUBIF_REPLY, vl_api_create_vlan_subif_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MPLS_ENABLE, vl_api_sw_interface_set_mpls_enable_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MPLS_ENABLE_REPLY, vl_api_sw_interface_set_mpls_enable_reply_t_handler)
vl_msg_id(VL_API_PROXY_ARP_ADD_DEL, vl_api_proxy_arp_add_del_t_handler)
vl_msg_id(VL_API_PROXY_ARP_ADD_DEL_REPLY, vl_api_proxy_arp_add_del_reply_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE, vl_api_proxy_arp_intfc_enable_disable_t_handler)
vl_msg_id(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE_REPLY, vl_api_proxy_arp_intfc_enable_disable_reply_t_handler)
vl_msg_id(VL_API_RESET_VRF, vl_api_reset_vrf_t_handler)
vl_msg_id(VL_API_RESET_VRF_REPLY, vl_api_reset_vrf_reply_t_handler)
vl_msg_id(VL_API_OAM_EVENT, vl_api_oam_event_t_handler)
vl_msg_id(VL_API_WANT_OAM_EVENTS, vl_api_want_oam_events_t_handler)
vl_msg_id(VL_API_WANT_OAM_EVENTS_REPLY, vl_api_want_oam_events_reply_t_handler)
vl_msg_id(VL_API_OAM_ADD_DEL, vl_api_oam_add_del_t_handler)
vl_msg_id(VL_API_OAM_ADD_DEL_REPLY, vl_api_oam_add_del_reply_t_handler)
vl_msg_id(VL_API_RESET_FIB, vl_api_reset_fib_t_handler)
vl_msg_id(VL_API_RESET_FIB_REPLY, vl_api_reset_fib_reply_t_handler)
vl_msg_id(VL_API_CREATE_LOOPBACK, vl_api_create_loopback_t_handler)
vl_msg_id(VL_API_CREATE_LOOPBACK_REPLY, vl_api_create_loopback_reply_t_handler)
vl_msg_id(VL_API_CREATE_LOOPBACK_INSTANCE, vl_api_create_loopback_instance_t_handler)
vl_msg_id(VL_API_CREATE_LOOPBACK_INSTANCE_REPLY, vl_api_create_loopback_instance_reply_t_handler)
vl_msg_id(VL_API_DELETE_LOOPBACK, vl_api_delete_loopback_t_handler)
vl_msg_id(VL_API_DELETE_LOOPBACK_REPLY, vl_api_delete_loopback_reply_t_handler)
vl_msg_id(VL_API_CONTROL_PING, vl_api_control_ping_t_handler)
vl_msg_id(VL_API_CONTROL_PING_REPLY, vl_api_control_ping_reply_t_handler)
vl_msg_id(VL_API_CLI, vl_api_cli_t_handler)
vl_msg_id(VL_API_CLI_INBAND, vl_api_cli_inband_t_handler)
vl_msg_id(VL_API_CLI_REPLY, vl_api_cli_reply_t_handler)
vl_msg_id(VL_API_CLI_INBAND_REPLY, vl_api_cli_inband_reply_t_handler)
vl_msg_id(VL_API_SET_ARP_NEIGHBOR_LIMIT, vl_api_set_arp_neighbor_limit_t_handler)
vl_msg_id(VL_API_SET_ARP_NEIGHBOR_LIMIT_REPLY, vl_api_set_arp_neighbor_limit_reply_t_handler)
vl_msg_id(VL_API_L2_PATCH_ADD_DEL, vl_api_l2_patch_add_del_t_handler)
vl_msg_id(VL_API_L2_PATCH_ADD_DEL_REPLY, vl_api_l2_patch_add_del_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_VPATH, vl_api_sw_interface_set_vpath_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_VPATH_REPLY, vl_api_sw_interface_set_vpath_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_L2_XCONNECT, vl_api_sw_interface_set_l2_xconnect_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_L2_XCONNECT_REPLY, vl_api_sw_interface_set_l2_xconnect_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_L2_BRIDGE, vl_api_sw_interface_set_l2_bridge_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_L2_BRIDGE_REPLY, vl_api_sw_interface_set_l2_bridge_reply_t_handler)
vl_msg_id(VL_API_BD_IP_MAC_ADD_DEL, vl_api_bd_ip_mac_add_del_t_handler)
vl_msg_id(VL_API_BD_IP_MAC_ADD_DEL_REPLY, vl_api_bd_ip_mac_add_del_reply_t_handler)
vl_msg_id(VL_API_CLASSIFY_SET_INTERFACE_IP_TABLE, vl_api_classify_set_interface_ip_table_t_handler)
vl_msg_id(VL_API_CLASSIFY_SET_INTERFACE_IP_TABLE_REPLY, vl_api_classify_set_interface_ip_table_reply_t_handler)
vl_msg_id(VL_API_CLASSIFY_SET_INTERFACE_L2_TABLES, vl_api_classify_set_interface_l2_tables_t_handler)
vl_msg_id(VL_API_CLASSIFY_SET_INTERFACE_L2_TABLES_REPLY, vl_api_classify_set_interface_l2_tables_reply_t_handler)
vl_msg_id(VL_API_GET_NODE_INDEX, vl_api_get_node_index_t_handler)
vl_msg_id(VL_API_GET_NODE_INDEX_REPLY, vl_api_get_node_index_reply_t_handler)
vl_msg_id(VL_API_ADD_NODE_NEXT, vl_api_add_node_next_t_handler)
vl_msg_id(VL_API_ADD_NODE_NEXT_REPLY, vl_api_add_node_next_reply_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_EFP_FILTER, vl_api_l2_interface_efp_filter_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_EFP_FILTER_REPLY, vl_api_l2_interface_efp_filter_reply_t_handler)
vl_msg_id(VL_API_CREATE_SUBIF, vl_api_create_subif_t_handler)
vl_msg_id(VL_API_CREATE_SUBIF_REPLY, vl_api_create_subif_reply_t_handler)
vl_msg_id(VL_API_SHOW_VERSION, vl_api_show_version_t_handler)
vl_msg_id(VL_API_SHOW_VERSION_REPLY, vl_api_show_version_reply_t_handler)
vl_msg_id(VL_API_INTERFACE_NAME_RENUMBER, vl_api_interface_name_renumber_t_handler)
vl_msg_id(VL_API_INTERFACE_NAME_RENUMBER_REPLY, vl_api_interface_name_renumber_reply_t_handler)
vl_msg_id(VL_API_WANT_IP4_ARP_EVENTS, vl_api_want_ip4_arp_events_t_handler)
vl_msg_id(VL_API_WANT_IP4_ARP_EVENTS_REPLY, vl_api_want_ip4_arp_events_reply_t_handler)
vl_msg_id(VL_API_IP4_ARP_EVENT, vl_api_ip4_arp_event_t_handler)
vl_msg_id(VL_API_WANT_IP6_ND_EVENTS, vl_api_want_ip6_nd_events_t_handler)
vl_msg_id(VL_API_WANT_IP6_ND_EVENTS_REPLY, vl_api_want_ip6_nd_events_reply_t_handler)
vl_msg_id(VL_API_IP6_ND_EVENT, vl_api_ip6_nd_event_t_handler)
vl_msg_id(VL_API_INPUT_ACL_SET_INTERFACE, vl_api_input_acl_set_interface_t_handler)
vl_msg_id(VL_API_INPUT_ACL_SET_INTERFACE_REPLY, vl_api_input_acl_set_interface_reply_t_handler)
vl_msg_id(VL_API_GET_NODE_GRAPH, vl_api_get_node_graph_t_handler)
vl_msg_id(VL_API_GET_NODE_GRAPH_REPLY, vl_api_get_node_graph_reply_t_handler)
vl_msg_id(VL_API_IOAM_ENABLE, vl_api_ioam_enable_t_handler)
vl_msg_id(VL_API_IOAM_ENABLE_REPLY, vl_api_ioam_enable_reply_t_handler)
vl_msg_id(VL_API_IOAM_DISABLE, vl_api_ioam_disable_t_handler)
vl_msg_id(VL_API_IOAM_DISABLE_REPLY, vl_api_ioam_disable_reply_t_handler)
vl_msg_id(VL_API_GET_NEXT_INDEX, vl_api_get_next_index_t_handler)
vl_msg_id(VL_API_GET_NEXT_INDEX_REPLY, vl_api_get_next_index_reply_t_handler)
vl_msg_id(VL_API_PG_CREATE_INTERFACE, vl_api_pg_create_interface_t_handler)
vl_msg_id(VL_API_PG_CREATE_INTERFACE_REPLY, vl_api_pg_create_interface_reply_t_handler)
vl_msg_id(VL_API_PG_CAPTURE, vl_api_pg_capture_t_handler)
vl_msg_id(VL_API_PG_CAPTURE_REPLY, vl_api_pg_capture_reply_t_handler)
vl_msg_id(VL_API_PG_ENABLE_DISABLE, vl_api_pg_enable_disable_t_handler)
vl_msg_id(VL_API_PG_ENABLE_DISABLE_REPLY, vl_api_pg_enable_disable_reply_t_handler)
vl_msg_id(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_ADD_DEL, vl_api_ip_source_and_port_range_check_add_del_t_handler)
vl_msg_id(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_ADD_DEL_REPLY, vl_api_ip_source_and_port_range_check_add_del_reply_t_handler)
vl_msg_id(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_INTERFACE_ADD_DEL, vl_api_ip_source_and_port_range_check_interface_add_del_t_handler)
vl_msg_id(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_INTERFACE_ADD_DEL_REPLY, vl_api_ip_source_and_port_range_check_interface_add_del_reply_t_handler)
vl_msg_id(VL_API_DELETE_SUBIF, vl_api_delete_subif_t_handler)
vl_msg_id(VL_API_DELETE_SUBIF_REPLY, vl_api_delete_subif_reply_t_handler)
vl_msg_id(VL_API_PUNT, vl_api_punt_t_handler)
vl_msg_id(VL_API_PUNT_REPLY, vl_api_punt_reply_t_handler)
vl_msg_id(VL_API_PUNT_SOCKET_REGISTER, vl_api_punt_socket_register_t_handler)
vl_msg_id(VL_API_PUNT_SOCKET_REGISTER_REPLY, vl_api_punt_socket_register_reply_t_handler)
vl_msg_id(VL_API_PUNT_SOCKET_DEREGISTER, vl_api_punt_socket_deregister_t_handler)
vl_msg_id(VL_API_PUNT_SOCKET_DEREGISTER_REPLY, vl_api_punt_socket_deregister_reply_t_handler)
vl_msg_id(VL_API_FEATURE_ENABLE_DISABLE, vl_api_feature_enable_disable_t_handler)
vl_msg_id(VL_API_FEATURE_ENABLE_DISABLE_REPLY, vl_api_feature_enable_disable_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_create_vlan_subif_t, 1)
vl_msg_name(vl_api_create_vlan_subif_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_mpls_enable_t, 1)
vl_msg_name(vl_api_sw_interface_set_mpls_enable_reply_t, 1)
vl_msg_name(vl_api_proxy_arp_add_del_t, 1)
vl_msg_name(vl_api_proxy_arp_add_del_reply_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_enable_disable_t, 1)
vl_msg_name(vl_api_proxy_arp_intfc_enable_disable_reply_t, 1)
vl_msg_name(vl_api_reset_vrf_t, 1)
vl_msg_name(vl_api_reset_vrf_reply_t, 1)
vl_msg_name(vl_api_oam_event_t, 1)
vl_msg_name(vl_api_want_oam_events_t, 1)
vl_msg_name(vl_api_want_oam_events_reply_t, 1)
vl_msg_name(vl_api_oam_add_del_t, 1)
vl_msg_name(vl_api_oam_add_del_reply_t, 1)
vl_msg_name(vl_api_reset_fib_t, 1)
vl_msg_name(vl_api_reset_fib_reply_t, 1)
vl_msg_name(vl_api_create_loopback_t, 1)
vl_msg_name(vl_api_create_loopback_reply_t, 1)
vl_msg_name(vl_api_create_loopback_instance_t, 1)
vl_msg_name(vl_api_create_loopback_instance_reply_t, 1)
vl_msg_name(vl_api_delete_loopback_t, 1)
vl_msg_name(vl_api_delete_loopback_reply_t, 1)
vl_msg_name(vl_api_control_ping_t, 1)
vl_msg_name(vl_api_control_ping_reply_t, 1)
vl_msg_name(vl_api_cli_t, 1)
vl_msg_name(vl_api_cli_inband_t, 1)
vl_msg_name(vl_api_cli_reply_t, 1)
vl_msg_name(vl_api_cli_inband_reply_t, 1)
vl_msg_name(vl_api_set_arp_neighbor_limit_t, 1)
vl_msg_name(vl_api_set_arp_neighbor_limit_reply_t, 1)
vl_msg_name(vl_api_l2_patch_add_del_t, 1)
vl_msg_name(vl_api_l2_patch_add_del_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_vpath_t, 1)
vl_msg_name(vl_api_sw_interface_set_vpath_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_l2_xconnect_t, 1)
vl_msg_name(vl_api_sw_interface_set_l2_xconnect_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_l2_bridge_t, 1)
vl_msg_name(vl_api_sw_interface_set_l2_bridge_reply_t, 1)
vl_msg_name(vl_api_bd_ip_mac_add_del_t, 1)
vl_msg_name(vl_api_bd_ip_mac_add_del_reply_t, 1)
vl_msg_name(vl_api_classify_set_interface_ip_table_t, 1)
vl_msg_name(vl_api_classify_set_interface_ip_table_reply_t, 1)
vl_msg_name(vl_api_classify_set_interface_l2_tables_t, 1)
vl_msg_name(vl_api_classify_set_interface_l2_tables_reply_t, 1)
vl_msg_name(vl_api_get_node_index_t, 1)
vl_msg_name(vl_api_get_node_index_reply_t, 1)
vl_msg_name(vl_api_add_node_next_t, 1)
vl_msg_name(vl_api_add_node_next_reply_t, 1)
vl_msg_name(vl_api_l2_interface_efp_filter_t, 1)
vl_msg_name(vl_api_l2_interface_efp_filter_reply_t, 1)
vl_msg_name(vl_api_create_subif_t, 1)
vl_msg_name(vl_api_create_subif_reply_t, 1)
vl_msg_name(vl_api_show_version_t, 1)
vl_msg_name(vl_api_show_version_reply_t, 1)
vl_msg_name(vl_api_interface_name_renumber_t, 1)
vl_msg_name(vl_api_interface_name_renumber_reply_t, 1)
vl_msg_name(vl_api_want_ip4_arp_events_t, 1)
vl_msg_name(vl_api_want_ip4_arp_events_reply_t, 1)
vl_msg_name(vl_api_ip4_arp_event_t, 1)
vl_msg_name(vl_api_want_ip6_nd_events_t, 1)
vl_msg_name(vl_api_want_ip6_nd_events_reply_t, 1)
vl_msg_name(vl_api_ip6_nd_event_t, 1)
vl_msg_name(vl_api_input_acl_set_interface_t, 1)
vl_msg_name(vl_api_input_acl_set_interface_reply_t, 1)
vl_msg_name(vl_api_get_node_graph_t, 1)
vl_msg_name(vl_api_get_node_graph_reply_t, 1)
vl_msg_name(vl_api_ioam_enable_t, 1)
vl_msg_name(vl_api_ioam_enable_reply_t, 1)
vl_msg_name(vl_api_ioam_disable_t, 1)
vl_msg_name(vl_api_ioam_disable_reply_t, 1)
vl_msg_name(vl_api_get_next_index_t, 1)
vl_msg_name(vl_api_get_next_index_reply_t, 1)
vl_msg_name(vl_api_pg_create_interface_t, 1)
vl_msg_name(vl_api_pg_create_interface_reply_t, 1)
vl_msg_name(vl_api_pg_capture_t, 1)
vl_msg_name(vl_api_pg_capture_reply_t, 1)
vl_msg_name(vl_api_pg_enable_disable_t, 1)
vl_msg_name(vl_api_pg_enable_disable_reply_t, 1)
vl_msg_name(vl_api_ip_source_and_port_range_check_add_del_t, 1)
vl_msg_name(vl_api_ip_source_and_port_range_check_add_del_reply_t, 1)
vl_msg_name(vl_api_ip_source_and_port_range_check_interface_add_del_t, 1)
vl_msg_name(vl_api_ip_source_and_port_range_check_interface_add_del_reply_t, 1)
vl_msg_name(vl_api_delete_subif_t, 1)
vl_msg_name(vl_api_delete_subif_reply_t, 1)
vl_msg_name(vl_api_punt_t, 1)
vl_msg_name(vl_api_punt_reply_t, 1)
vl_msg_name(vl_api_punt_socket_register_t, 1)
vl_msg_name(vl_api_punt_socket_register_reply_t, 1)
vl_msg_name(vl_api_punt_socket_deregister_t, 1)
vl_msg_name(vl_api_punt_socket_deregister_reply_t, 1)
vl_msg_name(vl_api_feature_enable_disable_t, 1)
vl_msg_name(vl_api_feature_enable_disable_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_vpe \
_(VL_API_CREATE_VLAN_SUBIF, create_vlan_subif, af9ae1e9) \
_(VL_API_CREATE_VLAN_SUBIF_REPLY, create_vlan_subif_reply, 8f36b888) \
_(VL_API_SW_INTERFACE_SET_MPLS_ENABLE, sw_interface_set_mpls_enable, 37f6357e) \
_(VL_API_SW_INTERFACE_SET_MPLS_ENABLE_REPLY, sw_interface_set_mpls_enable_reply, 5ffd3ca9) \
_(VL_API_PROXY_ARP_ADD_DEL, proxy_arp_add_del, 4bef9951) \
_(VL_API_PROXY_ARP_ADD_DEL_REPLY, proxy_arp_add_del_reply, 8e2d621d) \
_(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE, proxy_arp_intfc_enable_disable, 3ee1998e) \
_(VL_API_PROXY_ARP_INTFC_ENABLE_DISABLE_REPLY, proxy_arp_intfc_enable_disable_reply, 23d273cd) \
_(VL_API_RESET_VRF, reset_vrf, eb07deb0) \
_(VL_API_RESET_VRF_REPLY, reset_vrf_reply, 5f283863) \
_(VL_API_OAM_EVENT, oam_event, 4f285ade) \
_(VL_API_WANT_OAM_EVENTS, want_oam_events, 948ef12a) \
_(VL_API_WANT_OAM_EVENTS_REPLY, want_oam_events_reply, 266a677d) \
_(VL_API_OAM_ADD_DEL, oam_add_del, b14bc7df) \
_(VL_API_OAM_ADD_DEL_REPLY, oam_add_del_reply, c5594eec) \
_(VL_API_RESET_FIB, reset_fib, 6f17106b) \
_(VL_API_RESET_FIB_REPLY, reset_fib_reply, 990dcbf8) \
_(VL_API_CREATE_LOOPBACK, create_loopback, b2602de5) \
_(VL_API_CREATE_LOOPBACK_REPLY, create_loopback_reply, 9520f804) \
_(VL_API_CREATE_LOOPBACK_INSTANCE, create_loopback_instance, 967694f1) \
_(VL_API_CREATE_LOOPBACK_INSTANCE_REPLY, create_loopback_instance_reply, d52c63b6) \
_(VL_API_DELETE_LOOPBACK, delete_loopback, ded428b0) \
_(VL_API_DELETE_LOOPBACK_REPLY, delete_loopback_reply, c91dafa5) \
_(VL_API_CONTROL_PING, control_ping, ea1bf4f7) \
_(VL_API_CONTROL_PING_REPLY, control_ping_reply, aa016e7b) \
_(VL_API_CLI, cli, 543d8e2e) \
_(VL_API_CLI_INBAND, cli_inband, 22345937) \
_(VL_API_CLI_REPLY, cli_reply, 594a0b2e) \
_(VL_API_CLI_INBAND_REPLY, cli_inband_reply, c1835761) \
_(VL_API_SET_ARP_NEIGHBOR_LIMIT, set_arp_neighbor_limit, c1690cb4) \
_(VL_API_SET_ARP_NEIGHBOR_LIMIT_REPLY, set_arp_neighbor_limit_reply, a6b30518) \
_(VL_API_L2_PATCH_ADD_DEL, l2_patch_add_del, 9b10029a) \
_(VL_API_L2_PATCH_ADD_DEL_REPLY, l2_patch_add_del_reply, a85e37be) \
_(VL_API_SW_INTERFACE_SET_VPATH, sw_interface_set_vpath, 1bc2fd5e) \
_(VL_API_SW_INTERFACE_SET_VPATH_REPLY, sw_interface_set_vpath_reply, 828dbe62) \
_(VL_API_SW_INTERFACE_SET_L2_XCONNECT, sw_interface_set_l2_xconnect, 48a4c4c8) \
_(VL_API_SW_INTERFACE_SET_L2_XCONNECT_REPLY, sw_interface_set_l2_xconnect_reply, 6e45eed4) \
_(VL_API_SW_INTERFACE_SET_L2_BRIDGE, sw_interface_set_l2_bridge, 36c739e8) \
_(VL_API_SW_INTERFACE_SET_L2_BRIDGE_REPLY, sw_interface_set_l2_bridge_reply, 347e08d9) \
_(VL_API_BD_IP_MAC_ADD_DEL, bd_ip_mac_add_del, ad819817) \
_(VL_API_BD_IP_MAC_ADD_DEL_REPLY, bd_ip_mac_add_del_reply, 55bab3b4) \
_(VL_API_CLASSIFY_SET_INTERFACE_IP_TABLE, classify_set_interface_ip_table, 0dc45308) \
_(VL_API_CLASSIFY_SET_INTERFACE_IP_TABLE_REPLY, classify_set_interface_ip_table_reply, dc391c34) \
_(VL_API_CLASSIFY_SET_INTERFACE_L2_TABLES, classify_set_interface_l2_tables, ed9ccf0d) \
_(VL_API_CLASSIFY_SET_INTERFACE_L2_TABLES_REPLY, classify_set_interface_l2_tables_reply, 8df20579) \
_(VL_API_GET_NODE_INDEX, get_node_index, 226d3f8c) \
_(VL_API_GET_NODE_INDEX_REPLY, get_node_index_reply, 29116865) \
_(VL_API_ADD_NODE_NEXT, add_node_next, e4202993) \
_(VL_API_ADD_NODE_NEXT_REPLY, add_node_next_reply, e89d6eed) \
_(VL_API_L2_INTERFACE_EFP_FILTER, l2_interface_efp_filter, 07c9d601) \
_(VL_API_L2_INTERFACE_EFP_FILTER_REPLY, l2_interface_efp_filter_reply, 0f4bb0c0) \
_(VL_API_CREATE_SUBIF, create_subif, 150e6757) \
_(VL_API_CREATE_SUBIF_REPLY, create_subif_reply, 92272bcb) \
_(VL_API_SHOW_VERSION, show_version, f18f9480) \
_(VL_API_SHOW_VERSION_REPLY, show_version_reply, 83186d9e) \
_(VL_API_INTERFACE_NAME_RENUMBER, interface_name_renumber, 11b7bcec) \
_(VL_API_INTERFACE_NAME_RENUMBER_REPLY, interface_name_renumber_reply, 31594963) \
_(VL_API_WANT_IP4_ARP_EVENTS, want_ip4_arp_events, 5ae044c2) \
_(VL_API_WANT_IP4_ARP_EVENTS_REPLY, want_ip4_arp_events_reply, e1c0b59e) \
_(VL_API_IP4_ARP_EVENT, ip4_arp_event, 79b2d94d) \
_(VL_API_WANT_IP6_ND_EVENTS, want_ip6_nd_events, 9586ba55) \
_(VL_API_WANT_IP6_ND_EVENTS_REPLY, want_ip6_nd_events_reply, 95458aad) \
_(VL_API_IP6_ND_EVENT, ip6_nd_event, b9c7870c) \
_(VL_API_INPUT_ACL_SET_INTERFACE, input_acl_set_interface, 34d2fc33) \
_(VL_API_INPUT_ACL_SET_INTERFACE_REPLY, input_acl_set_interface_reply, ba0110e3) \
_(VL_API_GET_NODE_GRAPH, get_node_graph, f8636a76) \
_(VL_API_GET_NODE_GRAPH_REPLY, get_node_graph_reply, 816d91b6) \
_(VL_API_IOAM_ENABLE, ioam_enable, 7bd4abf9) \
_(VL_API_IOAM_ENABLE_REPLY, ioam_enable_reply, 58a8fedc) \
_(VL_API_IOAM_DISABLE, ioam_disable, aff26d33) \
_(VL_API_IOAM_DISABLE_REPLY, ioam_disable_reply, ef118a9d) \
_(VL_API_GET_NEXT_INDEX, get_next_index, 52f0e416) \
_(VL_API_GET_NEXT_INDEX_REPLY, get_next_index_reply, 671fbdb1) \
_(VL_API_PG_CREATE_INTERFACE, pg_create_interface, 253c5959) \
_(VL_API_PG_CREATE_INTERFACE_REPLY, pg_create_interface_reply, 21b4f949) \
_(VL_API_PG_CAPTURE, pg_capture, 6ac7fe78) \
_(VL_API_PG_CAPTURE_REPLY, pg_capture_reply, f403693b) \
_(VL_API_PG_ENABLE_DISABLE, pg_enable_disable, 7d0b90ff) \
_(VL_API_PG_ENABLE_DISABLE_REPLY, pg_enable_disable_reply, 02253bd6) \
_(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_ADD_DEL, ip_source_and_port_range_check_add_del, 0f8c6ba0) \
_(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_ADD_DEL_REPLY, ip_source_and_port_range_check_add_del_reply, 35df8160) \
_(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_INTERFACE_ADD_DEL, ip_source_and_port_range_check_interface_add_del, 4a6438f1) \
_(VL_API_IP_SOURCE_AND_PORT_RANGE_CHECK_INTERFACE_ADD_DEL_REPLY, ip_source_and_port_range_check_interface_add_del_reply, 6b940f04) \
_(VL_API_DELETE_SUBIF, delete_subif, 6038f848) \
_(VL_API_DELETE_SUBIF_REPLY, delete_subif_reply, 9d6015dc) \
_(VL_API_PUNT, punt, 4559c976) \
_(VL_API_PUNT_REPLY, punt_reply, cca27fbe) \
_(VL_API_PUNT_SOCKET_REGISTER, punt_socket_register, fbd069cb) \
_(VL_API_PUNT_SOCKET_REGISTER_REPLY, punt_socket_register_reply, b6059978) \
_(VL_API_PUNT_SOCKET_DEREGISTER, punt_socket_deregister, c02dbee8) \
_(VL_API_PUNT_SOCKET_DEREGISTER_REPLY, punt_socket_deregister_reply, e3cfe144) \
_(VL_API_FEATURE_ENABLE_DISABLE, feature_enable_disable, bc86393b) \
_(VL_API_FEATURE_ENABLE_DISABLE_REPLY, feature_enable_disable_reply, f6e14373) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_create_vlan_subif {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 vlan_id;
}) vl_api_create_vlan_subif_t;

typedef VL_API_PACKED(struct _vl_api_create_vlan_subif_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_create_vlan_subif_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mpls_enable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
}) vl_api_sw_interface_set_mpls_enable_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mpls_enable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_mpls_enable_reply_t;

typedef VL_API_PACKED(struct _vl_api_proxy_arp_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf_id;
    u8 is_add;
    u8 low_address[4];
    u8 hi_address[4];
}) vl_api_proxy_arp_add_del_t;

typedef VL_API_PACKED(struct _vl_api_proxy_arp_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_proxy_arp_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_proxy_arp_intfc_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable_disable;
}) vl_api_proxy_arp_intfc_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_proxy_arp_intfc_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_proxy_arp_intfc_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_reset_vrf {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u32 vrf_id;
}) vl_api_reset_vrf_t;

typedef VL_API_PACKED(struct _vl_api_reset_vrf_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_reset_vrf_reply_t;

typedef VL_API_PACKED(struct _vl_api_oam_event {
    u16 _vl_msg_id;
    u8 dst_address[4];
    u8 state;
}) vl_api_oam_event_t;

typedef VL_API_PACKED(struct _vl_api_want_oam_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_oam_events_t;

typedef VL_API_PACKED(struct _vl_api_want_oam_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_oam_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_oam_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf_id;
    u8 src_address[4];
    u8 dst_address[4];
    u8 is_add;
}) vl_api_oam_add_del_t;

typedef VL_API_PACKED(struct _vl_api_oam_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_oam_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_reset_fib {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf_id;
    u8 is_ipv6;
}) vl_api_reset_fib_t;

typedef VL_API_PACKED(struct _vl_api_reset_fib_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_reset_fib_reply_t;

typedef VL_API_PACKED(struct _vl_api_create_loopback {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mac_address[6];
}) vl_api_create_loopback_t;

typedef VL_API_PACKED(struct _vl_api_create_loopback_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_create_loopback_reply_t;

typedef VL_API_PACKED(struct _vl_api_create_loopback_instance {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mac_address[6];
    u8 is_specified;
    u32 user_instance;
}) vl_api_create_loopback_instance_t;

typedef VL_API_PACKED(struct _vl_api_create_loopback_instance_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_create_loopback_instance_reply_t;

typedef VL_API_PACKED(struct _vl_api_delete_loopback {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_delete_loopback_t;

typedef VL_API_PACKED(struct _vl_api_delete_loopback_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_delete_loopback_reply_t;

typedef VL_API_PACKED(struct _vl_api_control_ping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_control_ping_t;

typedef VL_API_PACKED(struct _vl_api_control_ping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 client_index;
    u32 vpe_pid;
}) vl_api_control_ping_reply_t;

typedef VL_API_PACKED(struct _vl_api_cli {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 cmd_in_shmem;
}) vl_api_cli_t;

typedef VL_API_PACKED(struct _vl_api_cli_inband {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 length;
    u8 cmd[0];
}) vl_api_cli_inband_t;

typedef VL_API_PACKED(struct _vl_api_cli_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 reply_in_shmem;
}) vl_api_cli_reply_t;

typedef VL_API_PACKED(struct _vl_api_cli_inband_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 length;
    u8 reply[0];
}) vl_api_cli_inband_reply_t;

typedef VL_API_PACKED(struct _vl_api_set_arp_neighbor_limit {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u32 arp_neighbor_limit;
}) vl_api_set_arp_neighbor_limit_t;

typedef VL_API_PACKED(struct _vl_api_set_arp_neighbor_limit_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_set_arp_neighbor_limit_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2_patch_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
    u8 is_add;
}) vl_api_l2_patch_add_del_t;

typedef VL_API_PACKED(struct _vl_api_l2_patch_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2_patch_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_vpath {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
}) vl_api_sw_interface_set_vpath_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_vpath_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_vpath_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_l2_xconnect {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
    u8 enable;
}) vl_api_sw_interface_set_l2_xconnect_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_l2_xconnect_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_l2_xconnect_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_l2_bridge {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_sw_if_index;
    u32 bd_id;
    u8 shg;
    u8 bvi;
    u8 enable;
}) vl_api_sw_interface_set_l2_bridge_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_l2_bridge_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_l2_bridge_reply_t;

typedef VL_API_PACKED(struct _vl_api_bd_ip_mac_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
    u8 mac_address[6];
}) vl_api_bd_ip_mac_add_del_t;

typedef VL_API_PACKED(struct _vl_api_bd_ip_mac_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bd_ip_mac_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_classify_set_interface_ip_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u32 sw_if_index;
    u32 table_index;
}) vl_api_classify_set_interface_ip_table_t;

typedef VL_API_PACKED(struct _vl_api_classify_set_interface_ip_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_classify_set_interface_ip_table_reply_t;

typedef VL_API_PACKED(struct _vl_api_classify_set_interface_l2_tables {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 other_table_index;
    u8 is_input;
}) vl_api_classify_set_interface_l2_tables_t;

typedef VL_API_PACKED(struct _vl_api_classify_set_interface_l2_tables_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_classify_set_interface_l2_tables_reply_t;

typedef VL_API_PACKED(struct _vl_api_get_node_index {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 node_name[64];
}) vl_api_get_node_index_t;

typedef VL_API_PACKED(struct _vl_api_get_node_index_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 node_index;
}) vl_api_get_node_index_reply_t;

typedef VL_API_PACKED(struct _vl_api_add_node_next {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 node_name[64];
    u8 next_name[64];
}) vl_api_add_node_next_t;

typedef VL_API_PACKED(struct _vl_api_add_node_next_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 next_index;
}) vl_api_add_node_next_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_efp_filter {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 enable_disable;
}) vl_api_l2_interface_efp_filter_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_efp_filter_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2_interface_efp_filter_reply_t;

typedef VL_API_PACKED(struct _vl_api_create_subif {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 sub_id;
    u8 no_tags;
    u8 one_tag;
    u8 two_tags;
    u8 dot1ad;
    u8 exact_match;
    u8 default_sub;
    u8 outer_vlan_id_any;
    u8 inner_vlan_id_any;
    u16 outer_vlan_id;
    u16 inner_vlan_id;
}) vl_api_create_subif_t;

typedef VL_API_PACKED(struct _vl_api_create_subif_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_create_subif_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_version {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_version_t;

typedef VL_API_PACKED(struct _vl_api_show_version_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 program[32];
    u8 version[32];
    u8 build_date[32];
    u8 build_directory[256];
}) vl_api_show_version_reply_t;

typedef VL_API_PACKED(struct _vl_api_interface_name_renumber {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 new_show_dev_instance;
}) vl_api_interface_name_renumber_t;

typedef VL_API_PACKED(struct _vl_api_interface_name_renumber_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_interface_name_renumber_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_arp_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 enable_disable;
    u32 pid;
    u32 address;
}) vl_api_want_ip4_arp_events_t;

typedef VL_API_PACKED(struct _vl_api_want_ip4_arp_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip4_arp_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip4_arp_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 address;
    u32 pid;
    u32 sw_if_index;
    u8 new_mac[6];
    u8 mac_ip;
}) vl_api_ip4_arp_event_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_nd_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 enable_disable;
    u32 pid;
    u8 address[16];
}) vl_api_want_ip6_nd_events_t;

typedef VL_API_PACKED(struct _vl_api_want_ip6_nd_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_ip6_nd_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip6_nd_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 pid;
    u32 sw_if_index;
    u8 address[16];
    u8 new_mac[6];
    u8 mac_ip;
}) vl_api_ip6_nd_event_t;

typedef VL_API_PACKED(struct _vl_api_input_acl_set_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 ip4_table_index;
    u32 ip6_table_index;
    u32 l2_table_index;
    u8 is_add;
}) vl_api_input_acl_set_interface_t;

typedef VL_API_PACKED(struct _vl_api_input_acl_set_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_input_acl_set_interface_reply_t;

typedef VL_API_PACKED(struct _vl_api_get_node_graph {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_get_node_graph_t;

typedef VL_API_PACKED(struct _vl_api_get_node_graph_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 reply_in_shmem;
}) vl_api_get_node_graph_reply_t;

typedef VL_API_PACKED(struct _vl_api_ioam_enable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 id;
    u8 seqno;
    u8 analyse;
    u8 pot_enable;
    u8 trace_enable;
    u32 node_id;
}) vl_api_ioam_enable_t;

typedef VL_API_PACKED(struct _vl_api_ioam_enable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ioam_enable_reply_t;

typedef VL_API_PACKED(struct _vl_api_ioam_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 id;
}) vl_api_ioam_disable_t;

typedef VL_API_PACKED(struct _vl_api_ioam_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ioam_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_get_next_index {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 node_name[64];
    u8 next_name[64];
}) vl_api_get_next_index_t;

typedef VL_API_PACKED(struct _vl_api_get_next_index_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 next_index;
}) vl_api_get_next_index_reply_t;

typedef VL_API_PACKED(struct _vl_api_pg_create_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 interface_id;
}) vl_api_pg_create_interface_t;

typedef VL_API_PACKED(struct _vl_api_pg_create_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_pg_create_interface_reply_t;

typedef VL_API_PACKED(struct _vl_api_pg_capture {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 interface_id;
    u8 is_enabled;
    u32 count;
    u32 pcap_name_length;
    u8 pcap_file_name[0];
}) vl_api_pg_capture_t;

typedef VL_API_PACKED(struct _vl_api_pg_capture_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_pg_capture_reply_t;

typedef VL_API_PACKED(struct _vl_api_pg_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
    u32 stream_name_length;
    u8 stream_name[0];
}) vl_api_pg_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_pg_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_pg_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_source_and_port_range_check_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ipv6;
    u8 is_add;
    u8 mask_length;
    u8 address[16];
    u8 number_of_ranges;
    u16 low_ports[32];
    u16 high_ports[32];
    u32 vrf_id;
}) vl_api_ip_source_and_port_range_check_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip_source_and_port_range_check_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_source_and_port_range_check_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_ip_source_and_port_range_check_interface_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sw_if_index;
    u32 tcp_in_vrf_id;
    u32 tcp_out_vrf_id;
    u32 udp_in_vrf_id;
    u32 udp_out_vrf_id;
}) vl_api_ip_source_and_port_range_check_interface_add_del_t;

typedef VL_API_PACKED(struct _vl_api_ip_source_and_port_range_check_interface_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_ip_source_and_port_range_check_interface_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_delete_subif {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_delete_subif_t;

typedef VL_API_PACKED(struct _vl_api_delete_subif_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_delete_subif_reply_t;

typedef VL_API_PACKED(struct _vl_api_punt {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ipv;
    u8 l4_protocol;
    u16 l4_port;
}) vl_api_punt_t;

typedef VL_API_PACKED(struct _vl_api_punt_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_punt_reply_t;

typedef VL_API_PACKED(struct _vl_api_punt_socket_register {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 header_version;
    u8 is_ip4;
    u8 l4_protocol;
    u16 l4_port;
    u8 pathname[108];
}) vl_api_punt_socket_register_t;

typedef VL_API_PACKED(struct _vl_api_punt_socket_register_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 pathname[64];
}) vl_api_punt_socket_register_reply_t;

typedef VL_API_PACKED(struct _vl_api_punt_socket_deregister {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 l4_protocol;
    u16 l4_port;
}) vl_api_punt_socket_deregister_t;

typedef VL_API_PACKED(struct _vl_api_punt_socket_deregister_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_punt_socket_deregister_reply_t;

typedef VL_API_PACKED(struct _vl_api_feature_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 enable;
    u8 arc_name[64];
    u8 feature_name[64];
}) vl_api_feature_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_feature_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_feature_enable_disable_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_create_vlan_subif_t_print (vl_api_create_vlan_subif_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_vlan_subif_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "vlan_id: %u\n", (unsigned) a->vlan_id);
    return handle;
}

static inline void *vl_api_create_vlan_subif_reply_t_print (vl_api_create_vlan_subif_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_vlan_subif_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_sw_interface_set_mpls_enable_t_print (vl_api_sw_interface_set_mpls_enable_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mpls_enable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_set_mpls_enable_reply_t_print (vl_api_sw_interface_set_mpls_enable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mpls_enable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_proxy_arp_add_del_t_print (vl_api_proxy_arp_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_proxy_arp_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "low_address[%d]: %u\n", _i, a->low_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "hi_address[%d]: %u\n", _i, a->hi_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_proxy_arp_add_del_reply_t_print (vl_api_proxy_arp_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_proxy_arp_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_proxy_arp_intfc_enable_disable_t_print (vl_api_proxy_arp_intfc_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_proxy_arp_intfc_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    return handle;
}

static inline void *vl_api_proxy_arp_intfc_enable_disable_reply_t_print (vl_api_proxy_arp_intfc_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_proxy_arp_intfc_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_reset_vrf_t_print (vl_api_reset_vrf_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_vrf_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_reset_vrf_reply_t_print (vl_api_reset_vrf_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_vrf_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_oam_event_t_print (vl_api_oam_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_oam_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "dst_address[%d]: %u\n", _i, a->dst_address[_i]);
        }
    }
    vl_print(handle, "state: %u\n", (unsigned) a->state);
    return handle;
}

static inline void *vl_api_want_oam_events_t_print (vl_api_want_oam_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_oam_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_oam_events_reply_t_print (vl_api_want_oam_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_oam_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_oam_add_del_t_print (vl_api_oam_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_oam_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "src_address[%d]: %u\n", _i, a->src_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "dst_address[%d]: %u\n", _i, a->dst_address[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_oam_add_del_reply_t_print (vl_api_oam_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_oam_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_reset_fib_t_print (vl_api_reset_fib_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_fib_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_reset_fib_reply_t_print (vl_api_reset_fib_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_fib_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_create_loopback_t_print (vl_api_create_loopback_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_loopback_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_create_loopback_reply_t_print (vl_api_create_loopback_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_loopback_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_create_loopback_instance_t_print (vl_api_create_loopback_instance_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_loopback_instance_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    vl_print(handle, "is_specified: %u\n", (unsigned) a->is_specified);
    vl_print(handle, "user_instance: %u\n", (unsigned) a->user_instance);
    return handle;
}

static inline void *vl_api_create_loopback_instance_reply_t_print (vl_api_create_loopback_instance_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_loopback_instance_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_delete_loopback_t_print (vl_api_delete_loopback_t *a,void *handle)
{
    vl_print(handle, "vl_api_delete_loopback_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_delete_loopback_reply_t_print (vl_api_delete_loopback_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_delete_loopback_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_control_ping_t_print (vl_api_control_ping_t *a,void *handle)
{
    vl_print(handle, "vl_api_control_ping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_control_ping_reply_t_print (vl_api_control_ping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_control_ping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "vpe_pid: %u\n", (unsigned) a->vpe_pid);
    return handle;
}

static inline void *vl_api_cli_t_print (vl_api_cli_t *a,void *handle)
{
    vl_print(handle, "vl_api_cli_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "cmd_in_shmem: %llu\n", (long long) a->cmd_in_shmem);
    return handle;
}

static inline void *vl_api_cli_inband_t_print (vl_api_cli_inband_t *a,void *handle)
{
    vl_print(handle, "vl_api_cli_inband_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "length: %u\n", (unsigned) a->length);
    return handle;
}

static inline void *vl_api_cli_reply_t_print (vl_api_cli_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_cli_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "reply_in_shmem: %llu\n", (long long) a->reply_in_shmem);
    return handle;
}

static inline void *vl_api_cli_inband_reply_t_print (vl_api_cli_inband_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_cli_inband_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "length: %u\n", (unsigned) a->length);
    return handle;
}

static inline void *vl_api_set_arp_neighbor_limit_t_print (vl_api_set_arp_neighbor_limit_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_arp_neighbor_limit_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "arp_neighbor_limit: %u\n", (unsigned) a->arp_neighbor_limit);
    return handle;
}

static inline void *vl_api_set_arp_neighbor_limit_reply_t_print (vl_api_set_arp_neighbor_limit_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_set_arp_neighbor_limit_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2_patch_add_del_t_print (vl_api_l2_patch_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_patch_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "rx_sw_if_index: %u\n", (unsigned) a->rx_sw_if_index);
    vl_print(handle, "tx_sw_if_index: %u\n", (unsigned) a->tx_sw_if_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_l2_patch_add_del_reply_t_print (vl_api_l2_patch_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_patch_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_vpath_t_print (vl_api_sw_interface_set_vpath_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_vpath_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_set_vpath_reply_t_print (vl_api_sw_interface_set_vpath_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_vpath_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_l2_xconnect_t_print (vl_api_sw_interface_set_l2_xconnect_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_l2_xconnect_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "rx_sw_if_index: %u\n", (unsigned) a->rx_sw_if_index);
    vl_print(handle, "tx_sw_if_index: %u\n", (unsigned) a->tx_sw_if_index);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_set_l2_xconnect_reply_t_print (vl_api_sw_interface_set_l2_xconnect_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_l2_xconnect_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_l2_bridge_t_print (vl_api_sw_interface_set_l2_bridge_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_l2_bridge_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "rx_sw_if_index: %u\n", (unsigned) a->rx_sw_if_index);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "shg: %u\n", (unsigned) a->shg);
    vl_print(handle, "bvi: %u\n", (unsigned) a->bvi);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_sw_interface_set_l2_bridge_reply_t_print (vl_api_sw_interface_set_l2_bridge_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_l2_bridge_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bd_ip_mac_add_del_t_print (vl_api_bd_ip_mac_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_bd_ip_mac_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_bd_ip_mac_add_del_reply_t_print (vl_api_bd_ip_mac_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bd_ip_mac_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_classify_set_interface_ip_table_t_print (vl_api_classify_set_interface_ip_table_t *a,void *handle)
{
    vl_print(handle, "vl_api_classify_set_interface_ip_table_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "table_index: %u\n", (unsigned) a->table_index);
    return handle;
}

static inline void *vl_api_classify_set_interface_ip_table_reply_t_print (vl_api_classify_set_interface_ip_table_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_classify_set_interface_ip_table_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_classify_set_interface_l2_tables_t_print (vl_api_classify_set_interface_l2_tables_t *a,void *handle)
{
    vl_print(handle, "vl_api_classify_set_interface_l2_tables_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "ip4_table_index: %u\n", (unsigned) a->ip4_table_index);
    vl_print(handle, "ip6_table_index: %u\n", (unsigned) a->ip6_table_index);
    vl_print(handle, "other_table_index: %u\n", (unsigned) a->other_table_index);
    vl_print(handle, "is_input: %u\n", (unsigned) a->is_input);
    return handle;
}

static inline void *vl_api_classify_set_interface_l2_tables_reply_t_print (vl_api_classify_set_interface_l2_tables_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_classify_set_interface_l2_tables_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_get_node_index_t_print (vl_api_get_node_index_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_node_index_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "node_name[%d]: %u\n", _i, a->node_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_get_node_index_reply_t_print (vl_api_get_node_index_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_node_index_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "node_index: %u\n", (unsigned) a->node_index);
    return handle;
}

static inline void *vl_api_add_node_next_t_print (vl_api_add_node_next_t *a,void *handle)
{
    vl_print(handle, "vl_api_add_node_next_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "node_name[%d]: %u\n", _i, a->node_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "next_name[%d]: %u\n", _i, a->next_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_add_node_next_reply_t_print (vl_api_add_node_next_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_add_node_next_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "next_index: %u\n", (unsigned) a->next_index);
    return handle;
}

static inline void *vl_api_l2_interface_efp_filter_t_print (vl_api_l2_interface_efp_filter_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_efp_filter_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    return handle;
}

static inline void *vl_api_l2_interface_efp_filter_reply_t_print (vl_api_l2_interface_efp_filter_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_efp_filter_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_create_subif_t_print (vl_api_create_subif_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_subif_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "sub_id: %u\n", (unsigned) a->sub_id);
    vl_print(handle, "no_tags: %u\n", (unsigned) a->no_tags);
    vl_print(handle, "one_tag: %u\n", (unsigned) a->one_tag);
    vl_print(handle, "two_tags: %u\n", (unsigned) a->two_tags);
    vl_print(handle, "dot1ad: %u\n", (unsigned) a->dot1ad);
    vl_print(handle, "exact_match: %u\n", (unsigned) a->exact_match);
    vl_print(handle, "default_sub: %u\n", (unsigned) a->default_sub);
    vl_print(handle, "outer_vlan_id_any: %u\n", (unsigned) a->outer_vlan_id_any);
    vl_print(handle, "inner_vlan_id_any: %u\n", (unsigned) a->inner_vlan_id_any);
    vl_print(handle, "outer_vlan_id: %u\n", (unsigned) a->outer_vlan_id);
    vl_print(handle, "inner_vlan_id: %u\n", (unsigned) a->inner_vlan_id);
    return handle;
}

static inline void *vl_api_create_subif_reply_t_print (vl_api_create_subif_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_create_subif_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_show_version_t_print (vl_api_show_version_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_version_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_version_reply_t_print (vl_api_show_version_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_version_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            vl_print(handle, "program[%d]: %u\n", _i, a->program[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            vl_print(handle, "version[%d]: %u\n", _i, a->version[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            vl_print(handle, "build_date[%d]: %u\n", _i, a->build_date[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 256; _i++) {
            vl_print(handle, "build_directory[%d]: %u\n", _i, a->build_directory[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_interface_name_renumber_t_print (vl_api_interface_name_renumber_t *a,void *handle)
{
    vl_print(handle, "vl_api_interface_name_renumber_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "new_show_dev_instance: %u\n", (unsigned) a->new_show_dev_instance);
    return handle;
}

static inline void *vl_api_interface_name_renumber_reply_t_print (vl_api_interface_name_renumber_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_interface_name_renumber_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_ip4_arp_events_t_print (vl_api_want_ip4_arp_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_arp_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "address: %u\n", (unsigned) a->address);
    return handle;
}

static inline void *vl_api_want_ip4_arp_events_reply_t_print (vl_api_want_ip4_arp_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip4_arp_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip4_arp_event_t_print (vl_api_ip4_arp_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip4_arp_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "address: %u\n", (unsigned) a->address);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "new_mac[%d]: %u\n", _i, a->new_mac[_i]);
        }
    }
    vl_print(handle, "mac_ip: %u\n", (unsigned) a->mac_ip);
    return handle;
}

static inline void *vl_api_want_ip6_nd_events_t_print (vl_api_want_ip6_nd_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_nd_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_want_ip6_nd_events_reply_t_print (vl_api_want_ip6_nd_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_ip6_nd_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip6_nd_event_t_print (vl_api_ip6_nd_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip6_nd_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "new_mac[%d]: %u\n", _i, a->new_mac[_i]);
        }
    }
    vl_print(handle, "mac_ip: %u\n", (unsigned) a->mac_ip);
    return handle;
}

static inline void *vl_api_input_acl_set_interface_t_print (vl_api_input_acl_set_interface_t *a,void *handle)
{
    vl_print(handle, "vl_api_input_acl_set_interface_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "ip4_table_index: %u\n", (unsigned) a->ip4_table_index);
    vl_print(handle, "ip6_table_index: %u\n", (unsigned) a->ip6_table_index);
    vl_print(handle, "l2_table_index: %u\n", (unsigned) a->l2_table_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_input_acl_set_interface_reply_t_print (vl_api_input_acl_set_interface_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_input_acl_set_interface_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_get_node_graph_t_print (vl_api_get_node_graph_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_node_graph_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_get_node_graph_reply_t_print (vl_api_get_node_graph_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_node_graph_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "reply_in_shmem: %llu\n", (long long) a->reply_in_shmem);
    return handle;
}

static inline void *vl_api_ioam_enable_t_print (vl_api_ioam_enable_t *a,void *handle)
{
    vl_print(handle, "vl_api_ioam_enable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "id: %u\n", (unsigned) a->id);
    vl_print(handle, "seqno: %u\n", (unsigned) a->seqno);
    vl_print(handle, "analyse: %u\n", (unsigned) a->analyse);
    vl_print(handle, "pot_enable: %u\n", (unsigned) a->pot_enable);
    vl_print(handle, "trace_enable: %u\n", (unsigned) a->trace_enable);
    vl_print(handle, "node_id: %u\n", (unsigned) a->node_id);
    return handle;
}

static inline void *vl_api_ioam_enable_reply_t_print (vl_api_ioam_enable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ioam_enable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ioam_disable_t_print (vl_api_ioam_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_ioam_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "id: %u\n", (unsigned) a->id);
    return handle;
}

static inline void *vl_api_ioam_disable_reply_t_print (vl_api_ioam_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ioam_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_get_next_index_t_print (vl_api_get_next_index_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_next_index_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "node_name[%d]: %u\n", _i, a->node_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "next_name[%d]: %u\n", _i, a->next_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_get_next_index_reply_t_print (vl_api_get_next_index_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_next_index_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "next_index: %u\n", (unsigned) a->next_index);
    return handle;
}

static inline void *vl_api_pg_create_interface_t_print (vl_api_pg_create_interface_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_create_interface_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "interface_id: %u\n", (unsigned) a->interface_id);
    return handle;
}

static inline void *vl_api_pg_create_interface_reply_t_print (vl_api_pg_create_interface_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_create_interface_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_pg_capture_t_print (vl_api_pg_capture_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_capture_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "interface_id: %u\n", (unsigned) a->interface_id);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    vl_print(handle, "count: %u\n", (unsigned) a->count);
    vl_print(handle, "pcap_name_length: %u\n", (unsigned) a->pcap_name_length);
    return handle;
}

static inline void *vl_api_pg_capture_reply_t_print (vl_api_pg_capture_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_capture_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_pg_enable_disable_t_print (vl_api_pg_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    vl_print(handle, "stream_name_length: %u\n", (unsigned) a->stream_name_length);
    return handle;
}

static inline void *vl_api_pg_enable_disable_reply_t_print (vl_api_pg_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_pg_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_source_and_port_range_check_add_del_t_print (vl_api_ip_source_and_port_range_check_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_source_and_port_range_check_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "mask_length: %u\n", (unsigned) a->mask_length);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    vl_print(handle, "number_of_ranges: %u\n", (unsigned) a->number_of_ranges);
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            vl_print(handle, "low_ports[%d]: %u\n", _i, a->low_ports[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            vl_print(handle, "high_ports[%d]: %u\n", _i, a->high_ports[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_ip_source_and_port_range_check_add_del_reply_t_print (vl_api_ip_source_and_port_range_check_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_source_and_port_range_check_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_ip_source_and_port_range_check_interface_add_del_t_print (vl_api_ip_source_and_port_range_check_interface_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_source_and_port_range_check_interface_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "tcp_in_vrf_id: %u\n", (unsigned) a->tcp_in_vrf_id);
    vl_print(handle, "tcp_out_vrf_id: %u\n", (unsigned) a->tcp_out_vrf_id);
    vl_print(handle, "udp_in_vrf_id: %u\n", (unsigned) a->udp_in_vrf_id);
    vl_print(handle, "udp_out_vrf_id: %u\n", (unsigned) a->udp_out_vrf_id);
    return handle;
}

static inline void *vl_api_ip_source_and_port_range_check_interface_add_del_reply_t_print (vl_api_ip_source_and_port_range_check_interface_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_ip_source_and_port_range_check_interface_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_delete_subif_t_print (vl_api_delete_subif_t *a,void *handle)
{
    vl_print(handle, "vl_api_delete_subif_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_delete_subif_reply_t_print (vl_api_delete_subif_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_delete_subif_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_punt_t_print (vl_api_punt_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "ipv: %u\n", (unsigned) a->ipv);
    vl_print(handle, "l4_protocol: %u\n", (unsigned) a->l4_protocol);
    vl_print(handle, "l4_port: %u\n", (unsigned) a->l4_port);
    return handle;
}

static inline void *vl_api_punt_reply_t_print (vl_api_punt_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_punt_socket_register_t_print (vl_api_punt_socket_register_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_socket_register_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "header_version: %u\n", (unsigned) a->header_version);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "l4_protocol: %u\n", (unsigned) a->l4_protocol);
    vl_print(handle, "l4_port: %u\n", (unsigned) a->l4_port);
    {
        int _i;
        for (_i = 0; _i < 108; _i++) {
            vl_print(handle, "pathname[%d]: %u\n", _i, a->pathname[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_punt_socket_register_reply_t_print (vl_api_punt_socket_register_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_socket_register_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "pathname[%d]: %u\n", _i, a->pathname[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_punt_socket_deregister_t_print (vl_api_punt_socket_deregister_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_socket_deregister_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "l4_protocol: %u\n", (unsigned) a->l4_protocol);
    vl_print(handle, "l4_port: %u\n", (unsigned) a->l4_port);
    return handle;
}

static inline void *vl_api_punt_socket_deregister_reply_t_print (vl_api_punt_socket_deregister_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_punt_socket_deregister_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_feature_enable_disable_t_print (vl_api_feature_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_feature_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "arc_name[%d]: %u\n", _i, a->arc_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "feature_name[%d]: %u\n", _i, a->feature_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_feature_enable_disable_reply_t_print (vl_api_feature_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_feature_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_create_vlan_subif_t_endian (vl_api_create_vlan_subif_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->vlan_id = clib_net_to_host_u32(a->vlan_id);
}

static inline void vl_api_create_vlan_subif_reply_t_endian (vl_api_create_vlan_subif_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_sw_interface_set_mpls_enable_t_endian (vl_api_sw_interface_set_mpls_enable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_mpls_enable_reply_t_endian (vl_api_sw_interface_set_mpls_enable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_proxy_arp_add_del_t_endian (vl_api_proxy_arp_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_add = a->is_add (no-op) */
    /* a->low_address[0..3] = a->low_address[0..3] (no-op) */
    /* a->hi_address[0..3] = a->hi_address[0..3] (no-op) */
}

static inline void vl_api_proxy_arp_add_del_reply_t_endian (vl_api_proxy_arp_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_proxy_arp_intfc_enable_disable_t_endian (vl_api_proxy_arp_intfc_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->enable_disable = a->enable_disable (no-op) */
}

static inline void vl_api_proxy_arp_intfc_enable_disable_reply_t_endian (vl_api_proxy_arp_intfc_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_reset_vrf_t_endian (vl_api_reset_vrf_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_reset_vrf_reply_t_endian (vl_api_reset_vrf_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_oam_event_t_endian (vl_api_oam_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->dst_address[0..3] = a->dst_address[0..3] (no-op) */
    /* a->state = a->state (no-op) */
}

static inline void vl_api_want_oam_events_t_endian (vl_api_want_oam_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_oam_events_reply_t_endian (vl_api_want_oam_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_oam_add_del_t_endian (vl_api_oam_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->src_address[0..3] = a->src_address[0..3] (no-op) */
    /* a->dst_address[0..3] = a->dst_address[0..3] (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_oam_add_del_reply_t_endian (vl_api_oam_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_reset_fib_t_endian (vl_api_reset_fib_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_reset_fib_reply_t_endian (vl_api_reset_fib_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_create_loopback_t_endian (vl_api_create_loopback_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
}

static inline void vl_api_create_loopback_reply_t_endian (vl_api_create_loopback_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_create_loopback_instance_t_endian (vl_api_create_loopback_instance_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
    /* a->is_specified = a->is_specified (no-op) */
    a->user_instance = clib_net_to_host_u32(a->user_instance);
}

static inline void vl_api_create_loopback_instance_reply_t_endian (vl_api_create_loopback_instance_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_delete_loopback_t_endian (vl_api_delete_loopback_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_delete_loopback_reply_t_endian (vl_api_delete_loopback_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_control_ping_t_endian (vl_api_control_ping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_control_ping_reply_t_endian (vl_api_control_ping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->vpe_pid = clib_net_to_host_u32(a->vpe_pid);
}

static inline void vl_api_cli_t_endian (vl_api_cli_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->cmd_in_shmem = clib_net_to_host_u64(a->cmd_in_shmem);
}

static inline void vl_api_cli_inband_t_endian (vl_api_cli_inband_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->length = clib_net_to_host_u32(a->length);
}

static inline void vl_api_cli_reply_t_endian (vl_api_cli_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->reply_in_shmem = clib_net_to_host_u64(a->reply_in_shmem);
}

static inline void vl_api_cli_inband_reply_t_endian (vl_api_cli_inband_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->length = clib_net_to_host_u32(a->length);
}

static inline void vl_api_set_arp_neighbor_limit_t_endian (vl_api_set_arp_neighbor_limit_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    a->arp_neighbor_limit = clib_net_to_host_u32(a->arp_neighbor_limit);
}

static inline void vl_api_set_arp_neighbor_limit_reply_t_endian (vl_api_set_arp_neighbor_limit_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2_patch_add_del_t_endian (vl_api_l2_patch_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->rx_sw_if_index = clib_net_to_host_u32(a->rx_sw_if_index);
    a->tx_sw_if_index = clib_net_to_host_u32(a->tx_sw_if_index);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_l2_patch_add_del_reply_t_endian (vl_api_l2_patch_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_vpath_t_endian (vl_api_sw_interface_set_vpath_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_vpath_reply_t_endian (vl_api_sw_interface_set_vpath_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_l2_xconnect_t_endian (vl_api_sw_interface_set_l2_xconnect_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->rx_sw_if_index = clib_net_to_host_u32(a->rx_sw_if_index);
    a->tx_sw_if_index = clib_net_to_host_u32(a->tx_sw_if_index);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_l2_xconnect_reply_t_endian (vl_api_sw_interface_set_l2_xconnect_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_l2_bridge_t_endian (vl_api_sw_interface_set_l2_bridge_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->rx_sw_if_index = clib_net_to_host_u32(a->rx_sw_if_index);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    /* a->shg = a->shg (no-op) */
    /* a->bvi = a->bvi (no-op) */
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_sw_interface_set_l2_bridge_reply_t_endian (vl_api_sw_interface_set_l2_bridge_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bd_ip_mac_add_del_t_endian (vl_api_bd_ip_mac_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
}

static inline void vl_api_bd_ip_mac_add_del_reply_t_endian (vl_api_bd_ip_mac_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_classify_set_interface_ip_table_t_endian (vl_api_classify_set_interface_ip_table_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->table_index = clib_net_to_host_u32(a->table_index);
}

static inline void vl_api_classify_set_interface_ip_table_reply_t_endian (vl_api_classify_set_interface_ip_table_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_classify_set_interface_l2_tables_t_endian (vl_api_classify_set_interface_l2_tables_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->ip4_table_index = clib_net_to_host_u32(a->ip4_table_index);
    a->ip6_table_index = clib_net_to_host_u32(a->ip6_table_index);
    a->other_table_index = clib_net_to_host_u32(a->other_table_index);
    /* a->is_input = a->is_input (no-op) */
}

static inline void vl_api_classify_set_interface_l2_tables_reply_t_endian (vl_api_classify_set_interface_l2_tables_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_get_node_index_t_endian (vl_api_get_node_index_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->node_name[0..63] = a->node_name[0..63] (no-op) */
}

static inline void vl_api_get_node_index_reply_t_endian (vl_api_get_node_index_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->node_index = clib_net_to_host_u32(a->node_index);
}

static inline void vl_api_add_node_next_t_endian (vl_api_add_node_next_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->node_name[0..63] = a->node_name[0..63] (no-op) */
    /* a->next_name[0..63] = a->next_name[0..63] (no-op) */
}

static inline void vl_api_add_node_next_reply_t_endian (vl_api_add_node_next_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->next_index = clib_net_to_host_u32(a->next_index);
}

static inline void vl_api_l2_interface_efp_filter_t_endian (vl_api_l2_interface_efp_filter_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
}

static inline void vl_api_l2_interface_efp_filter_reply_t_endian (vl_api_l2_interface_efp_filter_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_create_subif_t_endian (vl_api_create_subif_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->sub_id = clib_net_to_host_u32(a->sub_id);
    /* a->no_tags = a->no_tags (no-op) */
    /* a->one_tag = a->one_tag (no-op) */
    /* a->two_tags = a->two_tags (no-op) */
    /* a->dot1ad = a->dot1ad (no-op) */
    /* a->exact_match = a->exact_match (no-op) */
    /* a->default_sub = a->default_sub (no-op) */
    /* a->outer_vlan_id_any = a->outer_vlan_id_any (no-op) */
    /* a->inner_vlan_id_any = a->inner_vlan_id_any (no-op) */
    a->outer_vlan_id = clib_net_to_host_u16(a->outer_vlan_id);
    a->inner_vlan_id = clib_net_to_host_u16(a->inner_vlan_id);
}

static inline void vl_api_create_subif_reply_t_endian (vl_api_create_subif_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_show_version_t_endian (vl_api_show_version_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_version_reply_t_endian (vl_api_show_version_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->program[0..31] = a->program[0..31] (no-op) */
    /* a->version[0..31] = a->version[0..31] (no-op) */
    /* a->build_date[0..31] = a->build_date[0..31] (no-op) */
    /* a->build_directory[0..255] = a->build_directory[0..255] (no-op) */
}

static inline void vl_api_interface_name_renumber_t_endian (vl_api_interface_name_renumber_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->new_show_dev_instance = clib_net_to_host_u32(a->new_show_dev_instance);
}

static inline void vl_api_interface_name_renumber_reply_t_endian (vl_api_interface_name_renumber_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_ip4_arp_events_t_endian (vl_api_want_ip4_arp_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->enable_disable = a->enable_disable (no-op) */
    a->pid = clib_net_to_host_u32(a->pid);
    a->address = clib_net_to_host_u32(a->address);
}

static inline void vl_api_want_ip4_arp_events_reply_t_endian (vl_api_want_ip4_arp_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip4_arp_event_t_endian (vl_api_ip4_arp_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->address = clib_net_to_host_u32(a->address);
    a->pid = clib_net_to_host_u32(a->pid);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->new_mac[0..5] = a->new_mac[0..5] (no-op) */
    /* a->mac_ip = a->mac_ip (no-op) */
}

static inline void vl_api_want_ip6_nd_events_t_endian (vl_api_want_ip6_nd_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->enable_disable = a->enable_disable (no-op) */
    a->pid = clib_net_to_host_u32(a->pid);
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_want_ip6_nd_events_reply_t_endian (vl_api_want_ip6_nd_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip6_nd_event_t_endian (vl_api_ip6_nd_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->pid = clib_net_to_host_u32(a->pid);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->address[0..15] = a->address[0..15] (no-op) */
    /* a->new_mac[0..5] = a->new_mac[0..5] (no-op) */
    /* a->mac_ip = a->mac_ip (no-op) */
}

static inline void vl_api_input_acl_set_interface_t_endian (vl_api_input_acl_set_interface_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->ip4_table_index = clib_net_to_host_u32(a->ip4_table_index);
    a->ip6_table_index = clib_net_to_host_u32(a->ip6_table_index);
    a->l2_table_index = clib_net_to_host_u32(a->l2_table_index);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_input_acl_set_interface_reply_t_endian (vl_api_input_acl_set_interface_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_get_node_graph_t_endian (vl_api_get_node_graph_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_get_node_graph_reply_t_endian (vl_api_get_node_graph_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->reply_in_shmem = clib_net_to_host_u64(a->reply_in_shmem);
}

static inline void vl_api_ioam_enable_t_endian (vl_api_ioam_enable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->id = clib_net_to_host_u16(a->id);
    /* a->seqno = a->seqno (no-op) */
    /* a->analyse = a->analyse (no-op) */
    /* a->pot_enable = a->pot_enable (no-op) */
    /* a->trace_enable = a->trace_enable (no-op) */
    a->node_id = clib_net_to_host_u32(a->node_id);
}

static inline void vl_api_ioam_enable_reply_t_endian (vl_api_ioam_enable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ioam_disable_t_endian (vl_api_ioam_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->id = clib_net_to_host_u16(a->id);
}

static inline void vl_api_ioam_disable_reply_t_endian (vl_api_ioam_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_get_next_index_t_endian (vl_api_get_next_index_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->node_name[0..63] = a->node_name[0..63] (no-op) */
    /* a->next_name[0..63] = a->next_name[0..63] (no-op) */
}

static inline void vl_api_get_next_index_reply_t_endian (vl_api_get_next_index_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->next_index = clib_net_to_host_u32(a->next_index);
}

static inline void vl_api_pg_create_interface_t_endian (vl_api_pg_create_interface_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->interface_id = clib_net_to_host_u32(a->interface_id);
}

static inline void vl_api_pg_create_interface_reply_t_endian (vl_api_pg_create_interface_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_pg_capture_t_endian (vl_api_pg_capture_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->interface_id = clib_net_to_host_u32(a->interface_id);
    /* a->is_enabled = a->is_enabled (no-op) */
    a->count = clib_net_to_host_u32(a->count);
    a->pcap_name_length = clib_net_to_host_u32(a->pcap_name_length);
}

static inline void vl_api_pg_capture_reply_t_endian (vl_api_pg_capture_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_pg_enable_disable_t_endian (vl_api_pg_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enabled = a->is_enabled (no-op) */
    a->stream_name_length = clib_net_to_host_u32(a->stream_name_length);
}

static inline void vl_api_pg_enable_disable_reply_t_endian (vl_api_pg_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_source_and_port_range_check_add_del_t_endian (vl_api_ip_source_and_port_range_check_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->mask_length = a->mask_length (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
    /* a->number_of_ranges = a->number_of_ranges (no-op) */
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            a->low_ports[_i] = clib_net_to_host_u16(a->low_ports[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 32; _i++) {
            a->high_ports[_i] = clib_net_to_host_u16(a->high_ports[_i]);
        }
    }
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_ip_source_and_port_range_check_add_del_reply_t_endian (vl_api_ip_source_and_port_range_check_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_ip_source_and_port_range_check_interface_add_del_t_endian (vl_api_ip_source_and_port_range_check_interface_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->tcp_in_vrf_id = clib_net_to_host_u32(a->tcp_in_vrf_id);
    a->tcp_out_vrf_id = clib_net_to_host_u32(a->tcp_out_vrf_id);
    a->udp_in_vrf_id = clib_net_to_host_u32(a->udp_in_vrf_id);
    a->udp_out_vrf_id = clib_net_to_host_u32(a->udp_out_vrf_id);
}

static inline void vl_api_ip_source_and_port_range_check_interface_add_del_reply_t_endian (vl_api_ip_source_and_port_range_check_interface_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_delete_subif_t_endian (vl_api_delete_subif_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_delete_subif_reply_t_endian (vl_api_delete_subif_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_punt_t_endian (vl_api_punt_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->ipv = a->ipv (no-op) */
    /* a->l4_protocol = a->l4_protocol (no-op) */
    a->l4_port = clib_net_to_host_u16(a->l4_port);
}

static inline void vl_api_punt_reply_t_endian (vl_api_punt_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_punt_socket_register_t_endian (vl_api_punt_socket_register_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->header_version = clib_net_to_host_u32(a->header_version);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->l4_protocol = a->l4_protocol (no-op) */
    a->l4_port = clib_net_to_host_u16(a->l4_port);
    /* a->pathname[0..107] = a->pathname[0..107] (no-op) */
}

static inline void vl_api_punt_socket_register_reply_t_endian (vl_api_punt_socket_register_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->pathname[0..63] = a->pathname[0..63] (no-op) */
}

static inline void vl_api_punt_socket_deregister_t_endian (vl_api_punt_socket_deregister_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->l4_protocol = a->l4_protocol (no-op) */
    a->l4_port = clib_net_to_host_u16(a->l4_port);
}

static inline void vl_api_punt_socket_deregister_reply_t_endian (vl_api_punt_socket_deregister_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_feature_enable_disable_t_endian (vl_api_feature_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->enable = a->enable (no-op) */
    /* a->arc_name[0..63] = a->arc_name[0..63] (no-op) */
    /* a->feature_name[0..63] = a->feature_name[0..63] (no-op) */
}

static inline void vl_api_feature_enable_disable_reply_t_endian (vl_api_feature_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(vpe.api, 0xfdf4b648)

#endif

