/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/bfd/bfd.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/bfd/bfd.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_BFD_UDP_SET_ECHO_SOURCE, vl_api_bfd_udp_set_echo_source_t_handler)
vl_msg_id(VL_API_BFD_UDP_SET_ECHO_SOURCE_REPLY, vl_api_bfd_udp_set_echo_source_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_DEL_ECHO_SOURCE, vl_api_bfd_udp_del_echo_source_t_handler)
vl_msg_id(VL_API_BFD_UDP_DEL_ECHO_SOURCE_REPLY, vl_api_bfd_udp_del_echo_source_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_ADD, vl_api_bfd_udp_add_t_handler)
vl_msg_id(VL_API_BFD_UDP_ADD_REPLY, vl_api_bfd_udp_add_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_MOD, vl_api_bfd_udp_mod_t_handler)
vl_msg_id(VL_API_BFD_UDP_MOD_REPLY, vl_api_bfd_udp_mod_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_DEL, vl_api_bfd_udp_del_t_handler)
vl_msg_id(VL_API_BFD_UDP_DEL_REPLY, vl_api_bfd_udp_del_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_SESSION_DUMP, vl_api_bfd_udp_session_dump_t_handler)
vl_msg_id(VL_API_BFD_UDP_SESSION_DETAILS, vl_api_bfd_udp_session_details_t_handler)
vl_msg_id(VL_API_BFD_UDP_SESSION_SET_FLAGS, vl_api_bfd_udp_session_set_flags_t_handler)
vl_msg_id(VL_API_BFD_UDP_SESSION_SET_FLAGS_REPLY, vl_api_bfd_udp_session_set_flags_reply_t_handler)
vl_msg_id(VL_API_WANT_BFD_EVENTS, vl_api_want_bfd_events_t_handler)
vl_msg_id(VL_API_WANT_BFD_EVENTS_REPLY, vl_api_want_bfd_events_reply_t_handler)
vl_msg_id(VL_API_BFD_AUTH_SET_KEY, vl_api_bfd_auth_set_key_t_handler)
vl_msg_id(VL_API_BFD_AUTH_SET_KEY_REPLY, vl_api_bfd_auth_set_key_reply_t_handler)
vl_msg_id(VL_API_BFD_AUTH_DEL_KEY, vl_api_bfd_auth_del_key_t_handler)
vl_msg_id(VL_API_BFD_AUTH_DEL_KEY_REPLY, vl_api_bfd_auth_del_key_reply_t_handler)
vl_msg_id(VL_API_BFD_AUTH_KEYS_DUMP, vl_api_bfd_auth_keys_dump_t_handler)
vl_msg_id(VL_API_BFD_AUTH_KEYS_DETAILS, vl_api_bfd_auth_keys_details_t_handler)
vl_msg_id(VL_API_BFD_UDP_AUTH_ACTIVATE, vl_api_bfd_udp_auth_activate_t_handler)
vl_msg_id(VL_API_BFD_UDP_AUTH_ACTIVATE_REPLY, vl_api_bfd_udp_auth_activate_reply_t_handler)
vl_msg_id(VL_API_BFD_UDP_AUTH_DEACTIVATE, vl_api_bfd_udp_auth_deactivate_t_handler)
vl_msg_id(VL_API_BFD_UDP_AUTH_DEACTIVATE_REPLY, vl_api_bfd_udp_auth_deactivate_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_bfd_udp_set_echo_source_t, 1)
vl_msg_name(vl_api_bfd_udp_set_echo_source_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_del_echo_source_t, 1)
vl_msg_name(vl_api_bfd_udp_del_echo_source_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_add_t, 1)
vl_msg_name(vl_api_bfd_udp_add_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_mod_t, 1)
vl_msg_name(vl_api_bfd_udp_mod_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_del_t, 1)
vl_msg_name(vl_api_bfd_udp_del_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_session_dump_t, 1)
vl_msg_name(vl_api_bfd_udp_session_details_t, 1)
vl_msg_name(vl_api_bfd_udp_session_set_flags_t, 1)
vl_msg_name(vl_api_bfd_udp_session_set_flags_reply_t, 1)
vl_msg_name(vl_api_want_bfd_events_t, 1)
vl_msg_name(vl_api_want_bfd_events_reply_t, 1)
vl_msg_name(vl_api_bfd_auth_set_key_t, 1)
vl_msg_name(vl_api_bfd_auth_set_key_reply_t, 1)
vl_msg_name(vl_api_bfd_auth_del_key_t, 1)
vl_msg_name(vl_api_bfd_auth_del_key_reply_t, 1)
vl_msg_name(vl_api_bfd_auth_keys_dump_t, 1)
vl_msg_name(vl_api_bfd_auth_keys_details_t, 1)
vl_msg_name(vl_api_bfd_udp_auth_activate_t, 1)
vl_msg_name(vl_api_bfd_udp_auth_activate_reply_t, 1)
vl_msg_name(vl_api_bfd_udp_auth_deactivate_t, 1)
vl_msg_name(vl_api_bfd_udp_auth_deactivate_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_bfd \
_(VL_API_BFD_UDP_SET_ECHO_SOURCE, bfd_udp_set_echo_source, 928d862a) \
_(VL_API_BFD_UDP_SET_ECHO_SOURCE_REPLY, bfd_udp_set_echo_source_reply, c7700775) \
_(VL_API_BFD_UDP_DEL_ECHO_SOURCE, bfd_udp_del_echo_source, 2757531c) \
_(VL_API_BFD_UDP_DEL_ECHO_SOURCE_REPLY, bfd_udp_del_echo_source_reply, 63ae82c7) \
_(VL_API_BFD_UDP_ADD, bfd_udp_add, 5fe67640) \
_(VL_API_BFD_UDP_ADD_REPLY, bfd_udp_add_reply, 95013fb7) \
_(VL_API_BFD_UDP_MOD, bfd_udp_mod, cee1341e) \
_(VL_API_BFD_UDP_MOD_REPLY, bfd_udp_mod_reply, 6f9b0cf4) \
_(VL_API_BFD_UDP_DEL, bfd_udp_del, e95cc3ee) \
_(VL_API_BFD_UDP_DEL_REPLY, bfd_udp_del_reply, b9b0b355) \
_(VL_API_BFD_UDP_SESSION_DUMP, bfd_udp_session_dump, b5bd25a6) \
_(VL_API_BFD_UDP_SESSION_DETAILS, bfd_udp_session_details, 1a431796) \
_(VL_API_BFD_UDP_SESSION_SET_FLAGS, bfd_udp_session_set_flags, 7b8518ba) \
_(VL_API_BFD_UDP_SESSION_SET_FLAGS_REPLY, bfd_udp_session_set_flags_reply, 1a8335c3) \
_(VL_API_WANT_BFD_EVENTS, want_bfd_events, bc6547f0) \
_(VL_API_WANT_BFD_EVENTS_REPLY, want_bfd_events_reply, be8b3ff3) \
_(VL_API_BFD_AUTH_SET_KEY, bfd_auth_set_key, abbe70cc) \
_(VL_API_BFD_AUTH_SET_KEY_REPLY, bfd_auth_set_key_reply, 68ed0d61) \
_(VL_API_BFD_AUTH_DEL_KEY, bfd_auth_del_key, 4e4d7318) \
_(VL_API_BFD_AUTH_DEL_KEY_REPLY, bfd_auth_del_key_reply, a0db385f) \
_(VL_API_BFD_AUTH_KEYS_DUMP, bfd_auth_keys_dump, 336fa6ba) \
_(VL_API_BFD_AUTH_KEYS_DETAILS, bfd_auth_keys_details, 377927eb) \
_(VL_API_BFD_UDP_AUTH_ACTIVATE, bfd_udp_auth_activate, 87ac919e) \
_(VL_API_BFD_UDP_AUTH_ACTIVATE_REPLY, bfd_udp_auth_activate_reply, ba8f2610) \
_(VL_API_BFD_UDP_AUTH_DEACTIVATE, bfd_udp_auth_deactivate, 75f4d9e3) \
_(VL_API_BFD_UDP_AUTH_DEACTIVATE_REPLY, bfd_udp_auth_deactivate_reply, 1885e013) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_bfd_udp_set_echo_source {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_bfd_udp_set_echo_source_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_set_echo_source_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_set_echo_source_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_del_echo_source {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_bfd_udp_del_echo_source_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_del_echo_source_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_del_echo_source_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_add {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 desired_min_tx;
    u32 required_min_rx;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 detect_mult;
    u8 is_authenticated;
    u8 bfd_key_id;
    u32 conf_key_id;
}) vl_api_bfd_udp_add_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_add_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_add_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_mod {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 desired_min_tx;
    u32 required_min_rx;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 detect_mult;
}) vl_api_bfd_udp_mod_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_mod_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_mod_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
}) vl_api_bfd_udp_del_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_bfd_udp_session_dump_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_session_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 state;
    u8 is_authenticated;
    u8 bfd_key_id;
    u32 conf_key_id;
    u32 required_min_rx;
    u32 desired_min_tx;
    u8 detect_mult;
}) vl_api_bfd_udp_session_details_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_session_set_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 admin_up_down;
}) vl_api_bfd_udp_session_set_flags_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_session_set_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_session_set_flags_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_bfd_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_bfd_events_t;

typedef VL_API_PACKED(struct _vl_api_want_bfd_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_bfd_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_set_key {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 conf_key_id;
    u8 key_len;
    u8 auth_type;
    u8 key[20];
}) vl_api_bfd_auth_set_key_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_set_key_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_auth_set_key_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_del_key {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 conf_key_id;
}) vl_api_bfd_auth_del_key_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_del_key_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_auth_del_key_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_keys_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_bfd_auth_keys_dump_t;

typedef VL_API_PACKED(struct _vl_api_bfd_auth_keys_details {
    u16 _vl_msg_id;
    u32 context;
    u32 conf_key_id;
    u32 use_count;
    u8 auth_type;
}) vl_api_bfd_auth_keys_details_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_auth_activate {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 is_delayed;
    u8 bfd_key_id;
    u32 conf_key_id;
}) vl_api_bfd_udp_auth_activate_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_auth_activate_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_auth_activate_reply_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_auth_deactivate {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 local_addr[16];
    u8 peer_addr[16];
    u8 is_ipv6;
    u8 is_delayed;
}) vl_api_bfd_udp_auth_deactivate_t;

typedef VL_API_PACKED(struct _vl_api_bfd_udp_auth_deactivate_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bfd_udp_auth_deactivate_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_bfd_udp_set_echo_source_t_print (vl_api_bfd_udp_set_echo_source_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_set_echo_source_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_bfd_udp_set_echo_source_reply_t_print (vl_api_bfd_udp_set_echo_source_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_set_echo_source_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_del_echo_source_t_print (vl_api_bfd_udp_del_echo_source_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_del_echo_source_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_bfd_udp_del_echo_source_reply_t_print (vl_api_bfd_udp_del_echo_source_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_del_echo_source_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_add_t_print (vl_api_bfd_udp_add_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_add_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "desired_min_tx: %u\n", (unsigned) a->desired_min_tx);
    vl_print(handle, "required_min_rx: %u\n", (unsigned) a->required_min_rx);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "detect_mult: %u\n", (unsigned) a->detect_mult);
    vl_print(handle, "is_authenticated: %u\n", (unsigned) a->is_authenticated);
    vl_print(handle, "bfd_key_id: %u\n", (unsigned) a->bfd_key_id);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    return handle;
}

static inline void *vl_api_bfd_udp_add_reply_t_print (vl_api_bfd_udp_add_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_add_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_mod_t_print (vl_api_bfd_udp_mod_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_mod_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "desired_min_tx: %u\n", (unsigned) a->desired_min_tx);
    vl_print(handle, "required_min_rx: %u\n", (unsigned) a->required_min_rx);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "detect_mult: %u\n", (unsigned) a->detect_mult);
    return handle;
}

static inline void *vl_api_bfd_udp_mod_reply_t_print (vl_api_bfd_udp_mod_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_mod_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_del_t_print (vl_api_bfd_udp_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_bfd_udp_del_reply_t_print (vl_api_bfd_udp_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_session_dump_t_print (vl_api_bfd_udp_session_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_session_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_bfd_udp_session_details_t_print (vl_api_bfd_udp_session_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_session_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "state: %u\n", (unsigned) a->state);
    vl_print(handle, "is_authenticated: %u\n", (unsigned) a->is_authenticated);
    vl_print(handle, "bfd_key_id: %u\n", (unsigned) a->bfd_key_id);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    vl_print(handle, "required_min_rx: %u\n", (unsigned) a->required_min_rx);
    vl_print(handle, "desired_min_tx: %u\n", (unsigned) a->desired_min_tx);
    vl_print(handle, "detect_mult: %u\n", (unsigned) a->detect_mult);
    return handle;
}

static inline void *vl_api_bfd_udp_session_set_flags_t_print (vl_api_bfd_udp_session_set_flags_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_session_set_flags_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "admin_up_down: %u\n", (unsigned) a->admin_up_down);
    return handle;
}

static inline void *vl_api_bfd_udp_session_set_flags_reply_t_print (vl_api_bfd_udp_session_set_flags_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_session_set_flags_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_bfd_events_t_print (vl_api_want_bfd_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_bfd_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_bfd_events_reply_t_print (vl_api_want_bfd_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_bfd_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_auth_set_key_t_print (vl_api_bfd_auth_set_key_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_set_key_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    vl_print(handle, "key_len: %u\n", (unsigned) a->key_len);
    vl_print(handle, "auth_type: %u\n", (unsigned) a->auth_type);
    {
        int _i;
        for (_i = 0; _i < 20; _i++) {
            vl_print(handle, "key[%d]: %u\n", _i, a->key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_bfd_auth_set_key_reply_t_print (vl_api_bfd_auth_set_key_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_set_key_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_auth_del_key_t_print (vl_api_bfd_auth_del_key_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_del_key_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    return handle;
}

static inline void *vl_api_bfd_auth_del_key_reply_t_print (vl_api_bfd_auth_del_key_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_del_key_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_auth_keys_dump_t_print (vl_api_bfd_auth_keys_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_keys_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_bfd_auth_keys_details_t_print (vl_api_bfd_auth_keys_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_auth_keys_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    vl_print(handle, "use_count: %u\n", (unsigned) a->use_count);
    vl_print(handle, "auth_type: %u\n", (unsigned) a->auth_type);
    return handle;
}

static inline void *vl_api_bfd_udp_auth_activate_t_print (vl_api_bfd_udp_auth_activate_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_auth_activate_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_delayed: %u\n", (unsigned) a->is_delayed);
    vl_print(handle, "bfd_key_id: %u\n", (unsigned) a->bfd_key_id);
    vl_print(handle, "conf_key_id: %u\n", (unsigned) a->conf_key_id);
    return handle;
}

static inline void *vl_api_bfd_udp_auth_activate_reply_t_print (vl_api_bfd_udp_auth_activate_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_auth_activate_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bfd_udp_auth_deactivate_t_print (vl_api_bfd_udp_auth_deactivate_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_auth_deactivate_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_addr[%d]: %u\n", _i, a->local_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "peer_addr[%d]: %u\n", _i, a->peer_addr[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_delayed: %u\n", (unsigned) a->is_delayed);
    return handle;
}

static inline void *vl_api_bfd_udp_auth_deactivate_reply_t_print (vl_api_bfd_udp_auth_deactivate_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bfd_udp_auth_deactivate_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_bfd_udp_set_echo_source_t_endian (vl_api_bfd_udp_set_echo_source_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_bfd_udp_set_echo_source_reply_t_endian (vl_api_bfd_udp_set_echo_source_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_del_echo_source_t_endian (vl_api_bfd_udp_del_echo_source_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_bfd_udp_del_echo_source_reply_t_endian (vl_api_bfd_udp_del_echo_source_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_add_t_endian (vl_api_bfd_udp_add_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->desired_min_tx = clib_net_to_host_u32(a->desired_min_tx);
    a->required_min_rx = clib_net_to_host_u32(a->required_min_rx);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->detect_mult = a->detect_mult (no-op) */
    /* a->is_authenticated = a->is_authenticated (no-op) */
    /* a->bfd_key_id = a->bfd_key_id (no-op) */
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
}

static inline void vl_api_bfd_udp_add_reply_t_endian (vl_api_bfd_udp_add_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_mod_t_endian (vl_api_bfd_udp_mod_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->desired_min_tx = clib_net_to_host_u32(a->desired_min_tx);
    a->required_min_rx = clib_net_to_host_u32(a->required_min_rx);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->detect_mult = a->detect_mult (no-op) */
}

static inline void vl_api_bfd_udp_mod_reply_t_endian (vl_api_bfd_udp_mod_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_del_t_endian (vl_api_bfd_udp_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_bfd_udp_del_reply_t_endian (vl_api_bfd_udp_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_session_dump_t_endian (vl_api_bfd_udp_session_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_bfd_udp_session_details_t_endian (vl_api_bfd_udp_session_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->state = a->state (no-op) */
    /* a->is_authenticated = a->is_authenticated (no-op) */
    /* a->bfd_key_id = a->bfd_key_id (no-op) */
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
    a->required_min_rx = clib_net_to_host_u32(a->required_min_rx);
    a->desired_min_tx = clib_net_to_host_u32(a->desired_min_tx);
    /* a->detect_mult = a->detect_mult (no-op) */
}

static inline void vl_api_bfd_udp_session_set_flags_t_endian (vl_api_bfd_udp_session_set_flags_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->admin_up_down = a->admin_up_down (no-op) */
}

static inline void vl_api_bfd_udp_session_set_flags_reply_t_endian (vl_api_bfd_udp_session_set_flags_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_bfd_events_t_endian (vl_api_want_bfd_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_bfd_events_reply_t_endian (vl_api_want_bfd_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_auth_set_key_t_endian (vl_api_bfd_auth_set_key_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
    /* a->key_len = a->key_len (no-op) */
    /* a->auth_type = a->auth_type (no-op) */
    /* a->key[0..19] = a->key[0..19] (no-op) */
}

static inline void vl_api_bfd_auth_set_key_reply_t_endian (vl_api_bfd_auth_set_key_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_auth_del_key_t_endian (vl_api_bfd_auth_del_key_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
}

static inline void vl_api_bfd_auth_del_key_reply_t_endian (vl_api_bfd_auth_del_key_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_auth_keys_dump_t_endian (vl_api_bfd_auth_keys_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_bfd_auth_keys_details_t_endian (vl_api_bfd_auth_keys_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
    a->use_count = clib_net_to_host_u32(a->use_count);
    /* a->auth_type = a->auth_type (no-op) */
}

static inline void vl_api_bfd_udp_auth_activate_t_endian (vl_api_bfd_udp_auth_activate_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_delayed = a->is_delayed (no-op) */
    /* a->bfd_key_id = a->bfd_key_id (no-op) */
    a->conf_key_id = clib_net_to_host_u32(a->conf_key_id);
}

static inline void vl_api_bfd_udp_auth_activate_reply_t_endian (vl_api_bfd_udp_auth_activate_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bfd_udp_auth_deactivate_t_endian (vl_api_bfd_udp_auth_deactivate_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->local_addr[0..15] = a->local_addr[0..15] (no-op) */
    /* a->peer_addr[0..15] = a->peer_addr[0..15] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_delayed = a->is_delayed (no-op) */
}

static inline void vl_api_bfd_udp_auth_deactivate_reply_t_endian (vl_api_bfd_udp_auth_deactivate_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(bfd.api, 0xdd31bf39)

#endif

