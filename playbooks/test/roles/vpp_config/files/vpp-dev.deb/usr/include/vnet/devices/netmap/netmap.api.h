/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vnet/devices/netmap/netmap.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/devices/netmap/netmap.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_NETMAP_CREATE, vl_api_netmap_create_t_handler)
vl_msg_id(VL_API_NETMAP_CREATE_REPLY, vl_api_netmap_create_reply_t_handler)
vl_msg_id(VL_API_NETMAP_DELETE, vl_api_netmap_delete_t_handler)
vl_msg_id(VL_API_NETMAP_DELETE_REPLY, vl_api_netmap_delete_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_netmap_create_t, 1)
vl_msg_name(vl_api_netmap_create_reply_t, 1)
vl_msg_name(vl_api_netmap_delete_t, 1)
vl_msg_name(vl_api_netmap_delete_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_netmap \
_(VL_API_NETMAP_CREATE, netmap_create, 0f13a603) \
_(VL_API_NETMAP_CREATE_REPLY, netmap_create_reply, 70d29cfe) \
_(VL_API_NETMAP_DELETE, netmap_delete, 43e5c963) \
_(VL_API_NETMAP_DELETE_REPLY, netmap_delete_reply, 81ecfa0d) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_netmap_create {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 netmap_if_name[64];
    u8 hw_addr[6];
    u8 use_random_hw_addr;
    u8 is_pipe;
    u8 is_master;
}) vl_api_netmap_create_t;

typedef VL_API_PACKED(struct _vl_api_netmap_create_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_netmap_create_reply_t;

typedef VL_API_PACKED(struct _vl_api_netmap_delete {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 netmap_if_name[64];
}) vl_api_netmap_delete_t;

typedef VL_API_PACKED(struct _vl_api_netmap_delete_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_netmap_delete_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_netmap_create_t_print (vl_api_netmap_create_t *a,void *handle)
{
    vl_print(handle, "vl_api_netmap_create_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "netmap_if_name[%d]: %u\n", _i, a->netmap_if_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "hw_addr[%d]: %u\n", _i, a->hw_addr[_i]);
        }
    }
    vl_print(handle, "use_random_hw_addr: %u\n", (unsigned) a->use_random_hw_addr);
    vl_print(handle, "is_pipe: %u\n", (unsigned) a->is_pipe);
    vl_print(handle, "is_master: %u\n", (unsigned) a->is_master);
    return handle;
}

static inline void *vl_api_netmap_create_reply_t_print (vl_api_netmap_create_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_netmap_create_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_netmap_delete_t_print (vl_api_netmap_delete_t *a,void *handle)
{
    vl_print(handle, "vl_api_netmap_delete_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "netmap_if_name[%d]: %u\n", _i, a->netmap_if_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_netmap_delete_reply_t_print (vl_api_netmap_delete_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_netmap_delete_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_netmap_create_t_endian (vl_api_netmap_create_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->netmap_if_name[0..63] = a->netmap_if_name[0..63] (no-op) */
    /* a->hw_addr[0..5] = a->hw_addr[0..5] (no-op) */
    /* a->use_random_hw_addr = a->use_random_hw_addr (no-op) */
    /* a->is_pipe = a->is_pipe (no-op) */
    /* a->is_master = a->is_master (no-op) */
}

static inline void vl_api_netmap_create_reply_t_endian (vl_api_netmap_create_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_netmap_delete_t_endian (vl_api_netmap_delete_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->netmap_if_name[0..63] = a->netmap_if_name[0..63] (no-op) */
}

static inline void vl_api_netmap_delete_reply_t_endian (vl_api_netmap_delete_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(netmap.api, 0x54ce130c)

#endif

