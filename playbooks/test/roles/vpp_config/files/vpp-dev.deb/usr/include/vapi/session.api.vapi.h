#ifndef __included_session_api_json
#define __included_session_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_accept_session;
extern vapi_msg_id_t vapi_msg_id_application_detach;
extern vapi_msg_id_t vapi_msg_id_application_attach;
extern vapi_msg_id_t vapi_msg_id_reset_session;
extern vapi_msg_id_t vapi_msg_id_unbind_sock;
extern vapi_msg_id_t vapi_msg_id_connect_uri_reply;
extern vapi_msg_id_t vapi_msg_id_connect_session_reply;
extern vapi_msg_id_t vapi_msg_id_map_another_segment;
extern vapi_msg_id_t vapi_msg_id_disconnect_session_reply;
extern vapi_msg_id_t vapi_msg_id_unbind_sock_reply;
extern vapi_msg_id_t vapi_msg_id_connect_sock;
extern vapi_msg_id_t vapi_msg_id_unbind_uri;
extern vapi_msg_id_t vapi_msg_id_unbind_uri_reply;
extern vapi_msg_id_t vapi_msg_id_session_enable_disable_reply;
extern vapi_msg_id_t vapi_msg_id_bind_sock;
extern vapi_msg_id_t vapi_msg_id_accept_session_reply;
extern vapi_msg_id_t vapi_msg_id_bind_uri_reply;
extern vapi_msg_id_t vapi_msg_id_connect_session;
extern vapi_msg_id_t vapi_msg_id_application_detach_reply;
extern vapi_msg_id_t vapi_msg_id_application_attach_reply;
extern vapi_msg_id_t vapi_msg_id_reset_session_reply;
extern vapi_msg_id_t vapi_msg_id_map_another_segment_reply;
extern vapi_msg_id_t vapi_msg_id_connect_uri;
extern vapi_msg_id_t vapi_msg_id_bind_uri;
extern vapi_msg_id_t vapi_msg_id_disconnect_session;
extern vapi_msg_id_t vapi_msg_id_connect_sock_reply;
extern vapi_msg_id_t vapi_msg_id_bind_sock_reply;
extern vapi_msg_id_t vapi_msg_id_session_enable_disable;

#define DEFINE_VAPI_MSG_IDS_SESSION_API_JSON\
  vapi_msg_id_t vapi_msg_id_accept_session;\
  vapi_msg_id_t vapi_msg_id_application_detach;\
  vapi_msg_id_t vapi_msg_id_application_attach;\
  vapi_msg_id_t vapi_msg_id_reset_session;\
  vapi_msg_id_t vapi_msg_id_unbind_sock;\
  vapi_msg_id_t vapi_msg_id_connect_uri_reply;\
  vapi_msg_id_t vapi_msg_id_connect_session_reply;\
  vapi_msg_id_t vapi_msg_id_map_another_segment;\
  vapi_msg_id_t vapi_msg_id_disconnect_session_reply;\
  vapi_msg_id_t vapi_msg_id_unbind_sock_reply;\
  vapi_msg_id_t vapi_msg_id_connect_sock;\
  vapi_msg_id_t vapi_msg_id_unbind_uri;\
  vapi_msg_id_t vapi_msg_id_unbind_uri_reply;\
  vapi_msg_id_t vapi_msg_id_session_enable_disable_reply;\
  vapi_msg_id_t vapi_msg_id_bind_sock;\
  vapi_msg_id_t vapi_msg_id_accept_session_reply;\
  vapi_msg_id_t vapi_msg_id_bind_uri_reply;\
  vapi_msg_id_t vapi_msg_id_connect_session;\
  vapi_msg_id_t vapi_msg_id_application_detach_reply;\
  vapi_msg_id_t vapi_msg_id_application_attach_reply;\
  vapi_msg_id_t vapi_msg_id_reset_session_reply;\
  vapi_msg_id_t vapi_msg_id_map_another_segment_reply;\
  vapi_msg_id_t vapi_msg_id_connect_uri;\
  vapi_msg_id_t vapi_msg_id_bind_uri;\
  vapi_msg_id_t vapi_msg_id_disconnect_session;\
  vapi_msg_id_t vapi_msg_id_connect_sock_reply;\
  vapi_msg_id_t vapi_msg_id_bind_sock_reply;\
  vapi_msg_id_t vapi_msg_id_session_enable_disable;


typedef struct __attribute__ ((__packed__)) {
  u64 listener_handle;
  u64 handle;
  u64 server_rx_fifo;
  u64 server_tx_fifo;
  u64 vpp_event_queue_address;
  u16 port;
  u8 is_ip4;
  u8 ip[16]; 
} vapi_payload_accept_session;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_accept_session payload;
} vapi_msg_accept_session;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_application_detach;

typedef struct __attribute__ ((__packed__)) {
  u32 initial_segment_size;
  u64 options[16]; 
} vapi_payload_application_attach;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_application_attach payload;
} vapi_msg_application_attach;

typedef struct __attribute__ ((__packed__)) {
  u64 handle; 
} vapi_payload_reset_session;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_reset_session payload;
} vapi_msg_reset_session;

typedef struct __attribute__ ((__packed__)) {
  u64 handle; 
} vapi_payload_unbind_sock;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_unbind_sock payload;
} vapi_msg_unbind_sock;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_connect_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_connect_uri_reply payload;
} vapi_msg_connect_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 handle;
  u64 server_rx_fifo;
  u64 server_tx_fifo;
  u64 vpp_event_queue_address;
  u32 segment_size;
  u8 segment_name_length;
  u8 segment_name[128]; 
} vapi_payload_connect_session_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_connect_session_reply payload;
} vapi_msg_connect_session_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 segment_size;
  u8 segment_name[128]; 
} vapi_payload_map_another_segment;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_map_another_segment payload;
} vapi_msg_map_another_segment;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 handle; 
} vapi_payload_disconnect_session_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_disconnect_session_reply payload;
} vapi_msg_disconnect_session_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_unbind_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_unbind_sock_reply payload;
} vapi_msg_unbind_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf;
  u8 is_ip4;
  u8 ip[16];
  u16 port;
  u8 proto;
  u64 client_queue_address;
  u64 options[16]; 
} vapi_payload_connect_sock;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_connect_sock payload;
} vapi_msg_connect_sock;

typedef struct __attribute__ ((__packed__)) {
  u8 uri[128]; 
} vapi_payload_unbind_uri;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_unbind_uri payload;
} vapi_msg_unbind_uri;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_unbind_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_unbind_uri_reply payload;
} vapi_msg_unbind_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_session_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_session_enable_disable_reply payload;
} vapi_msg_session_enable_disable_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 vrf;
  u8 is_ip4;
  u8 ip[16];
  u16 port;
  u8 proto;
  u64 options[16]; 
} vapi_payload_bind_sock;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_bind_sock payload;
} vapi_msg_bind_sock;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 handle; 
} vapi_payload_accept_session_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_accept_session_reply payload;
} vapi_msg_accept_session_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_bind_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_bind_uri_reply payload;
} vapi_msg_bind_uri_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_connect_session;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_application_detach_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_application_detach_reply payload;
} vapi_msg_application_detach_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 app_event_queue_address;
  u32 segment_size;
  u8 segment_name_length;
  u8 segment_name[128]; 
} vapi_payload_application_attach_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_application_attach_reply payload;
} vapi_msg_application_attach_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 handle; 
} vapi_payload_reset_session_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_reset_session_reply payload;
} vapi_msg_reset_session_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_map_another_segment_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_another_segment_reply payload;
} vapi_msg_map_another_segment_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 uri[128];
  u64 client_queue_address;
  u64 options[16]; 
} vapi_payload_connect_uri;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_connect_uri payload;
} vapi_msg_connect_uri;

typedef struct __attribute__ ((__packed__)) {
  u32 accept_cookie;
  u8 uri[128]; 
} vapi_payload_bind_uri;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_bind_uri payload;
} vapi_msg_bind_uri;

typedef struct __attribute__ ((__packed__)) {
  u64 handle; 
} vapi_payload_disconnect_session;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_disconnect_session payload;
} vapi_msg_disconnect_session;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_connect_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_connect_sock_reply payload;
} vapi_msg_connect_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  u64 handle;
  i32 retval;
  u64 server_event_queue_address;
  u32 segment_size;
  u8 segment_name_length;
  u8 segment_name[128]; 
} vapi_payload_bind_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_bind_sock_reply payload;
} vapi_msg_bind_sock_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 is_enable; 
} vapi_payload_session_enable_disable;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_session_enable_disable payload;
} vapi_msg_session_enable_disable;


static inline void vapi_msg_accept_session_payload_hton(vapi_payload_accept_session *payload)
{
  payload->listener_handle = htobe64(payload->listener_handle);
  payload->handle = htobe64(payload->handle);
  payload->server_rx_fifo = htobe64(payload->server_rx_fifo);
  payload->server_tx_fifo = htobe64(payload->server_tx_fifo);
  payload->vpp_event_queue_address = htobe64(payload->vpp_event_queue_address);
  payload->port = htobe16(payload->port);
}

static inline void vapi_msg_accept_session_payload_ntoh(vapi_payload_accept_session *payload)
{
  payload->listener_handle = be64toh(payload->listener_handle);
  payload->handle = be64toh(payload->handle);
  payload->server_rx_fifo = be64toh(payload->server_rx_fifo);
  payload->server_tx_fifo = be64toh(payload->server_tx_fifo);
  payload->vpp_event_queue_address = be64toh(payload->vpp_event_queue_address);
  payload->port = be16toh(payload->port);
}

static inline uword vapi_calc_accept_session_msg_size(vapi_msg_accept_session *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_accept_session_hton(vapi_msg_accept_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_accept_session'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_accept_session_payload_hton(&msg->payload);
}

static inline void vapi_msg_accept_session_ntoh(vapi_msg_accept_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_accept_session'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_accept_session_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_application_detach_msg_size(vapi_msg_application_detach *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_application_detach_hton(vapi_msg_application_detach *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_detach'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_application_detach_ntoh(vapi_msg_application_detach *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_detach'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_application_attach_payload_hton(vapi_payload_application_attach *payload)
{
  payload->initial_segment_size = htobe32(payload->initial_segment_size);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = htobe64(payload->options[i]); } } while(0);
}

static inline void vapi_msg_application_attach_payload_ntoh(vapi_payload_application_attach *payload)
{
  payload->initial_segment_size = be32toh(payload->initial_segment_size);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = be64toh(payload->options[i]); } } while(0);
}

static inline uword vapi_calc_application_attach_msg_size(vapi_msg_application_attach *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_application_attach_hton(vapi_msg_application_attach *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_attach'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_application_attach_payload_hton(&msg->payload);
}

static inline void vapi_msg_application_attach_ntoh(vapi_msg_application_attach *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_attach'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_application_attach_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_session_payload_hton(vapi_payload_reset_session *payload)
{
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_reset_session_payload_ntoh(vapi_payload_reset_session *payload)
{
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_reset_session_msg_size(vapi_msg_reset_session *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_session_hton(vapi_msg_reset_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_session'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_reset_session_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_session_ntoh(vapi_msg_reset_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_session'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_reset_session_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_unbind_sock_payload_hton(vapi_payload_unbind_sock *payload)
{
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_unbind_sock_payload_ntoh(vapi_payload_unbind_sock *payload)
{
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_unbind_sock_msg_size(vapi_msg_unbind_sock *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_unbind_sock_hton(vapi_msg_unbind_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_sock'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_unbind_sock_payload_hton(&msg->payload);
}

static inline void vapi_msg_unbind_sock_ntoh(vapi_msg_unbind_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_sock'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_unbind_sock_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_connect_uri_reply_payload_hton(vapi_payload_connect_uri_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_connect_uri_reply_payload_ntoh(vapi_payload_connect_uri_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_connect_uri_reply_msg_size(vapi_msg_connect_uri_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_uri_reply_hton(vapi_msg_connect_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_uri_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_connect_uri_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_connect_uri_reply_ntoh(vapi_msg_connect_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_uri_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_connect_uri_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_connect_session_reply_payload_hton(vapi_payload_connect_session_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->handle = htobe64(payload->handle);
  payload->server_rx_fifo = htobe64(payload->server_rx_fifo);
  payload->server_tx_fifo = htobe64(payload->server_tx_fifo);
  payload->vpp_event_queue_address = htobe64(payload->vpp_event_queue_address);
  payload->segment_size = htobe32(payload->segment_size);
}

static inline void vapi_msg_connect_session_reply_payload_ntoh(vapi_payload_connect_session_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->handle = be64toh(payload->handle);
  payload->server_rx_fifo = be64toh(payload->server_rx_fifo);
  payload->server_tx_fifo = be64toh(payload->server_tx_fifo);
  payload->vpp_event_queue_address = be64toh(payload->vpp_event_queue_address);
  payload->segment_size = be32toh(payload->segment_size);
}

static inline uword vapi_calc_connect_session_reply_msg_size(vapi_msg_connect_session_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_session_reply_hton(vapi_msg_connect_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_session_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_connect_session_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_connect_session_reply_ntoh(vapi_msg_connect_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_session_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_connect_session_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_another_segment_payload_hton(vapi_payload_map_another_segment *payload)
{
  payload->segment_size = htobe32(payload->segment_size);
}

static inline void vapi_msg_map_another_segment_payload_ntoh(vapi_payload_map_another_segment *payload)
{
  payload->segment_size = be32toh(payload->segment_size);
}

static inline uword vapi_calc_map_another_segment_msg_size(vapi_msg_map_another_segment *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_another_segment_hton(vapi_msg_map_another_segment *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_another_segment'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_map_another_segment_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_another_segment_ntoh(vapi_msg_map_another_segment *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_another_segment'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_map_another_segment_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_disconnect_session_reply_payload_hton(vapi_payload_disconnect_session_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_disconnect_session_reply_payload_ntoh(vapi_payload_disconnect_session_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_disconnect_session_reply_msg_size(vapi_msg_disconnect_session_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_disconnect_session_reply_hton(vapi_msg_disconnect_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_disconnect_session_reply'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_disconnect_session_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_disconnect_session_reply_ntoh(vapi_msg_disconnect_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_disconnect_session_reply'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_disconnect_session_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_unbind_sock_reply_payload_hton(vapi_payload_unbind_sock_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_unbind_sock_reply_payload_ntoh(vapi_payload_unbind_sock_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_unbind_sock_reply_msg_size(vapi_msg_unbind_sock_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_unbind_sock_reply_hton(vapi_msg_unbind_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_sock_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_unbind_sock_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_unbind_sock_reply_ntoh(vapi_msg_unbind_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_sock_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_unbind_sock_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_connect_sock_payload_hton(vapi_payload_connect_sock *payload)
{
  payload->vrf = htobe32(payload->vrf);
  payload->port = htobe16(payload->port);
  payload->client_queue_address = htobe64(payload->client_queue_address);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = htobe64(payload->options[i]); } } while(0);
}

static inline void vapi_msg_connect_sock_payload_ntoh(vapi_payload_connect_sock *payload)
{
  payload->vrf = be32toh(payload->vrf);
  payload->port = be16toh(payload->port);
  payload->client_queue_address = be64toh(payload->client_queue_address);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = be64toh(payload->options[i]); } } while(0);
}

static inline uword vapi_calc_connect_sock_msg_size(vapi_msg_connect_sock *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_sock_hton(vapi_msg_connect_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_sock'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_connect_sock_payload_hton(&msg->payload);
}

static inline void vapi_msg_connect_sock_ntoh(vapi_msg_connect_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_sock'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_connect_sock_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_unbind_uri_payload_hton(vapi_payload_unbind_uri *payload)
{

}

static inline void vapi_msg_unbind_uri_payload_ntoh(vapi_payload_unbind_uri *payload)
{

}

static inline uword vapi_calc_unbind_uri_msg_size(vapi_msg_unbind_uri *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_unbind_uri_hton(vapi_msg_unbind_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_uri'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_unbind_uri_payload_hton(&msg->payload);
}

static inline void vapi_msg_unbind_uri_ntoh(vapi_msg_unbind_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_uri'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_unbind_uri_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_unbind_uri_reply_payload_hton(vapi_payload_unbind_uri_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_unbind_uri_reply_payload_ntoh(vapi_payload_unbind_uri_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_unbind_uri_reply_msg_size(vapi_msg_unbind_uri_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_unbind_uri_reply_hton(vapi_msg_unbind_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_uri_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_unbind_uri_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_unbind_uri_reply_ntoh(vapi_msg_unbind_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_unbind_uri_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_unbind_uri_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_session_enable_disable_reply_payload_hton(vapi_payload_session_enable_disable_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_session_enable_disable_reply_payload_ntoh(vapi_payload_session_enable_disable_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_session_enable_disable_reply_msg_size(vapi_msg_session_enable_disable_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_session_enable_disable_reply_hton(vapi_msg_session_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_session_enable_disable_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_session_enable_disable_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_session_enable_disable_reply_ntoh(vapi_msg_session_enable_disable_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_session_enable_disable_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_session_enable_disable_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bind_sock_payload_hton(vapi_payload_bind_sock *payload)
{
  payload->vrf = htobe32(payload->vrf);
  payload->port = htobe16(payload->port);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = htobe64(payload->options[i]); } } while(0);
}

static inline void vapi_msg_bind_sock_payload_ntoh(vapi_payload_bind_sock *payload)
{
  payload->vrf = be32toh(payload->vrf);
  payload->port = be16toh(payload->port);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = be64toh(payload->options[i]); } } while(0);
}

static inline uword vapi_calc_bind_sock_msg_size(vapi_msg_bind_sock *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bind_sock_hton(vapi_msg_bind_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_sock'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_bind_sock_payload_hton(&msg->payload);
}

static inline void vapi_msg_bind_sock_ntoh(vapi_msg_bind_sock *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_sock'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_bind_sock_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_accept_session_reply_payload_hton(vapi_payload_accept_session_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_accept_session_reply_payload_ntoh(vapi_payload_accept_session_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_accept_session_reply_msg_size(vapi_msg_accept_session_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_accept_session_reply_hton(vapi_msg_accept_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_accept_session_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_accept_session_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_accept_session_reply_ntoh(vapi_msg_accept_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_accept_session_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_accept_session_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bind_uri_reply_payload_hton(vapi_payload_bind_uri_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_bind_uri_reply_payload_ntoh(vapi_payload_bind_uri_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_bind_uri_reply_msg_size(vapi_msg_bind_uri_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bind_uri_reply_hton(vapi_msg_bind_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_uri_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_bind_uri_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_bind_uri_reply_ntoh(vapi_msg_bind_uri_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_uri_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_bind_uri_reply_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_connect_session_msg_size(vapi_msg_connect_session *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_session_hton(vapi_msg_connect_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_session'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_connect_session_ntoh(vapi_msg_connect_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_session'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_application_detach_reply_payload_hton(vapi_payload_application_detach_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_application_detach_reply_payload_ntoh(vapi_payload_application_detach_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_application_detach_reply_msg_size(vapi_msg_application_detach_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_application_detach_reply_hton(vapi_msg_application_detach_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_detach_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_application_detach_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_application_detach_reply_ntoh(vapi_msg_application_detach_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_detach_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_application_detach_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_application_attach_reply_payload_hton(vapi_payload_application_attach_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->app_event_queue_address = htobe64(payload->app_event_queue_address);
  payload->segment_size = htobe32(payload->segment_size);
}

static inline void vapi_msg_application_attach_reply_payload_ntoh(vapi_payload_application_attach_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->app_event_queue_address = be64toh(payload->app_event_queue_address);
  payload->segment_size = be32toh(payload->segment_size);
}

static inline uword vapi_calc_application_attach_reply_msg_size(vapi_msg_application_attach_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_application_attach_reply_hton(vapi_msg_application_attach_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_attach_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_application_attach_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_application_attach_reply_ntoh(vapi_msg_application_attach_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_application_attach_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_application_attach_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_reset_session_reply_payload_hton(vapi_payload_reset_session_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_reset_session_reply_payload_ntoh(vapi_payload_reset_session_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_reset_session_reply_msg_size(vapi_msg_reset_session_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_reset_session_reply_hton(vapi_msg_reset_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_session_reply'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_reset_session_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_reset_session_reply_ntoh(vapi_msg_reset_session_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_reset_session_reply'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_reset_session_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_another_segment_reply_payload_hton(vapi_payload_map_another_segment_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_map_another_segment_reply_payload_ntoh(vapi_payload_map_another_segment_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_map_another_segment_reply_msg_size(vapi_msg_map_another_segment_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_another_segment_reply_hton(vapi_msg_map_another_segment_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_another_segment_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_another_segment_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_another_segment_reply_ntoh(vapi_msg_map_another_segment_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_another_segment_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_another_segment_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_connect_uri_payload_hton(vapi_payload_connect_uri *payload)
{
  payload->client_queue_address = htobe64(payload->client_queue_address);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = htobe64(payload->options[i]); } } while(0);
}

static inline void vapi_msg_connect_uri_payload_ntoh(vapi_payload_connect_uri *payload)
{
  payload->client_queue_address = be64toh(payload->client_queue_address);
  do { unsigned i; for (i = 0; i < 16; ++i) { payload->options[i] = be64toh(payload->options[i]); } } while(0);
}

static inline uword vapi_calc_connect_uri_msg_size(vapi_msg_connect_uri *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_uri_hton(vapi_msg_connect_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_uri'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_connect_uri_payload_hton(&msg->payload);
}

static inline void vapi_msg_connect_uri_ntoh(vapi_msg_connect_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_uri'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_connect_uri_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bind_uri_payload_hton(vapi_payload_bind_uri *payload)
{
  payload->accept_cookie = htobe32(payload->accept_cookie);
}

static inline void vapi_msg_bind_uri_payload_ntoh(vapi_payload_bind_uri *payload)
{
  payload->accept_cookie = be32toh(payload->accept_cookie);
}

static inline uword vapi_calc_bind_uri_msg_size(vapi_msg_bind_uri *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bind_uri_hton(vapi_msg_bind_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_uri'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_bind_uri_payload_hton(&msg->payload);
}

static inline void vapi_msg_bind_uri_ntoh(vapi_msg_bind_uri *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_uri'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_bind_uri_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_disconnect_session_payload_hton(vapi_payload_disconnect_session *payload)
{
  payload->handle = htobe64(payload->handle);
}

static inline void vapi_msg_disconnect_session_payload_ntoh(vapi_payload_disconnect_session *payload)
{
  payload->handle = be64toh(payload->handle);
}

static inline uword vapi_calc_disconnect_session_msg_size(vapi_msg_disconnect_session *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_disconnect_session_hton(vapi_msg_disconnect_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_disconnect_session'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_disconnect_session_payload_hton(&msg->payload);
}

static inline void vapi_msg_disconnect_session_ntoh(vapi_msg_disconnect_session *msg)
{
  VAPI_DBG("Swapping `vapi_msg_disconnect_session'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_disconnect_session_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_connect_sock_reply_payload_hton(vapi_payload_connect_sock_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_connect_sock_reply_payload_ntoh(vapi_payload_connect_sock_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_connect_sock_reply_msg_size(vapi_msg_connect_sock_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_connect_sock_reply_hton(vapi_msg_connect_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_sock_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_connect_sock_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_connect_sock_reply_ntoh(vapi_msg_connect_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_connect_sock_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_connect_sock_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_bind_sock_reply_payload_hton(vapi_payload_bind_sock_reply *payload)
{
  payload->handle = htobe64(payload->handle);
  payload->retval = htobe32(payload->retval);
  payload->server_event_queue_address = htobe64(payload->server_event_queue_address);
  payload->segment_size = htobe32(payload->segment_size);
}

static inline void vapi_msg_bind_sock_reply_payload_ntoh(vapi_payload_bind_sock_reply *payload)
{
  payload->handle = be64toh(payload->handle);
  payload->retval = be32toh(payload->retval);
  payload->server_event_queue_address = be64toh(payload->server_event_queue_address);
  payload->segment_size = be32toh(payload->segment_size);
}

static inline uword vapi_calc_bind_sock_reply_msg_size(vapi_msg_bind_sock_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_bind_sock_reply_hton(vapi_msg_bind_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_sock_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_bind_sock_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_bind_sock_reply_ntoh(vapi_msg_bind_sock_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_bind_sock_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_bind_sock_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_session_enable_disable_payload_hton(vapi_payload_session_enable_disable *payload)
{

}

static inline void vapi_msg_session_enable_disable_payload_ntoh(vapi_payload_session_enable_disable *payload)
{

}

static inline uword vapi_calc_session_enable_disable_msg_size(vapi_msg_session_enable_disable *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_session_enable_disable_hton(vapi_msg_session_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_session_enable_disable'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_session_enable_disable_payload_hton(&msg->payload);
}

static inline void vapi_msg_session_enable_disable_ntoh(vapi_msg_session_enable_disable *msg)
{
  VAPI_DBG("Swapping `vapi_msg_session_enable_disable'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_session_enable_disable_payload_ntoh(&msg->payload);
}

static inline vapi_msg_accept_session* vapi_alloc_accept_session(struct vapi_ctx_s *ctx)
{
  vapi_msg_accept_session *msg = NULL;
  const size_t size = sizeof(vapi_msg_accept_session);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_accept_session*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_accept_session);

  return msg;
}

static inline vapi_error_e vapi_accept_session(struct vapi_ctx_s *ctx,
  vapi_msg_accept_session *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_accept_session_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_accept_session_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_accept_session_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_application_detach* vapi_alloc_application_detach(struct vapi_ctx_s *ctx)
{
  vapi_msg_application_detach *msg = NULL;
  const size_t size = sizeof(vapi_msg_application_detach);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_application_detach*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_application_detach);

  return msg;
}

static inline vapi_error_e vapi_application_detach(struct vapi_ctx_s *ctx,
  vapi_msg_application_detach *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_application_detach_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_application_detach_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_application_detach_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_application_attach* vapi_alloc_application_attach(struct vapi_ctx_s *ctx)
{
  vapi_msg_application_attach *msg = NULL;
  const size_t size = sizeof(vapi_msg_application_attach);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_application_attach*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_application_attach);

  return msg;
}

static inline vapi_error_e vapi_application_attach(struct vapi_ctx_s *ctx,
  vapi_msg_application_attach *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_application_attach_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_application_attach_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_application_attach_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_reset_session* vapi_alloc_reset_session(struct vapi_ctx_s *ctx)
{
  vapi_msg_reset_session *msg = NULL;
  const size_t size = sizeof(vapi_msg_reset_session);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_reset_session*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_reset_session);

  return msg;
}

static inline vapi_error_e vapi_reset_session(struct vapi_ctx_s *ctx,
  vapi_msg_reset_session *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_reset_session_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_reset_session_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_reset_session_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_unbind_sock* vapi_alloc_unbind_sock(struct vapi_ctx_s *ctx)
{
  vapi_msg_unbind_sock *msg = NULL;
  const size_t size = sizeof(vapi_msg_unbind_sock);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_unbind_sock*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_unbind_sock);

  return msg;
}

static inline vapi_error_e vapi_unbind_sock(struct vapi_ctx_s *ctx,
  vapi_msg_unbind_sock *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_unbind_sock_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_unbind_sock_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_unbind_sock_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_another_segment* vapi_alloc_map_another_segment(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_another_segment *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_another_segment);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_another_segment*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_another_segment);

  return msg;
}

static inline vapi_error_e vapi_map_another_segment(struct vapi_ctx_s *ctx,
  vapi_msg_map_another_segment *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_another_segment_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_another_segment_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_another_segment_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_connect_sock* vapi_alloc_connect_sock(struct vapi_ctx_s *ctx)
{
  vapi_msg_connect_sock *msg = NULL;
  const size_t size = sizeof(vapi_msg_connect_sock);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_connect_sock*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_connect_sock);

  return msg;
}

static inline vapi_error_e vapi_connect_sock(struct vapi_ctx_s *ctx,
  vapi_msg_connect_sock *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_connect_sock_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_connect_sock_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_connect_sock_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_unbind_uri* vapi_alloc_unbind_uri(struct vapi_ctx_s *ctx)
{
  vapi_msg_unbind_uri *msg = NULL;
  const size_t size = sizeof(vapi_msg_unbind_uri);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_unbind_uri*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_unbind_uri);

  return msg;
}

static inline vapi_error_e vapi_unbind_uri(struct vapi_ctx_s *ctx,
  vapi_msg_unbind_uri *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_unbind_uri_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_unbind_uri_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_unbind_uri_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_bind_sock* vapi_alloc_bind_sock(struct vapi_ctx_s *ctx)
{
  vapi_msg_bind_sock *msg = NULL;
  const size_t size = sizeof(vapi_msg_bind_sock);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_bind_sock*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_bind_sock);

  return msg;
}

static inline vapi_error_e vapi_bind_sock(struct vapi_ctx_s *ctx,
  vapi_msg_bind_sock *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_bind_sock_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_bind_sock_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_bind_sock_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_connect_session* vapi_alloc_connect_session(struct vapi_ctx_s *ctx)
{
  vapi_msg_connect_session *msg = NULL;
  const size_t size = sizeof(vapi_msg_connect_session);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_connect_session*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_connect_session);

  return msg;
}

static inline vapi_error_e vapi_connect_session(struct vapi_ctx_s *ctx,
  vapi_msg_connect_session *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_connect_session_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_connect_session_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_connect_session_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_connect_uri* vapi_alloc_connect_uri(struct vapi_ctx_s *ctx)
{
  vapi_msg_connect_uri *msg = NULL;
  const size_t size = sizeof(vapi_msg_connect_uri);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_connect_uri*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_connect_uri);

  return msg;
}

static inline vapi_error_e vapi_connect_uri(struct vapi_ctx_s *ctx,
  vapi_msg_connect_uri *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_connect_uri_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_connect_uri_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_connect_uri_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_bind_uri* vapi_alloc_bind_uri(struct vapi_ctx_s *ctx)
{
  vapi_msg_bind_uri *msg = NULL;
  const size_t size = sizeof(vapi_msg_bind_uri);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_bind_uri*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_bind_uri);

  return msg;
}

static inline vapi_error_e vapi_bind_uri(struct vapi_ctx_s *ctx,
  vapi_msg_bind_uri *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_bind_uri_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_bind_uri_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_bind_uri_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_disconnect_session* vapi_alloc_disconnect_session(struct vapi_ctx_s *ctx)
{
  vapi_msg_disconnect_session *msg = NULL;
  const size_t size = sizeof(vapi_msg_disconnect_session);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_disconnect_session*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_disconnect_session);

  return msg;
}

static inline vapi_error_e vapi_disconnect_session(struct vapi_ctx_s *ctx,
  vapi_msg_disconnect_session *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_disconnect_session_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_disconnect_session_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_disconnect_session_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_session_enable_disable* vapi_alloc_session_enable_disable(struct vapi_ctx_s *ctx)
{
  vapi_msg_session_enable_disable *msg = NULL;
  const size_t size = sizeof(vapi_msg_session_enable_disable);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_session_enable_disable*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_session_enable_disable);

  return msg;
}

static inline vapi_error_e vapi_session_enable_disable(struct vapi_ctx_s *ctx,
  vapi_msg_session_enable_disable *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_session_enable_disable_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_session_enable_disable_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_session_enable_disable_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_accept_session()
{
  static const char name[] = "accept_session";
  static const char name_with_crc[] = "accept_session_8e2a127e";
  static vapi_message_desc_t __vapi_metadata_accept_session = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_accept_session, payload),
    sizeof(vapi_msg_accept_session),
    (generic_swap_fn_t)vapi_msg_accept_session_hton,
    (generic_swap_fn_t)vapi_msg_accept_session_ntoh,
    ~0,
  };

  vapi_msg_id_accept_session = vapi_register_msg(&__vapi_metadata_accept_session);
  VAPI_DBG("Assigned msg id %d to accept_session", vapi_msg_id_accept_session);
}

static void __attribute__((constructor)) __vapi_constructor_application_detach()
{
  static const char name[] = "application_detach";
  static const char name_with_crc[] = "application_detach_bf7e4352";
  static vapi_message_desc_t __vapi_metadata_application_detach = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_application_detach),
    (generic_swap_fn_t)vapi_msg_application_detach_hton,
    (generic_swap_fn_t)vapi_msg_application_detach_ntoh,
    ~0,
  };

  vapi_msg_id_application_detach = vapi_register_msg(&__vapi_metadata_application_detach);
  VAPI_DBG("Assigned msg id %d to application_detach", vapi_msg_id_application_detach);
}

static void __attribute__((constructor)) __vapi_constructor_application_attach()
{
  static const char name[] = "application_attach";
  static const char name_with_crc[] = "application_attach_e589ec93";
  static vapi_message_desc_t __vapi_metadata_application_attach = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_application_attach, payload),
    sizeof(vapi_msg_application_attach),
    (generic_swap_fn_t)vapi_msg_application_attach_hton,
    (generic_swap_fn_t)vapi_msg_application_attach_ntoh,
    ~0,
  };

  vapi_msg_id_application_attach = vapi_register_msg(&__vapi_metadata_application_attach);
  VAPI_DBG("Assigned msg id %d to application_attach", vapi_msg_id_application_attach);
}

static void __attribute__((constructor)) __vapi_constructor_reset_session()
{
  static const char name[] = "reset_session";
  static const char name_with_crc[] = "reset_session_601fefd7";
  static vapi_message_desc_t __vapi_metadata_reset_session = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_reset_session, payload),
    sizeof(vapi_msg_reset_session),
    (generic_swap_fn_t)vapi_msg_reset_session_hton,
    (generic_swap_fn_t)vapi_msg_reset_session_ntoh,
    ~0,
  };

  vapi_msg_id_reset_session = vapi_register_msg(&__vapi_metadata_reset_session);
  VAPI_DBG("Assigned msg id %d to reset_session", vapi_msg_id_reset_session);
}

static void __attribute__((constructor)) __vapi_constructor_unbind_sock()
{
  static const char name[] = "unbind_sock";
  static const char name_with_crc[] = "unbind_sock_9007c8c9";
  static vapi_message_desc_t __vapi_metadata_unbind_sock = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_unbind_sock, payload),
    sizeof(vapi_msg_unbind_sock),
    (generic_swap_fn_t)vapi_msg_unbind_sock_hton,
    (generic_swap_fn_t)vapi_msg_unbind_sock_ntoh,
    ~0,
  };

  vapi_msg_id_unbind_sock = vapi_register_msg(&__vapi_metadata_unbind_sock);
  VAPI_DBG("Assigned msg id %d to unbind_sock", vapi_msg_id_unbind_sock);
}

static void __attribute__((constructor)) __vapi_constructor_connect_uri_reply()
{
  static const char name[] = "connect_uri_reply";
  static const char name_with_crc[] = "connect_uri_reply_54ec1256";
  static vapi_message_desc_t __vapi_metadata_connect_uri_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_connect_uri_reply, payload),
    sizeof(vapi_msg_connect_uri_reply),
    (generic_swap_fn_t)vapi_msg_connect_uri_reply_hton,
    (generic_swap_fn_t)vapi_msg_connect_uri_reply_ntoh,
    ~0,
  };

  vapi_msg_id_connect_uri_reply = vapi_register_msg(&__vapi_metadata_connect_uri_reply);
  VAPI_DBG("Assigned msg id %d to connect_uri_reply", vapi_msg_id_connect_uri_reply);
}

static void __attribute__((constructor)) __vapi_constructor_connect_session_reply()
{
  static const char name[] = "connect_session_reply";
  static const char name_with_crc[] = "connect_session_reply_1c779aca";
  static vapi_message_desc_t __vapi_metadata_connect_session_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_connect_session_reply, payload),
    sizeof(vapi_msg_connect_session_reply),
    (generic_swap_fn_t)vapi_msg_connect_session_reply_hton,
    (generic_swap_fn_t)vapi_msg_connect_session_reply_ntoh,
    ~0,
  };

  vapi_msg_id_connect_session_reply = vapi_register_msg(&__vapi_metadata_connect_session_reply);
  VAPI_DBG("Assigned msg id %d to connect_session_reply", vapi_msg_id_connect_session_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_another_segment()
{
  static const char name[] = "map_another_segment";
  static const char name_with_crc[] = "map_another_segment_28ca2003";
  static vapi_message_desc_t __vapi_metadata_map_another_segment = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_map_another_segment, payload),
    sizeof(vapi_msg_map_another_segment),
    (generic_swap_fn_t)vapi_msg_map_another_segment_hton,
    (generic_swap_fn_t)vapi_msg_map_another_segment_ntoh,
    ~0,
  };

  vapi_msg_id_map_another_segment = vapi_register_msg(&__vapi_metadata_map_another_segment);
  VAPI_DBG("Assigned msg id %d to map_another_segment", vapi_msg_id_map_another_segment);
}

static void __attribute__((constructor)) __vapi_constructor_disconnect_session_reply()
{
  static const char name[] = "disconnect_session_reply";
  static const char name_with_crc[] = "disconnect_session_reply_6fb16b8f";
  static vapi_message_desc_t __vapi_metadata_disconnect_session_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_disconnect_session_reply, payload),
    sizeof(vapi_msg_disconnect_session_reply),
    (generic_swap_fn_t)vapi_msg_disconnect_session_reply_hton,
    (generic_swap_fn_t)vapi_msg_disconnect_session_reply_ntoh,
    ~0,
  };

  vapi_msg_id_disconnect_session_reply = vapi_register_msg(&__vapi_metadata_disconnect_session_reply);
  VAPI_DBG("Assigned msg id %d to disconnect_session_reply", vapi_msg_id_disconnect_session_reply);
}

static void __attribute__((constructor)) __vapi_constructor_unbind_sock_reply()
{
  static const char name[] = "unbind_sock_reply";
  static const char name_with_crc[] = "unbind_sock_reply_5d9c5da6";
  static vapi_message_desc_t __vapi_metadata_unbind_sock_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_unbind_sock_reply, payload),
    sizeof(vapi_msg_unbind_sock_reply),
    (generic_swap_fn_t)vapi_msg_unbind_sock_reply_hton,
    (generic_swap_fn_t)vapi_msg_unbind_sock_reply_ntoh,
    ~0,
  };

  vapi_msg_id_unbind_sock_reply = vapi_register_msg(&__vapi_metadata_unbind_sock_reply);
  VAPI_DBG("Assigned msg id %d to unbind_sock_reply", vapi_msg_id_unbind_sock_reply);
}

static void __attribute__((constructor)) __vapi_constructor_connect_sock()
{
  static const char name[] = "connect_sock";
  static const char name_with_crc[] = "connect_sock_3e66becf";
  static vapi_message_desc_t __vapi_metadata_connect_sock = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_connect_sock, payload),
    sizeof(vapi_msg_connect_sock),
    (generic_swap_fn_t)vapi_msg_connect_sock_hton,
    (generic_swap_fn_t)vapi_msg_connect_sock_ntoh,
    ~0,
  };

  vapi_msg_id_connect_sock = vapi_register_msg(&__vapi_metadata_connect_sock);
  VAPI_DBG("Assigned msg id %d to connect_sock", vapi_msg_id_connect_sock);
}

static void __attribute__((constructor)) __vapi_constructor_unbind_uri()
{
  static const char name[] = "unbind_uri";
  static const char name_with_crc[] = "unbind_uri_46569743";
  static vapi_message_desc_t __vapi_metadata_unbind_uri = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_unbind_uri, payload),
    sizeof(vapi_msg_unbind_uri),
    (generic_swap_fn_t)vapi_msg_unbind_uri_hton,
    (generic_swap_fn_t)vapi_msg_unbind_uri_ntoh,
    ~0,
  };

  vapi_msg_id_unbind_uri = vapi_register_msg(&__vapi_metadata_unbind_uri);
  VAPI_DBG("Assigned msg id %d to unbind_uri", vapi_msg_id_unbind_uri);
}

static void __attribute__((constructor)) __vapi_constructor_unbind_uri_reply()
{
  static const char name[] = "unbind_uri_reply";
  static const char name_with_crc[] = "unbind_uri_reply_310db78f";
  static vapi_message_desc_t __vapi_metadata_unbind_uri_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_unbind_uri_reply, payload),
    sizeof(vapi_msg_unbind_uri_reply),
    (generic_swap_fn_t)vapi_msg_unbind_uri_reply_hton,
    (generic_swap_fn_t)vapi_msg_unbind_uri_reply_ntoh,
    ~0,
  };

  vapi_msg_id_unbind_uri_reply = vapi_register_msg(&__vapi_metadata_unbind_uri_reply);
  VAPI_DBG("Assigned msg id %d to unbind_uri_reply", vapi_msg_id_unbind_uri_reply);
}

static void __attribute__((constructor)) __vapi_constructor_session_enable_disable_reply()
{
  static const char name[] = "session_enable_disable_reply";
  static const char name_with_crc[] = "session_enable_disable_reply_cfb0e390";
  static vapi_message_desc_t __vapi_metadata_session_enable_disable_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_session_enable_disable_reply, payload),
    sizeof(vapi_msg_session_enable_disable_reply),
    (generic_swap_fn_t)vapi_msg_session_enable_disable_reply_hton,
    (generic_swap_fn_t)vapi_msg_session_enable_disable_reply_ntoh,
    ~0,
  };

  vapi_msg_id_session_enable_disable_reply = vapi_register_msg(&__vapi_metadata_session_enable_disable_reply);
  VAPI_DBG("Assigned msg id %d to session_enable_disable_reply", vapi_msg_id_session_enable_disable_reply);
}

static void __attribute__((constructor)) __vapi_constructor_bind_sock()
{
  static const char name[] = "bind_sock";
  static const char name_with_crc[] = "bind_sock_3f898291";
  static vapi_message_desc_t __vapi_metadata_bind_sock = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_bind_sock, payload),
    sizeof(vapi_msg_bind_sock),
    (generic_swap_fn_t)vapi_msg_bind_sock_hton,
    (generic_swap_fn_t)vapi_msg_bind_sock_ntoh,
    ~0,
  };

  vapi_msg_id_bind_sock = vapi_register_msg(&__vapi_metadata_bind_sock);
  VAPI_DBG("Assigned msg id %d to bind_sock", vapi_msg_id_bind_sock);
}

static void __attribute__((constructor)) __vapi_constructor_accept_session_reply()
{
  static const char name[] = "accept_session_reply";
  static const char name_with_crc[] = "accept_session_reply_67d8c22a";
  static vapi_message_desc_t __vapi_metadata_accept_session_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_accept_session_reply, payload),
    sizeof(vapi_msg_accept_session_reply),
    (generic_swap_fn_t)vapi_msg_accept_session_reply_hton,
    (generic_swap_fn_t)vapi_msg_accept_session_reply_ntoh,
    ~0,
  };

  vapi_msg_id_accept_session_reply = vapi_register_msg(&__vapi_metadata_accept_session_reply);
  VAPI_DBG("Assigned msg id %d to accept_session_reply", vapi_msg_id_accept_session_reply);
}

static void __attribute__((constructor)) __vapi_constructor_bind_uri_reply()
{
  static const char name[] = "bind_uri_reply";
  static const char name_with_crc[] = "bind_uri_reply_75918978";
  static vapi_message_desc_t __vapi_metadata_bind_uri_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_bind_uri_reply, payload),
    sizeof(vapi_msg_bind_uri_reply),
    (generic_swap_fn_t)vapi_msg_bind_uri_reply_hton,
    (generic_swap_fn_t)vapi_msg_bind_uri_reply_ntoh,
    ~0,
  };

  vapi_msg_id_bind_uri_reply = vapi_register_msg(&__vapi_metadata_bind_uri_reply);
  VAPI_DBG("Assigned msg id %d to bind_uri_reply", vapi_msg_id_bind_uri_reply);
}

static void __attribute__((constructor)) __vapi_constructor_connect_session()
{
  static const char name[] = "connect_session";
  static const char name_with_crc[] = "connect_session_40ae01d1";
  static vapi_message_desc_t __vapi_metadata_connect_session = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_connect_session),
    (generic_swap_fn_t)vapi_msg_connect_session_hton,
    (generic_swap_fn_t)vapi_msg_connect_session_ntoh,
    ~0,
  };

  vapi_msg_id_connect_session = vapi_register_msg(&__vapi_metadata_connect_session);
  VAPI_DBG("Assigned msg id %d to connect_session", vapi_msg_id_connect_session);
}

static void __attribute__((constructor)) __vapi_constructor_application_detach_reply()
{
  static const char name[] = "application_detach_reply";
  static const char name_with_crc[] = "application_detach_reply_fb879289";
  static vapi_message_desc_t __vapi_metadata_application_detach_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_application_detach_reply, payload),
    sizeof(vapi_msg_application_detach_reply),
    (generic_swap_fn_t)vapi_msg_application_detach_reply_hton,
    (generic_swap_fn_t)vapi_msg_application_detach_reply_ntoh,
    ~0,
  };

  vapi_msg_id_application_detach_reply = vapi_register_msg(&__vapi_metadata_application_detach_reply);
  VAPI_DBG("Assigned msg id %d to application_detach_reply", vapi_msg_id_application_detach_reply);
}

static void __attribute__((constructor)) __vapi_constructor_application_attach_reply()
{
  static const char name[] = "application_attach_reply";
  static const char name_with_crc[] = "application_attach_reply_0df5c138";
  static vapi_message_desc_t __vapi_metadata_application_attach_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_application_attach_reply, payload),
    sizeof(vapi_msg_application_attach_reply),
    (generic_swap_fn_t)vapi_msg_application_attach_reply_hton,
    (generic_swap_fn_t)vapi_msg_application_attach_reply_ntoh,
    ~0,
  };

  vapi_msg_id_application_attach_reply = vapi_register_msg(&__vapi_metadata_application_attach_reply);
  VAPI_DBG("Assigned msg id %d to application_attach_reply", vapi_msg_id_application_attach_reply);
}

static void __attribute__((constructor)) __vapi_constructor_reset_session_reply()
{
  static const char name[] = "reset_session_reply";
  static const char name_with_crc[] = "reset_session_reply_80f6c14f";
  static vapi_message_desc_t __vapi_metadata_reset_session_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_reset_session_reply, payload),
    sizeof(vapi_msg_reset_session_reply),
    (generic_swap_fn_t)vapi_msg_reset_session_reply_hton,
    (generic_swap_fn_t)vapi_msg_reset_session_reply_ntoh,
    ~0,
  };

  vapi_msg_id_reset_session_reply = vapi_register_msg(&__vapi_metadata_reset_session_reply);
  VAPI_DBG("Assigned msg id %d to reset_session_reply", vapi_msg_id_reset_session_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_another_segment_reply()
{
  static const char name[] = "map_another_segment_reply";
  static const char name_with_crc[] = "map_another_segment_reply_76d11a9d";
  static vapi_message_desc_t __vapi_metadata_map_another_segment_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_another_segment_reply, payload),
    sizeof(vapi_msg_map_another_segment_reply),
    (generic_swap_fn_t)vapi_msg_map_another_segment_reply_hton,
    (generic_swap_fn_t)vapi_msg_map_another_segment_reply_ntoh,
    ~0,
  };

  vapi_msg_id_map_another_segment_reply = vapi_register_msg(&__vapi_metadata_map_another_segment_reply);
  VAPI_DBG("Assigned msg id %d to map_another_segment_reply", vapi_msg_id_map_another_segment_reply);
}

static void __attribute__((constructor)) __vapi_constructor_connect_uri()
{
  static const char name[] = "connect_uri";
  static const char name_with_crc[] = "connect_uri_80474aff";
  static vapi_message_desc_t __vapi_metadata_connect_uri = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_connect_uri, payload),
    sizeof(vapi_msg_connect_uri),
    (generic_swap_fn_t)vapi_msg_connect_uri_hton,
    (generic_swap_fn_t)vapi_msg_connect_uri_ntoh,
    ~0,
  };

  vapi_msg_id_connect_uri = vapi_register_msg(&__vapi_metadata_connect_uri);
  VAPI_DBG("Assigned msg id %d to connect_uri", vapi_msg_id_connect_uri);
}

static void __attribute__((constructor)) __vapi_constructor_bind_uri()
{
  static const char name[] = "bind_uri";
  static const char name_with_crc[] = "bind_uri_ceafed7f";
  static vapi_message_desc_t __vapi_metadata_bind_uri = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_bind_uri, payload),
    sizeof(vapi_msg_bind_uri),
    (generic_swap_fn_t)vapi_msg_bind_uri_hton,
    (generic_swap_fn_t)vapi_msg_bind_uri_ntoh,
    ~0,
  };

  vapi_msg_id_bind_uri = vapi_register_msg(&__vapi_metadata_bind_uri);
  VAPI_DBG("Assigned msg id %d to bind_uri", vapi_msg_id_bind_uri);
}

static void __attribute__((constructor)) __vapi_constructor_disconnect_session()
{
  static const char name[] = "disconnect_session";
  static const char name_with_crc[] = "disconnect_session_18addf61";
  static vapi_message_desc_t __vapi_metadata_disconnect_session = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_disconnect_session, payload),
    sizeof(vapi_msg_disconnect_session),
    (generic_swap_fn_t)vapi_msg_disconnect_session_hton,
    (generic_swap_fn_t)vapi_msg_disconnect_session_ntoh,
    ~0,
  };

  vapi_msg_id_disconnect_session = vapi_register_msg(&__vapi_metadata_disconnect_session);
  VAPI_DBG("Assigned msg id %d to disconnect_session", vapi_msg_id_disconnect_session);
}

static void __attribute__((constructor)) __vapi_constructor_connect_sock_reply()
{
  static const char name[] = "connect_sock_reply";
  static const char name_with_crc[] = "connect_sock_reply_f6988664";
  static vapi_message_desc_t __vapi_metadata_connect_sock_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_connect_sock_reply, payload),
    sizeof(vapi_msg_connect_sock_reply),
    (generic_swap_fn_t)vapi_msg_connect_sock_reply_hton,
    (generic_swap_fn_t)vapi_msg_connect_sock_reply_ntoh,
    ~0,
  };

  vapi_msg_id_connect_sock_reply = vapi_register_msg(&__vapi_metadata_connect_sock_reply);
  VAPI_DBG("Assigned msg id %d to connect_sock_reply", vapi_msg_id_connect_sock_reply);
}

static void __attribute__((constructor)) __vapi_constructor_bind_sock_reply()
{
  static const char name[] = "bind_sock_reply";
  static const char name_with_crc[] = "bind_sock_reply_eecef9cc";
  static vapi_message_desc_t __vapi_metadata_bind_sock_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_bind_sock_reply, payload),
    sizeof(vapi_msg_bind_sock_reply),
    (generic_swap_fn_t)vapi_msg_bind_sock_reply_hton,
    (generic_swap_fn_t)vapi_msg_bind_sock_reply_ntoh,
    ~0,
  };

  vapi_msg_id_bind_sock_reply = vapi_register_msg(&__vapi_metadata_bind_sock_reply);
  VAPI_DBG("Assigned msg id %d to bind_sock_reply", vapi_msg_id_bind_sock_reply);
}

static void __attribute__((constructor)) __vapi_constructor_session_enable_disable()
{
  static const char name[] = "session_enable_disable";
  static const char name_with_crc[] = "session_enable_disable_a4cfced4";
  static vapi_message_desc_t __vapi_metadata_session_enable_disable = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_session_enable_disable, payload),
    sizeof(vapi_msg_session_enable_disable),
    (generic_swap_fn_t)vapi_msg_session_enable_disable_hton,
    (generic_swap_fn_t)vapi_msg_session_enable_disable_ntoh,
    ~0,
  };

  vapi_msg_id_session_enable_disable = vapi_register_msg(&__vapi_metadata_session_enable_disable);
  VAPI_DBG("Assigned msg id %d to session_enable_disable", vapi_msg_id_session_enable_disable);
}


static inline void vapi_set_vapi_msg_connect_uri_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_connect_uri_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_connect_uri_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_connect_session_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_connect_session_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_connect_session_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_disconnect_session_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_disconnect_session_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_disconnect_session_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_unbind_sock_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_unbind_sock_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_unbind_sock_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_unbind_uri_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_unbind_uri_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_unbind_uri_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_session_enable_disable_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_session_enable_disable_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_session_enable_disable_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_accept_session_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_accept_session_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_accept_session_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_bind_uri_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_bind_uri_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_bind_uri_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_application_detach_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_application_detach_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_application_detach_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_application_attach_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_application_attach_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_application_attach_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_reset_session_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_reset_session_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_reset_session_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_another_segment_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_another_segment_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_another_segment_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_connect_sock_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_connect_sock_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_connect_sock_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_bind_sock_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_bind_sock_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_bind_sock_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
