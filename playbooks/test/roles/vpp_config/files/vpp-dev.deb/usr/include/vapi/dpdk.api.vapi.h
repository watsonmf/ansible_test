#ifndef __included_dpdk_api_json
#define __included_dpdk_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_subport;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_pipe;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply;
extern vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply;

#define DEFINE_VAPI_MSG_IDS_DPDK_API_JSON\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_subport;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_pipe;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply;\
  vapi_msg_id_t vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply;


typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_dpdk_hqos_subport_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_subport_reply payload;
} vapi_msg_sw_interface_set_dpdk_hqos_subport_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 entry;
  u32 tc;
  u32 queue; 
} vapi_payload_sw_interface_set_dpdk_hqos_tctbl;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_tctbl payload;
} vapi_msg_sw_interface_set_dpdk_hqos_tctbl;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 subport;
  u32 tb_rate;
  u32 tb_size;
  u32 tc_rate[4];
  u32 tc_period; 
} vapi_payload_sw_interface_set_dpdk_hqos_subport;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_subport payload;
} vapi_msg_sw_interface_set_dpdk_hqos_subport;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u32 subport;
  u32 pipe;
  u32 profile; 
} vapi_payload_sw_interface_set_dpdk_hqos_pipe;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_pipe payload;
} vapi_msg_sw_interface_set_dpdk_hqos_pipe;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply payload;
} vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply payload;
} vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply;


static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_subport_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_subport_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_subport_reply_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_hton(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_subport_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_subport_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_tctbl *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->entry = htobe32(payload->entry);
  payload->tc = htobe32(payload->tc);
  payload->queue = htobe32(payload->queue);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_tctbl *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->entry = be32toh(payload->entry);
  payload->tc = be32toh(payload->tc);
  payload->queue = be32toh(payload->queue);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_tctbl_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_hton(vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_tctbl'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_tctbl'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_subport *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->subport = htobe32(payload->subport);
  payload->tb_rate = htobe32(payload->tb_rate);
  payload->tb_size = htobe32(payload->tb_size);
  do { unsigned i; for (i = 0; i < 4; ++i) { payload->tc_rate[i] = htobe32(payload->tc_rate[i]); } } while(0);
  payload->tc_period = htobe32(payload->tc_period);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_subport *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->subport = be32toh(payload->subport);
  payload->tb_rate = be32toh(payload->tb_rate);
  payload->tb_size = be32toh(payload->tb_size);
  do { unsigned i; for (i = 0; i < 4; ++i) { payload->tc_rate[i] = be32toh(payload->tc_rate[i]); } } while(0);
  payload->tc_period = be32toh(payload->tc_period);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_subport_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_subport *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_hton(vapi_msg_sw_interface_set_dpdk_hqos_subport *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_subport'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_subport_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_subport_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_subport *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_subport'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_subport_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_pipe *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->subport = htobe32(payload->subport);
  payload->pipe = htobe32(payload->pipe);
  payload->profile = htobe32(payload->profile);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_pipe *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->subport = be32toh(payload->subport);
  payload->pipe = be32toh(payload->pipe);
  payload->profile = be32toh(payload->profile);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_pipe_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_hton(vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_pipe'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_pipe'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_tctbl_reply_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_hton(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_payload_hton(vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_payload_ntoh(vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_sw_interface_set_dpdk_hqos_pipe_reply_msg_size(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_hton(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_ntoh(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_payload_ntoh(&msg->payload);
}

static inline vapi_msg_sw_interface_set_dpdk_hqos_tctbl* vapi_alloc_sw_interface_set_dpdk_hqos_tctbl(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_dpdk_hqos_tctbl);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_dpdk_hqos_tctbl*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_dpdk_hqos_tctbl(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_dpdk_hqos_tctbl_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_dpdk_hqos_subport* vapi_alloc_sw_interface_set_dpdk_hqos_subport(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_dpdk_hqos_subport);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_dpdk_hqos_subport*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_subport);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_dpdk_hqos_subport(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_dpdk_hqos_subport *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_dpdk_hqos_subport_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_dpdk_hqos_subport_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_dpdk_hqos_subport_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_sw_interface_set_dpdk_hqos_pipe* vapi_alloc_sw_interface_set_dpdk_hqos_pipe(struct vapi_ctx_s *ctx)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg = NULL;
  const size_t size = sizeof(vapi_msg_sw_interface_set_dpdk_hqos_pipe);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_sw_interface_set_dpdk_hqos_pipe*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_pipe);

  return msg;
}

static inline vapi_error_e vapi_sw_interface_set_dpdk_hqos_pipe(struct vapi_ctx_s *ctx,
  vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_sw_interface_set_dpdk_hqos_pipe_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_subport_reply()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_subport_reply";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_subport_reply_147f258a";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_subport_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_subport_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_subport_reply", vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_tctbl()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_tctbl";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_tctbl_f9d98f13";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_tctbl = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_tctbl, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_tctbl),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_tctbl_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_tctbl_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_tctbl);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_tctbl", vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_subport()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_subport";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_subport_05a9fa2c";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_subport = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_subport, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_subport),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_subport_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_subport_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_subport = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_subport);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_subport", vapi_msg_id_sw_interface_set_dpdk_hqos_subport);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_pipe()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_pipe";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_pipe_be9b2181";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_pipe = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_pipe, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_pipe),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_pipe_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_pipe_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_pipe = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_pipe);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_pipe", vapi_msg_id_sw_interface_set_dpdk_hqos_pipe);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_tctbl_reply()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_tctbl_reply";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_tctbl_reply_4e2f524d";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_tctbl_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_tctbl_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_tctbl_reply", vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply);
}

static void __attribute__((constructor)) __vapi_constructor_sw_interface_set_dpdk_hqos_pipe_reply()
{
  static const char name[] = "sw_interface_set_dpdk_hqos_pipe_reply";
  static const char name_with_crc[] = "sw_interface_set_dpdk_hqos_pipe_reply_1222fa49";
  static vapi_message_desc_t __vapi_metadata_sw_interface_set_dpdk_hqos_pipe_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply, payload),
    sizeof(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply),
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_hton,
    (generic_swap_fn_t)vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_ntoh,
    ~0,
  };

  vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply = vapi_register_msg(&__vapi_metadata_sw_interface_set_dpdk_hqos_pipe_reply);
  VAPI_DBG("Assigned msg id %d to sw_interface_set_dpdk_hqos_pipe_reply", vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply);
}


static inline void vapi_set_vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_dpdk_hqos_subport_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_dpdk_hqos_tctbl_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_sw_interface_set_dpdk_hqos_pipe_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
