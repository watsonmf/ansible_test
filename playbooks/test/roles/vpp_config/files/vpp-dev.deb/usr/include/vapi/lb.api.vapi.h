#ifndef __included_lb_api_json
#define __included_lb_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_lb_add_del_vip_reply;
extern vapi_msg_id_t vapi_msg_id_lb_add_del_as;
extern vapi_msg_id_t vapi_msg_id_lb_conf_reply;
extern vapi_msg_id_t vapi_msg_id_lb_add_del_as_reply;
extern vapi_msg_id_t vapi_msg_id_lb_conf;
extern vapi_msg_id_t vapi_msg_id_lb_add_del_vip;

#define DEFINE_VAPI_MSG_IDS_LB_API_JSON\
  vapi_msg_id_t vapi_msg_id_lb_add_del_vip_reply;\
  vapi_msg_id_t vapi_msg_id_lb_add_del_as;\
  vapi_msg_id_t vapi_msg_id_lb_conf_reply;\
  vapi_msg_id_t vapi_msg_id_lb_add_del_as_reply;\
  vapi_msg_id_t vapi_msg_id_lb_conf;\
  vapi_msg_id_t vapi_msg_id_lb_add_del_vip;


typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_lb_add_del_vip_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_lb_add_del_vip_reply payload;
} vapi_msg_lb_add_del_vip_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 vip_ip_prefix[16];
  u8 vip_prefix_length;
  u8 as_address[16];
  u8 is_del; 
} vapi_payload_lb_add_del_as;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_lb_add_del_as payload;
} vapi_msg_lb_add_del_as;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_lb_conf_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_lb_conf_reply payload;
} vapi_msg_lb_conf_reply;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_lb_add_del_as_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_lb_add_del_as_reply payload;
} vapi_msg_lb_add_del_as_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 ip4_src_address;
  u8 ip6_src_address[16];
  u32 sticky_buckets_per_core;
  u32 flow_timeout; 
} vapi_payload_lb_conf;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_lb_conf payload;
} vapi_msg_lb_conf;

typedef struct __attribute__ ((__packed__)) {
  u8 ip_prefix[16];
  u8 prefix_length;
  u8 is_gre4;
  u32 new_flows_table_length;
  u8 is_del; 
} vapi_payload_lb_add_del_vip;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_lb_add_del_vip payload;
} vapi_msg_lb_add_del_vip;


static inline void vapi_msg_lb_add_del_vip_reply_payload_hton(vapi_payload_lb_add_del_vip_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_lb_add_del_vip_reply_payload_ntoh(vapi_payload_lb_add_del_vip_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_lb_add_del_vip_reply_msg_size(vapi_msg_lb_add_del_vip_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_add_del_vip_reply_hton(vapi_msg_lb_add_del_vip_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_vip_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_lb_add_del_vip_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_add_del_vip_reply_ntoh(vapi_msg_lb_add_del_vip_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_vip_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_lb_add_del_vip_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_lb_add_del_as_payload_hton(vapi_payload_lb_add_del_as *payload)
{

}

static inline void vapi_msg_lb_add_del_as_payload_ntoh(vapi_payload_lb_add_del_as *payload)
{

}

static inline uword vapi_calc_lb_add_del_as_msg_size(vapi_msg_lb_add_del_as *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_add_del_as_hton(vapi_msg_lb_add_del_as *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_as'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_lb_add_del_as_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_add_del_as_ntoh(vapi_msg_lb_add_del_as *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_as'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_lb_add_del_as_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_lb_conf_reply_payload_hton(vapi_payload_lb_conf_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_lb_conf_reply_payload_ntoh(vapi_payload_lb_conf_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_lb_conf_reply_msg_size(vapi_msg_lb_conf_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_conf_reply_hton(vapi_msg_lb_conf_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_conf_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_lb_conf_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_conf_reply_ntoh(vapi_msg_lb_conf_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_conf_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_lb_conf_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_lb_add_del_as_reply_payload_hton(vapi_payload_lb_add_del_as_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_lb_add_del_as_reply_payload_ntoh(vapi_payload_lb_add_del_as_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_lb_add_del_as_reply_msg_size(vapi_msg_lb_add_del_as_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_add_del_as_reply_hton(vapi_msg_lb_add_del_as_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_as_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_lb_add_del_as_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_add_del_as_reply_ntoh(vapi_msg_lb_add_del_as_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_as_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_lb_add_del_as_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_lb_conf_payload_hton(vapi_payload_lb_conf *payload)
{
  payload->ip4_src_address = htobe32(payload->ip4_src_address);
  payload->sticky_buckets_per_core = htobe32(payload->sticky_buckets_per_core);
  payload->flow_timeout = htobe32(payload->flow_timeout);
}

static inline void vapi_msg_lb_conf_payload_ntoh(vapi_payload_lb_conf *payload)
{
  payload->ip4_src_address = be32toh(payload->ip4_src_address);
  payload->sticky_buckets_per_core = be32toh(payload->sticky_buckets_per_core);
  payload->flow_timeout = be32toh(payload->flow_timeout);
}

static inline uword vapi_calc_lb_conf_msg_size(vapi_msg_lb_conf *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_conf_hton(vapi_msg_lb_conf *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_conf'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_lb_conf_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_conf_ntoh(vapi_msg_lb_conf *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_conf'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_lb_conf_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_lb_add_del_vip_payload_hton(vapi_payload_lb_add_del_vip *payload)
{
  payload->new_flows_table_length = htobe32(payload->new_flows_table_length);
}

static inline void vapi_msg_lb_add_del_vip_payload_ntoh(vapi_payload_lb_add_del_vip *payload)
{
  payload->new_flows_table_length = be32toh(payload->new_flows_table_length);
}

static inline uword vapi_calc_lb_add_del_vip_msg_size(vapi_msg_lb_add_del_vip *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_lb_add_del_vip_hton(vapi_msg_lb_add_del_vip *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_vip'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_lb_add_del_vip_payload_hton(&msg->payload);
}

static inline void vapi_msg_lb_add_del_vip_ntoh(vapi_msg_lb_add_del_vip *msg)
{
  VAPI_DBG("Swapping `vapi_msg_lb_add_del_vip'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_lb_add_del_vip_payload_ntoh(&msg->payload);
}

static inline vapi_msg_lb_add_del_as* vapi_alloc_lb_add_del_as(struct vapi_ctx_s *ctx)
{
  vapi_msg_lb_add_del_as *msg = NULL;
  const size_t size = sizeof(vapi_msg_lb_add_del_as);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_lb_add_del_as*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_lb_add_del_as);

  return msg;
}

static inline vapi_error_e vapi_lb_add_del_as(struct vapi_ctx_s *ctx,
  vapi_msg_lb_add_del_as *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_lb_add_del_as_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_lb_add_del_as_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_lb_add_del_as_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_lb_conf* vapi_alloc_lb_conf(struct vapi_ctx_s *ctx)
{
  vapi_msg_lb_conf *msg = NULL;
  const size_t size = sizeof(vapi_msg_lb_conf);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_lb_conf*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_lb_conf);

  return msg;
}

static inline vapi_error_e vapi_lb_conf(struct vapi_ctx_s *ctx,
  vapi_msg_lb_conf *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_lb_conf_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_lb_conf_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_lb_conf_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_lb_add_del_vip* vapi_alloc_lb_add_del_vip(struct vapi_ctx_s *ctx)
{
  vapi_msg_lb_add_del_vip *msg = NULL;
  const size_t size = sizeof(vapi_msg_lb_add_del_vip);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_lb_add_del_vip*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_lb_add_del_vip);

  return msg;
}

static inline vapi_error_e vapi_lb_add_del_vip(struct vapi_ctx_s *ctx,
  vapi_msg_lb_add_del_vip *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_lb_add_del_vip_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_lb_add_del_vip_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_lb_add_del_vip_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_lb_add_del_vip_reply()
{
  static const char name[] = "lb_add_del_vip_reply";
  static const char name_with_crc[] = "lb_add_del_vip_reply_446cc0f6";
  static vapi_message_desc_t __vapi_metadata_lb_add_del_vip_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_lb_add_del_vip_reply, payload),
    sizeof(vapi_msg_lb_add_del_vip_reply),
    (generic_swap_fn_t)vapi_msg_lb_add_del_vip_reply_hton,
    (generic_swap_fn_t)vapi_msg_lb_add_del_vip_reply_ntoh,
    ~0,
  };

  vapi_msg_id_lb_add_del_vip_reply = vapi_register_msg(&__vapi_metadata_lb_add_del_vip_reply);
  VAPI_DBG("Assigned msg id %d to lb_add_del_vip_reply", vapi_msg_id_lb_add_del_vip_reply);
}

static void __attribute__((constructor)) __vapi_constructor_lb_add_del_as()
{
  static const char name[] = "lb_add_del_as";
  static const char name_with_crc[] = "lb_add_del_as_a74233e4";
  static vapi_message_desc_t __vapi_metadata_lb_add_del_as = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_lb_add_del_as, payload),
    sizeof(vapi_msg_lb_add_del_as),
    (generic_swap_fn_t)vapi_msg_lb_add_del_as_hton,
    (generic_swap_fn_t)vapi_msg_lb_add_del_as_ntoh,
    ~0,
  };

  vapi_msg_id_lb_add_del_as = vapi_register_msg(&__vapi_metadata_lb_add_del_as);
  VAPI_DBG("Assigned msg id %d to lb_add_del_as", vapi_msg_id_lb_add_del_as);
}

static void __attribute__((constructor)) __vapi_constructor_lb_conf_reply()
{
  static const char name[] = "lb_conf_reply";
  static const char name_with_crc[] = "lb_conf_reply_b6b1c34e";
  static vapi_message_desc_t __vapi_metadata_lb_conf_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_lb_conf_reply, payload),
    sizeof(vapi_msg_lb_conf_reply),
    (generic_swap_fn_t)vapi_msg_lb_conf_reply_hton,
    (generic_swap_fn_t)vapi_msg_lb_conf_reply_ntoh,
    ~0,
  };

  vapi_msg_id_lb_conf_reply = vapi_register_msg(&__vapi_metadata_lb_conf_reply);
  VAPI_DBG("Assigned msg id %d to lb_conf_reply", vapi_msg_id_lb_conf_reply);
}

static void __attribute__((constructor)) __vapi_constructor_lb_add_del_as_reply()
{
  static const char name[] = "lb_add_del_as_reply";
  static const char name_with_crc[] = "lb_add_del_as_reply_6c407528";
  static vapi_message_desc_t __vapi_metadata_lb_add_del_as_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_lb_add_del_as_reply, payload),
    sizeof(vapi_msg_lb_add_del_as_reply),
    (generic_swap_fn_t)vapi_msg_lb_add_del_as_reply_hton,
    (generic_swap_fn_t)vapi_msg_lb_add_del_as_reply_ntoh,
    ~0,
  };

  vapi_msg_id_lb_add_del_as_reply = vapi_register_msg(&__vapi_metadata_lb_add_del_as_reply);
  VAPI_DBG("Assigned msg id %d to lb_add_del_as_reply", vapi_msg_id_lb_add_del_as_reply);
}

static void __attribute__((constructor)) __vapi_constructor_lb_conf()
{
  static const char name[] = "lb_conf";
  static const char name_with_crc[] = "lb_conf_3e9c476c";
  static vapi_message_desc_t __vapi_metadata_lb_conf = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_lb_conf, payload),
    sizeof(vapi_msg_lb_conf),
    (generic_swap_fn_t)vapi_msg_lb_conf_hton,
    (generic_swap_fn_t)vapi_msg_lb_conf_ntoh,
    ~0,
  };

  vapi_msg_id_lb_conf = vapi_register_msg(&__vapi_metadata_lb_conf);
  VAPI_DBG("Assigned msg id %d to lb_conf", vapi_msg_id_lb_conf);
}

static void __attribute__((constructor)) __vapi_constructor_lb_add_del_vip()
{
  static const char name[] = "lb_add_del_vip";
  static const char name_with_crc[] = "lb_add_del_vip_f611e4a4";
  static vapi_message_desc_t __vapi_metadata_lb_add_del_vip = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_lb_add_del_vip, payload),
    sizeof(vapi_msg_lb_add_del_vip),
    (generic_swap_fn_t)vapi_msg_lb_add_del_vip_hton,
    (generic_swap_fn_t)vapi_msg_lb_add_del_vip_ntoh,
    ~0,
  };

  vapi_msg_id_lb_add_del_vip = vapi_register_msg(&__vapi_metadata_lb_add_del_vip);
  VAPI_DBG("Assigned msg id %d to lb_add_del_vip", vapi_msg_id_lb_add_del_vip);
}


static inline void vapi_set_vapi_msg_lb_add_del_vip_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_lb_add_del_vip_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_lb_add_del_vip_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_lb_conf_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_lb_conf_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_lb_conf_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_lb_add_del_as_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_lb_add_del_as_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_lb_add_del_as_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
