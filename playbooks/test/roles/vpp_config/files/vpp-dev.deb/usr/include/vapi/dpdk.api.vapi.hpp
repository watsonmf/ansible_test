#ifndef __included_hpp_dpdk_api_json
#define __included_hpp_dpdk_api_json

#include <vapi/vapi.hpp>
#include <vapi/dpdk.api.vapi.h>

namespace vapi {

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>(vapi_msg_sw_interface_set_dpdk_hqos_subport_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_subport_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>(vapi_msg_id_sw_interface_set_dpdk_hqos_subport_reply);
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>;

using Sw_interface_set_dpdk_hqos_subport_reply = Msg<vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>(vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>(vapi_msg_sw_interface_set_dpdk_hqos_tctbl *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_tctbl()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>(vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl);
}

template <> inline vapi_msg_sw_interface_set_dpdk_hqos_tctbl* vapi_alloc<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>(Connection &con)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl* result = vapi_alloc_sw_interface_set_dpdk_hqos_tctbl(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_tctbl>;

template class Request<vapi_msg_sw_interface_set_dpdk_hqos_tctbl, vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>;

using Sw_interface_set_dpdk_hqos_tctbl = Request<vapi_msg_sw_interface_set_dpdk_hqos_tctbl, vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_subport>(vapi_msg_sw_interface_set_dpdk_hqos_subport *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_subport>(vapi_msg_sw_interface_set_dpdk_hqos_subport *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_subport>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_subport; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_subport>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_subport; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_subport()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_subport>(vapi_msg_id_sw_interface_set_dpdk_hqos_subport);
}

template <> inline vapi_msg_sw_interface_set_dpdk_hqos_subport* vapi_alloc<vapi_msg_sw_interface_set_dpdk_hqos_subport>(Connection &con)
{
  vapi_msg_sw_interface_set_dpdk_hqos_subport* result = vapi_alloc_sw_interface_set_dpdk_hqos_subport(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_subport>;

template class Request<vapi_msg_sw_interface_set_dpdk_hqos_subport, vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>;

using Sw_interface_set_dpdk_hqos_subport = Request<vapi_msg_sw_interface_set_dpdk_hqos_subport, vapi_msg_sw_interface_set_dpdk_hqos_subport_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_pipe>(vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_pipe>(vapi_msg_sw_interface_set_dpdk_hqos_pipe *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_pipe>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_pipe; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_pipe>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_pipe; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_pipe()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_pipe>(vapi_msg_id_sw_interface_set_dpdk_hqos_pipe);
}

template <> inline vapi_msg_sw_interface_set_dpdk_hqos_pipe* vapi_alloc<vapi_msg_sw_interface_set_dpdk_hqos_pipe>(Connection &con)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe* result = vapi_alloc_sw_interface_set_dpdk_hqos_pipe(con.vapi_ctx);
#if VAPI_CPP_DEBUG_LEAKS
  con.on_shm_data_alloc(result);
#endif
  return result;
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_pipe>;

template class Request<vapi_msg_sw_interface_set_dpdk_hqos_pipe, vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>;

using Sw_interface_set_dpdk_hqos_pipe = Request<vapi_msg_sw_interface_set_dpdk_hqos_pipe, vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>;

template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>(vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_tctbl_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>(vapi_msg_id_sw_interface_set_dpdk_hqos_tctbl_reply);
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>;

using Sw_interface_set_dpdk_hqos_tctbl_reply = Msg<vapi_msg_sw_interface_set_dpdk_hqos_tctbl_reply>;
template <> inline void vapi_swap_to_be<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_hton(msg);
}

template <> inline void vapi_swap_to_host<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>(vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply *msg)
{
  vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply_ntoh(msg);
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply; 
}

template <> inline vapi_msg_id_t vapi_get_msg_id_t<Msg<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>>()
{
  return ::vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply; 
}

static void __attribute__((constructor)) __vapi_cpp_constructor_sw_interface_set_dpdk_hqos_pipe_reply()
{
  vapi::vapi_msg_set_msg_id<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>(vapi_msg_id_sw_interface_set_dpdk_hqos_pipe_reply);
}

template class Msg<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>;

using Sw_interface_set_dpdk_hqos_pipe_reply = Msg<vapi_msg_sw_interface_set_dpdk_hqos_pipe_reply>;
}
#endif
