/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vnet/dhcp/dhcp.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/dhcp/dhcp.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_DHCP_PROXY_CONFIG, vl_api_dhcp_proxy_config_t_handler)
vl_msg_id(VL_API_DHCP_PROXY_CONFIG_REPLY, vl_api_dhcp_proxy_config_reply_t_handler)
vl_msg_id(VL_API_DHCP_PROXY_SET_VSS, vl_api_dhcp_proxy_set_vss_t_handler)
vl_msg_id(VL_API_DHCP_PROXY_SET_VSS_REPLY, vl_api_dhcp_proxy_set_vss_reply_t_handler)
vl_msg_id(VL_API_DHCP_CLIENT_CONFIG, vl_api_dhcp_client_config_t_handler)
vl_msg_id(VL_API_DHCP_CLIENT_CONFIG_REPLY, vl_api_dhcp_client_config_reply_t_handler)
vl_msg_id(VL_API_DHCP_COMPL_EVENT, vl_api_dhcp_compl_event_t_handler)
vl_msg_id(VL_API_DHCP_PROXY_DUMP, vl_api_dhcp_proxy_dump_t_handler)
/* typeonly: dhcp_server */
vl_msg_id(VL_API_DHCP_PROXY_DETAILS, vl_api_dhcp_proxy_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_dhcp_proxy_config_t, 1)
vl_msg_name(vl_api_dhcp_proxy_config_reply_t, 1)
vl_msg_name(vl_api_dhcp_proxy_set_vss_t, 1)
vl_msg_name(vl_api_dhcp_proxy_set_vss_reply_t, 1)
vl_msg_name(vl_api_dhcp_client_config_t, 1)
vl_msg_name(vl_api_dhcp_client_config_reply_t, 1)
vl_msg_name(vl_api_dhcp_compl_event_t, 1)
vl_msg_name(vl_api_dhcp_proxy_dump_t, 1)
/* typeonly: dhcp_server */
vl_msg_name(vl_api_dhcp_proxy_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_dhcp \
_(VL_API_DHCP_PROXY_CONFIG, dhcp_proxy_config, 3b4f2bc8) \
_(VL_API_DHCP_PROXY_CONFIG_REPLY, dhcp_proxy_config_reply, fe63196f) \
_(VL_API_DHCP_PROXY_SET_VSS, dhcp_proxy_set_vss, be54d194) \
_(VL_API_DHCP_PROXY_SET_VSS_REPLY, dhcp_proxy_set_vss_reply, 5bb4e754) \
_(VL_API_DHCP_CLIENT_CONFIG, dhcp_client_config, 41c8a9f2) \
_(VL_API_DHCP_CLIENT_CONFIG_REPLY, dhcp_client_config_reply, d947f4c8) \
_(VL_API_DHCP_COMPL_EVENT, dhcp_compl_event, aafb5462) \
_(VL_API_DHCP_PROXY_DUMP, dhcp_proxy_dump, 175bc073) \
_(VL_API_DHCP_PROXY_DETAILS, dhcp_proxy_details, 9727dbdd) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 rx_vrf_id;
    u32 server_vrf_id;
    u8 is_ipv6;
    u8 is_add;
    u8 dhcp_server[16];
    u8 dhcp_src_address[16];
}) vl_api_dhcp_proxy_config_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_dhcp_proxy_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_set_vss {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 tbl_id;
    u32 oui;
    u32 fib_id;
    u8 is_ipv6;
    u8 is_add;
}) vl_api_dhcp_proxy_set_vss_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_set_vss_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_dhcp_proxy_set_vss_reply_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_client_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 hostname[64];
    u8 client_id[64];
    u8 is_add;
    u8 want_dhcp_event;
    u32 pid;
}) vl_api_dhcp_client_config_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_client_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_dhcp_client_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_compl_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 pid;
    u8 hostname[64];
    u8 is_ipv6;
    u8 mask_width;
    u8 host_address[16];
    u8 router_address[16];
    u8 host_mac[6];
}) vl_api_dhcp_compl_event_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip6;
}) vl_api_dhcp_proxy_dump_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_server {
    u32 server_vrf_id;
    u8 dhcp_server[16];
}) vl_api_dhcp_server_t;

typedef VL_API_PACKED(struct _vl_api_dhcp_proxy_details {
    u16 _vl_msg_id;
    u32 context;
    u32 rx_vrf_id;
    u32 vss_oui;
    u32 vss_fib_id;
    u8 is_ipv6;
    u8 dhcp_src_address[16];
    u8 count;
    vl_api_dhcp_server_t servers[0];
}) vl_api_dhcp_proxy_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_dhcp_proxy_config_t_print (vl_api_dhcp_proxy_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_proxy_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "rx_vrf_id: %u\n", (unsigned) a->rx_vrf_id);
    vl_print(handle, "server_vrf_id: %u\n", (unsigned) a->server_vrf_id);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "dhcp_server[%d]: %u\n", _i, a->dhcp_server[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "dhcp_src_address[%d]: %u\n", _i, a->dhcp_src_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_dhcp_proxy_config_reply_t_print (vl_api_dhcp_proxy_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_proxy_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_dhcp_proxy_set_vss_t_print (vl_api_dhcp_proxy_set_vss_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_proxy_set_vss_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "tbl_id: %u\n", (unsigned) a->tbl_id);
    vl_print(handle, "oui: %u\n", (unsigned) a->oui);
    vl_print(handle, "fib_id: %u\n", (unsigned) a->fib_id);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_dhcp_proxy_set_vss_reply_t_print (vl_api_dhcp_proxy_set_vss_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_proxy_set_vss_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_dhcp_client_config_t_print (vl_api_dhcp_client_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_client_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "hostname[%d]: %u\n", _i, a->hostname[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "client_id[%d]: %u\n", _i, a->client_id[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "want_dhcp_event: %u\n", (unsigned) a->want_dhcp_event);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_dhcp_client_config_reply_t_print (vl_api_dhcp_client_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_client_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_dhcp_compl_event_t_print (vl_api_dhcp_compl_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_compl_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "hostname[%d]: %u\n", _i, a->hostname[_i]);
        }
    }
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "mask_width: %u\n", (unsigned) a->mask_width);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "host_address[%d]: %u\n", _i, a->host_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "router_address[%d]: %u\n", _i, a->router_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "host_mac[%d]: %u\n", _i, a->host_mac[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_dhcp_proxy_dump_t_print (vl_api_dhcp_proxy_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_dhcp_proxy_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip6: %u\n", (unsigned) a->is_ip6);
    return handle;
}

/***** manual: vl_api_dhcp_server_t_print  *****/

/***** manual: vl_api_dhcp_proxy_details_t_print  *****/

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_dhcp_proxy_config_t_endian (vl_api_dhcp_proxy_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->rx_vrf_id = clib_net_to_host_u32(a->rx_vrf_id);
    a->server_vrf_id = clib_net_to_host_u32(a->server_vrf_id);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->dhcp_server[0..15] = a->dhcp_server[0..15] (no-op) */
    /* a->dhcp_src_address[0..15] = a->dhcp_src_address[0..15] (no-op) */
}

static inline void vl_api_dhcp_proxy_config_reply_t_endian (vl_api_dhcp_proxy_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_dhcp_proxy_set_vss_t_endian (vl_api_dhcp_proxy_set_vss_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->tbl_id = clib_net_to_host_u32(a->tbl_id);
    a->oui = clib_net_to_host_u32(a->oui);
    a->fib_id = clib_net_to_host_u32(a->fib_id);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_dhcp_proxy_set_vss_reply_t_endian (vl_api_dhcp_proxy_set_vss_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_dhcp_client_config_t_endian (vl_api_dhcp_client_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->hostname[0..63] = a->hostname[0..63] (no-op) */
    /* a->client_id[0..63] = a->client_id[0..63] (no-op) */
    /* a->is_add = a->is_add (no-op) */
    /* a->want_dhcp_event = a->want_dhcp_event (no-op) */
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_dhcp_client_config_reply_t_endian (vl_api_dhcp_client_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_dhcp_compl_event_t_endian (vl_api_dhcp_compl_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->pid = clib_net_to_host_u32(a->pid);
    /* a->hostname[0..63] = a->hostname[0..63] (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->mask_width = a->mask_width (no-op) */
    /* a->host_address[0..15] = a->host_address[0..15] (no-op) */
    /* a->router_address[0..15] = a->router_address[0..15] (no-op) */
    /* a->host_mac[0..5] = a->host_mac[0..5] (no-op) */
}

static inline void vl_api_dhcp_proxy_dump_t_endian (vl_api_dhcp_proxy_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip6 = a->is_ip6 (no-op) */
}

/***** manual: vl_api_dhcp_server_t_endian  *****/

/***** manual: vl_api_dhcp_proxy_details_t_endian  *****/

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(dhcp.api, 0x8a58174c)

#endif

