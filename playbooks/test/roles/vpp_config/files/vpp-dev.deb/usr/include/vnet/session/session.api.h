/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vnet/session/session.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/session/session.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_APPLICATION_ATTACH, vl_api_application_attach_t_handler)
vl_msg_id(VL_API_APPLICATION_ATTACH_REPLY, vl_api_application_attach_reply_t_handler)
vl_msg_id(VL_API_APPLICATION_DETACH, vl_api_application_detach_t_handler)
vl_msg_id(VL_API_APPLICATION_DETACH_REPLY, vl_api_application_detach_reply_t_handler)
vl_msg_id(VL_API_MAP_ANOTHER_SEGMENT, vl_api_map_another_segment_t_handler)
vl_msg_id(VL_API_MAP_ANOTHER_SEGMENT_REPLY, vl_api_map_another_segment_reply_t_handler)
vl_msg_id(VL_API_BIND_URI, vl_api_bind_uri_t_handler)
vl_msg_id(VL_API_BIND_URI_REPLY, vl_api_bind_uri_reply_t_handler)
vl_msg_id(VL_API_UNBIND_URI, vl_api_unbind_uri_t_handler)
vl_msg_id(VL_API_UNBIND_URI_REPLY, vl_api_unbind_uri_reply_t_handler)
vl_msg_id(VL_API_CONNECT_URI, vl_api_connect_uri_t_handler)
vl_msg_id(VL_API_CONNECT_URI_REPLY, vl_api_connect_uri_reply_t_handler)
vl_msg_id(VL_API_ACCEPT_SESSION, vl_api_accept_session_t_handler)
vl_msg_id(VL_API_ACCEPT_SESSION_REPLY, vl_api_accept_session_reply_t_handler)
vl_msg_id(VL_API_DISCONNECT_SESSION, vl_api_disconnect_session_t_handler)
vl_msg_id(VL_API_DISCONNECT_SESSION_REPLY, vl_api_disconnect_session_reply_t_handler)
vl_msg_id(VL_API_RESET_SESSION, vl_api_reset_session_t_handler)
vl_msg_id(VL_API_RESET_SESSION_REPLY, vl_api_reset_session_reply_t_handler)
vl_msg_id(VL_API_BIND_SOCK, vl_api_bind_sock_t_handler)
vl_msg_id(VL_API_UNBIND_SOCK, vl_api_unbind_sock_t_handler)
vl_msg_id(VL_API_UNBIND_SOCK_REPLY, vl_api_unbind_sock_reply_t_handler)
vl_msg_id(VL_API_CONNECT_SOCK, vl_api_connect_sock_t_handler)
vl_msg_id(VL_API_CONNECT_SOCK_REPLY, vl_api_connect_sock_reply_t_handler)
vl_msg_id(VL_API_BIND_SOCK_REPLY, vl_api_bind_sock_reply_t_handler)
vl_msg_id(VL_API_CONNECT_SESSION, vl_api_connect_session_t_handler)
vl_msg_id(VL_API_CONNECT_SESSION_REPLY, vl_api_connect_session_reply_t_handler)
vl_msg_id(VL_API_SESSION_ENABLE_DISABLE, vl_api_session_enable_disable_t_handler)
vl_msg_id(VL_API_SESSION_ENABLE_DISABLE_REPLY, vl_api_session_enable_disable_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_application_attach_t, 1)
vl_msg_name(vl_api_application_attach_reply_t, 1)
vl_msg_name(vl_api_application_detach_t, 1)
vl_msg_name(vl_api_application_detach_reply_t, 1)
vl_msg_name(vl_api_map_another_segment_t, 1)
vl_msg_name(vl_api_map_another_segment_reply_t, 1)
vl_msg_name(vl_api_bind_uri_t, 1)
vl_msg_name(vl_api_bind_uri_reply_t, 1)
vl_msg_name(vl_api_unbind_uri_t, 1)
vl_msg_name(vl_api_unbind_uri_reply_t, 1)
vl_msg_name(vl_api_connect_uri_t, 1)
vl_msg_name(vl_api_connect_uri_reply_t, 1)
vl_msg_name(vl_api_accept_session_t, 1)
vl_msg_name(vl_api_accept_session_reply_t, 1)
vl_msg_name(vl_api_disconnect_session_t, 1)
vl_msg_name(vl_api_disconnect_session_reply_t, 1)
vl_msg_name(vl_api_reset_session_t, 1)
vl_msg_name(vl_api_reset_session_reply_t, 1)
vl_msg_name(vl_api_bind_sock_t, 1)
vl_msg_name(vl_api_unbind_sock_t, 1)
vl_msg_name(vl_api_unbind_sock_reply_t, 1)
vl_msg_name(vl_api_connect_sock_t, 1)
vl_msg_name(vl_api_connect_sock_reply_t, 1)
vl_msg_name(vl_api_bind_sock_reply_t, 1)
vl_msg_name(vl_api_connect_session_t, 1)
vl_msg_name(vl_api_connect_session_reply_t, 1)
vl_msg_name(vl_api_session_enable_disable_t, 1)
vl_msg_name(vl_api_session_enable_disable_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_session \
_(VL_API_APPLICATION_ATTACH, application_attach, e589ec93) \
_(VL_API_APPLICATION_ATTACH_REPLY, application_attach_reply, 0df5c138) \
_(VL_API_APPLICATION_DETACH, application_detach, bf7e4352) \
_(VL_API_APPLICATION_DETACH_REPLY, application_detach_reply, fb879289) \
_(VL_API_MAP_ANOTHER_SEGMENT, map_another_segment, 28ca2003) \
_(VL_API_MAP_ANOTHER_SEGMENT_REPLY, map_another_segment_reply, 76d11a9d) \
_(VL_API_BIND_URI, bind_uri, ceafed7f) \
_(VL_API_BIND_URI_REPLY, bind_uri_reply, 75918978) \
_(VL_API_UNBIND_URI, unbind_uri, 46569743) \
_(VL_API_UNBIND_URI_REPLY, unbind_uri_reply, 310db78f) \
_(VL_API_CONNECT_URI, connect_uri, 80474aff) \
_(VL_API_CONNECT_URI_REPLY, connect_uri_reply, 54ec1256) \
_(VL_API_ACCEPT_SESSION, accept_session, 8e2a127e) \
_(VL_API_ACCEPT_SESSION_REPLY, accept_session_reply, 67d8c22a) \
_(VL_API_DISCONNECT_SESSION, disconnect_session, 18addf61) \
_(VL_API_DISCONNECT_SESSION_REPLY, disconnect_session_reply, 6fb16b8f) \
_(VL_API_RESET_SESSION, reset_session, 601fefd7) \
_(VL_API_RESET_SESSION_REPLY, reset_session_reply, 80f6c14f) \
_(VL_API_BIND_SOCK, bind_sock, 3f898291) \
_(VL_API_UNBIND_SOCK, unbind_sock, 9007c8c9) \
_(VL_API_UNBIND_SOCK_REPLY, unbind_sock_reply, 5d9c5da6) \
_(VL_API_CONNECT_SOCK, connect_sock, 3e66becf) \
_(VL_API_CONNECT_SOCK_REPLY, connect_sock_reply, f6988664) \
_(VL_API_BIND_SOCK_REPLY, bind_sock_reply, eecef9cc) \
_(VL_API_CONNECT_SESSION, connect_session, 40ae01d1) \
_(VL_API_CONNECT_SESSION_REPLY, connect_session_reply, 1c779aca) \
_(VL_API_SESSION_ENABLE_DISABLE, session_enable_disable, a4cfced4) \
_(VL_API_SESSION_ENABLE_DISABLE_REPLY, session_enable_disable_reply, cfb0e390) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_application_attach {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 initial_segment_size;
    u64 options[16];
}) vl_api_application_attach_t;

typedef VL_API_PACKED(struct _vl_api_application_attach_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 app_event_queue_address;
    u32 segment_size;
    u8 segment_name_length;
    u8 segment_name[128];
}) vl_api_application_attach_reply_t;

typedef VL_API_PACKED(struct _vl_api_application_detach {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_application_detach_t;

typedef VL_API_PACKED(struct _vl_api_application_detach_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_application_detach_reply_t;

typedef VL_API_PACKED(struct _vl_api_map_another_segment {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 segment_size;
    u8 segment_name[128];
}) vl_api_map_another_segment_t;

typedef VL_API_PACKED(struct _vl_api_map_another_segment_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_map_another_segment_reply_t;

typedef VL_API_PACKED(struct _vl_api_bind_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 accept_cookie;
    u8 uri[128];
}) vl_api_bind_uri_t;

typedef VL_API_PACKED(struct _vl_api_bind_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bind_uri_reply_t;

typedef VL_API_PACKED(struct _vl_api_unbind_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 uri[128];
}) vl_api_unbind_uri_t;

typedef VL_API_PACKED(struct _vl_api_unbind_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_unbind_uri_reply_t;

typedef VL_API_PACKED(struct _vl_api_connect_uri {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 uri[128];
    u64 client_queue_address;
    u64 options[16];
}) vl_api_connect_uri_t;

typedef VL_API_PACKED(struct _vl_api_connect_uri_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_connect_uri_reply_t;

typedef VL_API_PACKED(struct _vl_api_accept_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 listener_handle;
    u64 handle;
    u64 server_rx_fifo;
    u64 server_tx_fifo;
    u64 vpp_event_queue_address;
    u16 port;
    u8 is_ip4;
    u8 ip[16];
}) vl_api_accept_session_t;

typedef VL_API_PACKED(struct _vl_api_accept_session_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 handle;
}) vl_api_accept_session_reply_t;

typedef VL_API_PACKED(struct _vl_api_disconnect_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 handle;
}) vl_api_disconnect_session_t;

typedef VL_API_PACKED(struct _vl_api_disconnect_session_reply {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 retval;
    u64 handle;
}) vl_api_disconnect_session_reply_t;

typedef VL_API_PACKED(struct _vl_api_reset_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 handle;
}) vl_api_reset_session_t;

typedef VL_API_PACKED(struct _vl_api_reset_session_reply {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 retval;
    u64 handle;
}) vl_api_reset_session_reply_t;

typedef VL_API_PACKED(struct _vl_api_bind_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf;
    u8 is_ip4;
    u8 ip[16];
    u16 port;
    u8 proto;
    u64 options[16];
}) vl_api_bind_sock_t;

typedef VL_API_PACKED(struct _vl_api_unbind_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 handle;
}) vl_api_unbind_sock_t;

typedef VL_API_PACKED(struct _vl_api_unbind_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_unbind_sock_reply_t;

typedef VL_API_PACKED(struct _vl_api_connect_sock {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vrf;
    u8 is_ip4;
    u8 ip[16];
    u16 port;
    u8 proto;
    u64 client_queue_address;
    u64 options[16];
}) vl_api_connect_sock_t;

typedef VL_API_PACKED(struct _vl_api_connect_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_connect_sock_reply_t;

typedef VL_API_PACKED(struct _vl_api_bind_sock_reply {
    u16 _vl_msg_id;
    u32 context;
    u64 handle;
    i32 retval;
    u64 server_event_queue_address;
    u32 segment_size;
    u8 segment_name_length;
    u8 segment_name[128];
}) vl_api_bind_sock_reply_t;

typedef VL_API_PACKED(struct _vl_api_connect_session {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_connect_session_t;

typedef VL_API_PACKED(struct _vl_api_connect_session_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u64 handle;
    u64 server_rx_fifo;
    u64 server_tx_fifo;
    u64 vpp_event_queue_address;
    u32 segment_size;
    u8 segment_name_length;
    u8 segment_name[128];
}) vl_api_connect_session_reply_t;

typedef VL_API_PACKED(struct _vl_api_session_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enable;
}) vl_api_session_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_session_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_session_enable_disable_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_application_attach_t_print (vl_api_application_attach_t *a,void *handle)
{
    vl_print(handle, "vl_api_application_attach_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "initial_segment_size: %u\n", (unsigned) a->initial_segment_size);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "options[%d]: %llu\n", _i, a->options[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_application_attach_reply_t_print (vl_api_application_attach_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_application_attach_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "app_event_queue_address: %llu\n", (long long) a->app_event_queue_address);
    vl_print(handle, "segment_size: %u\n", (unsigned) a->segment_size);
    vl_print(handle, "segment_name_length: %u\n", (unsigned) a->segment_name_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "segment_name[%d]: %u\n", _i, a->segment_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_application_detach_t_print (vl_api_application_detach_t *a,void *handle)
{
    vl_print(handle, "vl_api_application_detach_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_application_detach_reply_t_print (vl_api_application_detach_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_application_detach_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_map_another_segment_t_print (vl_api_map_another_segment_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_another_segment_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "segment_size: %u\n", (unsigned) a->segment_size);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "segment_name[%d]: %u\n", _i, a->segment_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_map_another_segment_reply_t_print (vl_api_map_another_segment_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_map_another_segment_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bind_uri_t_print (vl_api_bind_uri_t *a,void *handle)
{
    vl_print(handle, "vl_api_bind_uri_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "accept_cookie: %u\n", (unsigned) a->accept_cookie);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "uri[%d]: %u\n", _i, a->uri[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_bind_uri_reply_t_print (vl_api_bind_uri_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bind_uri_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_unbind_uri_t_print (vl_api_unbind_uri_t *a,void *handle)
{
    vl_print(handle, "vl_api_unbind_uri_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "uri[%d]: %u\n", _i, a->uri[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_unbind_uri_reply_t_print (vl_api_unbind_uri_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_unbind_uri_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_connect_uri_t_print (vl_api_connect_uri_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_uri_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "uri[%d]: %u\n", _i, a->uri[_i]);
        }
    }
    vl_print(handle, "client_queue_address: %llu\n", (long long) a->client_queue_address);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "options[%d]: %llu\n", _i, a->options[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_connect_uri_reply_t_print (vl_api_connect_uri_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_uri_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_accept_session_t_print (vl_api_accept_session_t *a,void *handle)
{
    vl_print(handle, "vl_api_accept_session_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "listener_handle: %llu\n", (long long) a->listener_handle);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "server_rx_fifo: %llu\n", (long long) a->server_rx_fifo);
    vl_print(handle, "server_tx_fifo: %llu\n", (long long) a->server_tx_fifo);
    vl_print(handle, "vpp_event_queue_address: %llu\n", (long long) a->vpp_event_queue_address);
    vl_print(handle, "port: %u\n", (unsigned) a->port);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip[%d]: %u\n", _i, a->ip[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_accept_session_reply_t_print (vl_api_accept_session_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_accept_session_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_disconnect_session_t_print (vl_api_disconnect_session_t *a,void *handle)
{
    vl_print(handle, "vl_api_disconnect_session_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_disconnect_session_reply_t_print (vl_api_disconnect_session_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_disconnect_session_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_reset_session_t_print (vl_api_reset_session_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_session_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_reset_session_reply_t_print (vl_api_reset_session_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_reset_session_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_bind_sock_t_print (vl_api_bind_sock_t *a,void *handle)
{
    vl_print(handle, "vl_api_bind_sock_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf: %u\n", (unsigned) a->vrf);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip[%d]: %u\n", _i, a->ip[_i]);
        }
    }
    vl_print(handle, "port: %u\n", (unsigned) a->port);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "options[%d]: %llu\n", _i, a->options[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_unbind_sock_t_print (vl_api_unbind_sock_t *a,void *handle)
{
    vl_print(handle, "vl_api_unbind_sock_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_unbind_sock_reply_t_print (vl_api_unbind_sock_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_unbind_sock_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_connect_sock_t_print (vl_api_connect_sock_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_sock_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf: %u\n", (unsigned) a->vrf);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip[%d]: %u\n", _i, a->ip[_i]);
        }
    }
    vl_print(handle, "port: %u\n", (unsigned) a->port);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    vl_print(handle, "client_queue_address: %llu\n", (long long) a->client_queue_address);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "options[%d]: %llu\n", _i, a->options[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_connect_sock_reply_t_print (vl_api_connect_sock_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_sock_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bind_sock_reply_t_print (vl_api_bind_sock_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bind_sock_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "server_event_queue_address: %llu\n", (long long) a->server_event_queue_address);
    vl_print(handle, "segment_size: %u\n", (unsigned) a->segment_size);
    vl_print(handle, "segment_name_length: %u\n", (unsigned) a->segment_name_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "segment_name[%d]: %u\n", _i, a->segment_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_connect_session_t_print (vl_api_connect_session_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_session_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_connect_session_reply_t_print (vl_api_connect_session_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_connect_session_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "server_rx_fifo: %llu\n", (long long) a->server_rx_fifo);
    vl_print(handle, "server_tx_fifo: %llu\n", (long long) a->server_tx_fifo);
    vl_print(handle, "vpp_event_queue_address: %llu\n", (long long) a->vpp_event_queue_address);
    vl_print(handle, "segment_size: %u\n", (unsigned) a->segment_size);
    vl_print(handle, "segment_name_length: %u\n", (unsigned) a->segment_name_length);
    {
        int _i;
        for (_i = 0; _i < 128; _i++) {
            vl_print(handle, "segment_name[%d]: %u\n", _i, a->segment_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_session_enable_disable_t_print (vl_api_session_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_session_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enable: %u\n", (unsigned) a->is_enable);
    return handle;
}

static inline void *vl_api_session_enable_disable_reply_t_print (vl_api_session_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_session_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_application_attach_t_endian (vl_api_application_attach_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->initial_segment_size = clib_net_to_host_u32(a->initial_segment_size);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            a->options[_i] = clib_net_to_host_u64(a->options[_i]);
        }
    }
}

static inline void vl_api_application_attach_reply_t_endian (vl_api_application_attach_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->app_event_queue_address = clib_net_to_host_u64(a->app_event_queue_address);
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name[0..127] = a->segment_name[0..127] (no-op) */
}

static inline void vl_api_application_detach_t_endian (vl_api_application_detach_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_application_detach_reply_t_endian (vl_api_application_detach_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_map_another_segment_t_endian (vl_api_map_another_segment_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name[0..127] = a->segment_name[0..127] (no-op) */
}

static inline void vl_api_map_another_segment_reply_t_endian (vl_api_map_another_segment_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bind_uri_t_endian (vl_api_bind_uri_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->accept_cookie = clib_net_to_host_u32(a->accept_cookie);
    /* a->uri[0..127] = a->uri[0..127] (no-op) */
}

static inline void vl_api_bind_uri_reply_t_endian (vl_api_bind_uri_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_unbind_uri_t_endian (vl_api_unbind_uri_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->uri[0..127] = a->uri[0..127] (no-op) */
}

static inline void vl_api_unbind_uri_reply_t_endian (vl_api_unbind_uri_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_connect_uri_t_endian (vl_api_connect_uri_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->uri[0..127] = a->uri[0..127] (no-op) */
    a->client_queue_address = clib_net_to_host_u64(a->client_queue_address);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            a->options[_i] = clib_net_to_host_u64(a->options[_i]);
        }
    }
}

static inline void vl_api_connect_uri_reply_t_endian (vl_api_connect_uri_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_accept_session_t_endian (vl_api_accept_session_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->listener_handle = clib_net_to_host_u64(a->listener_handle);
    a->handle = clib_net_to_host_u64(a->handle);
    a->server_rx_fifo = clib_net_to_host_u64(a->server_rx_fifo);
    a->server_tx_fifo = clib_net_to_host_u64(a->server_tx_fifo);
    a->vpp_event_queue_address = clib_net_to_host_u64(a->vpp_event_queue_address);
    a->port = clib_net_to_host_u16(a->port);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip[0..15] = a->ip[0..15] (no-op) */
}

static inline void vl_api_accept_session_reply_t_endian (vl_api_accept_session_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_disconnect_session_t_endian (vl_api_disconnect_session_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_disconnect_session_reply_t_endian (vl_api_disconnect_session_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_reset_session_t_endian (vl_api_reset_session_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_reset_session_reply_t_endian (vl_api_reset_session_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_bind_sock_t_endian (vl_api_bind_sock_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf = clib_net_to_host_u32(a->vrf);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip[0..15] = a->ip[0..15] (no-op) */
    a->port = clib_net_to_host_u16(a->port);
    /* a->proto = a->proto (no-op) */
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            a->options[_i] = clib_net_to_host_u64(a->options[_i]);
        }
    }
}

static inline void vl_api_unbind_sock_t_endian (vl_api_unbind_sock_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_unbind_sock_reply_t_endian (vl_api_unbind_sock_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_connect_sock_t_endian (vl_api_connect_sock_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf = clib_net_to_host_u32(a->vrf);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip[0..15] = a->ip[0..15] (no-op) */
    a->port = clib_net_to_host_u16(a->port);
    /* a->proto = a->proto (no-op) */
    a->client_queue_address = clib_net_to_host_u64(a->client_queue_address);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            a->options[_i] = clib_net_to_host_u64(a->options[_i]);
        }
    }
}

static inline void vl_api_connect_sock_reply_t_endian (vl_api_connect_sock_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bind_sock_reply_t_endian (vl_api_bind_sock_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->handle = clib_net_to_host_u64(a->handle);
    a->retval = clib_net_to_host_u32(a->retval);
    a->server_event_queue_address = clib_net_to_host_u64(a->server_event_queue_address);
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name[0..127] = a->segment_name[0..127] (no-op) */
}

static inline void vl_api_connect_session_t_endian (vl_api_connect_session_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_connect_session_reply_t_endian (vl_api_connect_session_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->handle = clib_net_to_host_u64(a->handle);
    a->server_rx_fifo = clib_net_to_host_u64(a->server_rx_fifo);
    a->server_tx_fifo = clib_net_to_host_u64(a->server_tx_fifo);
    a->vpp_event_queue_address = clib_net_to_host_u64(a->vpp_event_queue_address);
    a->segment_size = clib_net_to_host_u32(a->segment_size);
    /* a->segment_name_length = a->segment_name_length (no-op) */
    /* a->segment_name[0..127] = a->segment_name[0..127] (no-op) */
}

static inline void vl_api_session_enable_disable_t_endian (vl_api_session_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enable = a->is_enable (no-op) */
}

static inline void vl_api_session_enable_disable_reply_t_endian (vl_api_session_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(session.api, 0xe706031e)

#endif

