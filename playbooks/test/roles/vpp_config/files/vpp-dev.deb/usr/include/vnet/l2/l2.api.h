/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/l2/l2.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/l2/l2.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_L2_XCONNECT_DETAILS, vl_api_l2_xconnect_details_t_handler)
vl_msg_id(VL_API_L2_XCONNECT_DUMP, vl_api_l2_xconnect_dump_t_handler)
vl_msg_id(VL_API_L2_FIB_TABLE_DETAILS, vl_api_l2_fib_table_details_t_handler)
vl_msg_id(VL_API_L2_FIB_TABLE_DUMP, vl_api_l2_fib_table_dump_t_handler)
vl_msg_id(VL_API_L2_FIB_CLEAR_TABLE, vl_api_l2_fib_clear_table_t_handler)
vl_msg_id(VL_API_L2_FIB_CLEAR_TABLE_REPLY, vl_api_l2_fib_clear_table_reply_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_ALL, vl_api_l2fib_flush_all_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_ALL_REPLY, vl_api_l2fib_flush_all_reply_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_BD, vl_api_l2fib_flush_bd_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_BD_REPLY, vl_api_l2fib_flush_bd_reply_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_INT, vl_api_l2fib_flush_int_t_handler)
vl_msg_id(VL_API_L2FIB_FLUSH_INT_REPLY, vl_api_l2fib_flush_int_reply_t_handler)
vl_msg_id(VL_API_L2FIB_ADD_DEL, vl_api_l2fib_add_del_t_handler)
vl_msg_id(VL_API_L2FIB_ADD_DEL_REPLY, vl_api_l2fib_add_del_reply_t_handler)
vl_msg_id(VL_API_WANT_L2_MACS_EVENTS, vl_api_want_l2_macs_events_t_handler)
vl_msg_id(VL_API_WANT_L2_MACS_EVENTS_REPLY, vl_api_want_l2_macs_events_reply_t_handler)
/* typeonly: mac_entry */
vl_msg_id(VL_API_L2_MACS_EVENT, vl_api_l2_macs_event_t_handler)
vl_msg_id(VL_API_L2_FLAGS, vl_api_l2_flags_t_handler)
vl_msg_id(VL_API_L2_FLAGS_REPLY, vl_api_l2_flags_reply_t_handler)
vl_msg_id(VL_API_BRIDGE_DOMAIN_SET_MAC_AGE, vl_api_bridge_domain_set_mac_age_t_handler)
vl_msg_id(VL_API_BRIDGE_DOMAIN_SET_MAC_AGE_REPLY, vl_api_bridge_domain_set_mac_age_reply_t_handler)
vl_msg_id(VL_API_BRIDGE_DOMAIN_ADD_DEL, vl_api_bridge_domain_add_del_t_handler)
vl_msg_id(VL_API_BRIDGE_DOMAIN_ADD_DEL_REPLY, vl_api_bridge_domain_add_del_reply_t_handler)
vl_msg_id(VL_API_BRIDGE_DOMAIN_DUMP, vl_api_bridge_domain_dump_t_handler)
/* typeonly: bridge_domain_sw_if */
vl_msg_id(VL_API_BRIDGE_DOMAIN_DETAILS, vl_api_bridge_domain_details_t_handler)
vl_msg_id(VL_API_BRIDGE_FLAGS, vl_api_bridge_flags_t_handler)
vl_msg_id(VL_API_BRIDGE_FLAGS_REPLY, vl_api_bridge_flags_reply_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_VLAN_TAG_REWRITE, vl_api_l2_interface_vlan_tag_rewrite_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_VLAN_TAG_REWRITE_REPLY, vl_api_l2_interface_vlan_tag_rewrite_reply_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_PBB_TAG_REWRITE, vl_api_l2_interface_pbb_tag_rewrite_t_handler)
vl_msg_id(VL_API_L2_INTERFACE_PBB_TAG_REWRITE_REPLY, vl_api_l2_interface_pbb_tag_rewrite_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_l2_xconnect_details_t, 1)
vl_msg_name(vl_api_l2_xconnect_dump_t, 1)
vl_msg_name(vl_api_l2_fib_table_details_t, 1)
vl_msg_name(vl_api_l2_fib_table_dump_t, 1)
vl_msg_name(vl_api_l2_fib_clear_table_t, 1)
vl_msg_name(vl_api_l2_fib_clear_table_reply_t, 1)
vl_msg_name(vl_api_l2fib_flush_all_t, 1)
vl_msg_name(vl_api_l2fib_flush_all_reply_t, 1)
vl_msg_name(vl_api_l2fib_flush_bd_t, 1)
vl_msg_name(vl_api_l2fib_flush_bd_reply_t, 1)
vl_msg_name(vl_api_l2fib_flush_int_t, 1)
vl_msg_name(vl_api_l2fib_flush_int_reply_t, 1)
vl_msg_name(vl_api_l2fib_add_del_t, 1)
vl_msg_name(vl_api_l2fib_add_del_reply_t, 1)
vl_msg_name(vl_api_want_l2_macs_events_t, 1)
vl_msg_name(vl_api_want_l2_macs_events_reply_t, 1)
/* typeonly: mac_entry */
vl_msg_name(vl_api_l2_macs_event_t, 1)
vl_msg_name(vl_api_l2_flags_t, 1)
vl_msg_name(vl_api_l2_flags_reply_t, 1)
vl_msg_name(vl_api_bridge_domain_set_mac_age_t, 1)
vl_msg_name(vl_api_bridge_domain_set_mac_age_reply_t, 1)
vl_msg_name(vl_api_bridge_domain_add_del_t, 1)
vl_msg_name(vl_api_bridge_domain_add_del_reply_t, 1)
vl_msg_name(vl_api_bridge_domain_dump_t, 1)
/* typeonly: bridge_domain_sw_if */
vl_msg_name(vl_api_bridge_domain_details_t, 1)
vl_msg_name(vl_api_bridge_flags_t, 1)
vl_msg_name(vl_api_bridge_flags_reply_t, 1)
vl_msg_name(vl_api_l2_interface_vlan_tag_rewrite_t, 1)
vl_msg_name(vl_api_l2_interface_vlan_tag_rewrite_reply_t, 1)
vl_msg_name(vl_api_l2_interface_pbb_tag_rewrite_t, 1)
vl_msg_name(vl_api_l2_interface_pbb_tag_rewrite_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_l2 \
_(VL_API_L2_XCONNECT_DETAILS, l2_xconnect_details, 8983dff7) \
_(VL_API_L2_XCONNECT_DUMP, l2_xconnect_dump, 794eaafb) \
_(VL_API_L2_FIB_TABLE_DETAILS, l2_fib_table_details, 07426ad7) \
_(VL_API_L2_FIB_TABLE_DUMP, l2_fib_table_dump, edcbdcf6) \
_(VL_API_L2_FIB_CLEAR_TABLE, l2_fib_clear_table, 40dc61e3) \
_(VL_API_L2_FIB_CLEAR_TABLE_REPLY, l2_fib_clear_table_reply, 0425b038) \
_(VL_API_L2FIB_FLUSH_ALL, l2fib_flush_all, abc3e39e) \
_(VL_API_L2FIB_FLUSH_ALL_REPLY, l2fib_flush_all_reply, ef3a3245) \
_(VL_API_L2FIB_FLUSH_BD, l2fib_flush_bd, 82b7f182) \
_(VL_API_L2FIB_FLUSH_BD_REPLY, l2fib_flush_bd_reply, a68d5609) \
_(VL_API_L2FIB_FLUSH_INT, l2fib_flush_int, a1216623) \
_(VL_API_L2FIB_FLUSH_INT_REPLY, l2fib_flush_int_reply, aacfc0d0) \
_(VL_API_L2FIB_ADD_DEL, l2fib_add_del, 604cc582) \
_(VL_API_L2FIB_ADD_DEL_REPLY, l2fib_add_del_reply, 1be0875a) \
_(VL_API_WANT_L2_MACS_EVENTS, want_l2_macs_events, c043c52c) \
_(VL_API_WANT_L2_MACS_EVENTS_REPLY, want_l2_macs_events_reply, 97d6535f) \
_(VL_API_L2_MACS_EVENT, l2_macs_event, 2a1cc4f5) \
_(VL_API_L2_FLAGS, l2_flags, 987fb8e1) \
_(VL_API_L2_FLAGS_REPLY, l2_flags_reply, bd749594) \
_(VL_API_BRIDGE_DOMAIN_SET_MAC_AGE, bridge_domain_set_mac_age, f58c37aa) \
_(VL_API_BRIDGE_DOMAIN_SET_MAC_AGE_REPLY, bridge_domain_set_mac_age_reply, c127a682) \
_(VL_API_BRIDGE_DOMAIN_ADD_DEL, bridge_domain_add_del, e9894b51) \
_(VL_API_BRIDGE_DOMAIN_ADD_DEL_REPLY, bridge_domain_add_del_reply, d5e138e4) \
_(VL_API_BRIDGE_DOMAIN_DUMP, bridge_domain_dump, 68d5401d) \
_(VL_API_BRIDGE_DOMAIN_DETAILS, bridge_domain_details, ff7d2b54) \
_(VL_API_BRIDGE_FLAGS, bridge_flags, c1d50251) \
_(VL_API_BRIDGE_FLAGS_REPLY, bridge_flags_reply, fa6b7397) \
_(VL_API_L2_INTERFACE_VLAN_TAG_REWRITE, l2_interface_vlan_tag_rewrite, b9dcbd39) \
_(VL_API_L2_INTERFACE_VLAN_TAG_REWRITE_REPLY, l2_interface_vlan_tag_rewrite_reply, 901eddfb) \
_(VL_API_L2_INTERFACE_PBB_TAG_REWRITE, l2_interface_pbb_tag_rewrite, b7706c15) \
_(VL_API_L2_INTERFACE_PBB_TAG_REWRITE_REPLY, l2_interface_pbb_tag_rewrite_reply, 2d083312) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_l2_xconnect_details {
    u16 _vl_msg_id;
    u32 context;
    u32 rx_sw_if_index;
    u32 tx_sw_if_index;
}) vl_api_l2_xconnect_details_t;

typedef VL_API_PACKED(struct _vl_api_l2_xconnect_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_l2_xconnect_dump_t;

typedef VL_API_PACKED(struct _vl_api_l2_fib_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 bd_id;
    u64 mac;
    u32 sw_if_index;
    u8 static_mac;
    u8 filter_mac;
    u8 bvi_mac;
}) vl_api_l2_fib_table_details_t;

typedef VL_API_PACKED(struct _vl_api_l2_fib_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
}) vl_api_l2_fib_table_dump_t;

typedef VL_API_PACKED(struct _vl_api_l2_fib_clear_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_l2_fib_clear_table_t;

typedef VL_API_PACKED(struct _vl_api_l2_fib_clear_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2_fib_clear_table_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_all {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_l2fib_flush_all_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_all_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2fib_flush_all_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_bd {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
}) vl_api_l2fib_flush_bd_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_bd_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2fib_flush_bd_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_int {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_l2fib_flush_int_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_flush_int_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2fib_flush_int_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 mac;
    u32 bd_id;
    u32 sw_if_index;
    u8 is_add;
    u8 static_mac;
    u8 filter_mac;
    u8 bvi_mac;
}) vl_api_l2fib_add_del_t;

typedef VL_API_PACKED(struct _vl_api_l2fib_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2fib_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_want_l2_macs_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 learn_limit;
    u8 scan_delay;
    u8 max_macs_in_event;
    u8 enable_disable;
    u32 pid;
}) vl_api_want_l2_macs_events_t;

typedef VL_API_PACKED(struct _vl_api_want_l2_macs_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_l2_macs_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_mac_entry {
    u32 sw_if_index;
    u8 mac_addr[6];
    u8 is_del;
    u8 spare;
}) vl_api_mac_entry_t;

typedef VL_API_PACKED(struct _vl_api_l2_macs_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 pid;
    u32 n_macs;
    vl_api_mac_entry_t mac[0];
}) vl_api_l2_macs_event_t;

typedef VL_API_PACKED(struct _vl_api_l2_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_set;
    u32 feature_bitmap;
}) vl_api_l2_flags_t;

typedef VL_API_PACKED(struct _vl_api_l2_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 resulting_feature_bitmap;
}) vl_api_l2_flags_reply_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_set_mac_age {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 mac_age;
}) vl_api_bridge_domain_set_mac_age_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_set_mac_age_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bridge_domain_set_mac_age_reply_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 flood;
    u8 uu_flood;
    u8 forward;
    u8 learn;
    u8 arp_term;
    u8 mac_age;
    u8 bd_tag[64];
    u8 is_add;
}) vl_api_bridge_domain_add_del_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_bridge_domain_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
}) vl_api_bridge_domain_dump_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_sw_if {
    u32 context;
    u32 sw_if_index;
    u8 shg;
}) vl_api_bridge_domain_sw_if_t;

typedef VL_API_PACKED(struct _vl_api_bridge_domain_details {
    u16 _vl_msg_id;
    u32 context;
    u32 bd_id;
    u8 flood;
    u8 uu_flood;
    u8 forward;
    u8 learn;
    u8 arp_term;
    u8 mac_age;
    u8 bd_tag[64];
    u32 bvi_sw_if_index;
    u32 n_sw_ifs;
    vl_api_bridge_domain_sw_if_t sw_if_details[0];
}) vl_api_bridge_domain_details_t;

typedef VL_API_PACKED(struct _vl_api_bridge_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd_id;
    u8 is_set;
    u32 feature_bitmap;
}) vl_api_bridge_flags_t;

typedef VL_API_PACKED(struct _vl_api_bridge_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 resulting_feature_bitmap;
}) vl_api_bridge_flags_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_vlan_tag_rewrite {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 vtr_op;
    u32 push_dot1q;
    u32 tag1;
    u32 tag2;
}) vl_api_l2_interface_vlan_tag_rewrite_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_vlan_tag_rewrite_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2_interface_vlan_tag_rewrite_reply_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_pbb_tag_rewrite {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 vtr_op;
    u16 outer_tag;
    u8 b_dmac[6];
    u8 b_smac[6];
    u16 b_vlanid;
    u32 i_sid;
}) vl_api_l2_interface_pbb_tag_rewrite_t;

typedef VL_API_PACKED(struct _vl_api_l2_interface_pbb_tag_rewrite_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_l2_interface_pbb_tag_rewrite_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_l2_xconnect_details_t_print (vl_api_l2_xconnect_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_xconnect_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "rx_sw_if_index: %u\n", (unsigned) a->rx_sw_if_index);
    vl_print(handle, "tx_sw_if_index: %u\n", (unsigned) a->tx_sw_if_index);
    return handle;
}

static inline void *vl_api_l2_xconnect_dump_t_print (vl_api_l2_xconnect_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_xconnect_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_l2_fib_table_details_t_print (vl_api_l2_fib_table_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_fib_table_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "mac: %llu\n", (long long) a->mac);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "static_mac: %u\n", (unsigned) a->static_mac);
    vl_print(handle, "filter_mac: %u\n", (unsigned) a->filter_mac);
    vl_print(handle, "bvi_mac: %u\n", (unsigned) a->bvi_mac);
    return handle;
}

static inline void *vl_api_l2_fib_table_dump_t_print (vl_api_l2_fib_table_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_fib_table_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    return handle;
}

static inline void *vl_api_l2_fib_clear_table_t_print (vl_api_l2_fib_clear_table_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_fib_clear_table_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_l2_fib_clear_table_reply_t_print (vl_api_l2_fib_clear_table_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_fib_clear_table_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2fib_flush_all_t_print (vl_api_l2fib_flush_all_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_all_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_l2fib_flush_all_reply_t_print (vl_api_l2fib_flush_all_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_all_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2fib_flush_bd_t_print (vl_api_l2fib_flush_bd_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_bd_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    return handle;
}

static inline void *vl_api_l2fib_flush_bd_reply_t_print (vl_api_l2fib_flush_bd_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_bd_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2fib_flush_int_t_print (vl_api_l2fib_flush_int_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_int_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_l2fib_flush_int_reply_t_print (vl_api_l2fib_flush_int_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_flush_int_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2fib_add_del_t_print (vl_api_l2fib_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mac: %llu\n", (long long) a->mac);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "static_mac: %u\n", (unsigned) a->static_mac);
    vl_print(handle, "filter_mac: %u\n", (unsigned) a->filter_mac);
    vl_print(handle, "bvi_mac: %u\n", (unsigned) a->bvi_mac);
    return handle;
}

static inline void *vl_api_l2fib_add_del_reply_t_print (vl_api_l2fib_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2fib_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_want_l2_macs_events_t_print (vl_api_want_l2_macs_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_l2_macs_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "learn_limit: %u\n", (unsigned) a->learn_limit);
    vl_print(handle, "scan_delay: %u\n", (unsigned) a->scan_delay);
    vl_print(handle, "max_macs_in_event: %u\n", (unsigned) a->max_macs_in_event);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_l2_macs_events_reply_t_print (vl_api_want_l2_macs_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_l2_macs_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_mac_entry_t_print (vl_api_mac_entry_t *a,void *handle)
{
    vl_print(handle, "vl_api_mac_entry_t:\n");
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_addr[%d]: %u\n", _i, a->mac_addr[_i]);
        }
    }
    vl_print(handle, "is_del: %u\n", (unsigned) a->is_del);
    vl_print(handle, "spare: %u\n", (unsigned) a->spare);
    return handle;
}

static inline void *vl_api_l2_macs_event_t_print (vl_api_l2_macs_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_macs_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "n_macs: %u\n", (unsigned) a->n_macs);
    vl_print(handle, "mac ----- \n");
    vl_api_mac_entry_t_print(a->mac, handle);
    vl_print(handle, "mac ----- END \n");
    return handle;
}

static inline void *vl_api_l2_flags_t_print (vl_api_l2_flags_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_flags_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_set: %u\n", (unsigned) a->is_set);
    vl_print(handle, "feature_bitmap: %u\n", (unsigned) a->feature_bitmap);
    return handle;
}

static inline void *vl_api_l2_flags_reply_t_print (vl_api_l2_flags_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_flags_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "resulting_feature_bitmap: %u\n", (unsigned) a->resulting_feature_bitmap);
    return handle;
}

static inline void *vl_api_bridge_domain_set_mac_age_t_print (vl_api_bridge_domain_set_mac_age_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_domain_set_mac_age_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "mac_age: %u\n", (unsigned) a->mac_age);
    return handle;
}

static inline void *vl_api_bridge_domain_set_mac_age_reply_t_print (vl_api_bridge_domain_set_mac_age_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_domain_set_mac_age_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bridge_domain_add_del_t_print (vl_api_bridge_domain_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_domain_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "flood: %u\n", (unsigned) a->flood);
    vl_print(handle, "uu_flood: %u\n", (unsigned) a->uu_flood);
    vl_print(handle, "forward: %u\n", (unsigned) a->forward);
    vl_print(handle, "learn: %u\n", (unsigned) a->learn);
    vl_print(handle, "arp_term: %u\n", (unsigned) a->arp_term);
    vl_print(handle, "mac_age: %u\n", (unsigned) a->mac_age);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "bd_tag[%d]: %u\n", _i, a->bd_tag[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_bridge_domain_add_del_reply_t_print (vl_api_bridge_domain_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_domain_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_bridge_domain_dump_t_print (vl_api_bridge_domain_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_domain_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    return handle;
}

/***** manual: vl_api_bridge_domain_sw_if_t_print  *****/

/***** manual: vl_api_bridge_domain_details_t_print  *****/

static inline void *vl_api_bridge_flags_t_print (vl_api_bridge_flags_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_flags_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd_id: %u\n", (unsigned) a->bd_id);
    vl_print(handle, "is_set: %u\n", (unsigned) a->is_set);
    vl_print(handle, "feature_bitmap: %u\n", (unsigned) a->feature_bitmap);
    return handle;
}

static inline void *vl_api_bridge_flags_reply_t_print (vl_api_bridge_flags_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_bridge_flags_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "resulting_feature_bitmap: %u\n", (unsigned) a->resulting_feature_bitmap);
    return handle;
}

static inline void *vl_api_l2_interface_vlan_tag_rewrite_t_print (vl_api_l2_interface_vlan_tag_rewrite_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_vlan_tag_rewrite_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "vtr_op: %u\n", (unsigned) a->vtr_op);
    vl_print(handle, "push_dot1q: %u\n", (unsigned) a->push_dot1q);
    vl_print(handle, "tag1: %u\n", (unsigned) a->tag1);
    vl_print(handle, "tag2: %u\n", (unsigned) a->tag2);
    return handle;
}

static inline void *vl_api_l2_interface_vlan_tag_rewrite_reply_t_print (vl_api_l2_interface_vlan_tag_rewrite_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_vlan_tag_rewrite_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_l2_interface_pbb_tag_rewrite_t_print (vl_api_l2_interface_pbb_tag_rewrite_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_pbb_tag_rewrite_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "vtr_op: %u\n", (unsigned) a->vtr_op);
    vl_print(handle, "outer_tag: %u\n", (unsigned) a->outer_tag);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "b_dmac[%d]: %u\n", _i, a->b_dmac[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "b_smac[%d]: %u\n", _i, a->b_smac[_i]);
        }
    }
    vl_print(handle, "b_vlanid: %u\n", (unsigned) a->b_vlanid);
    vl_print(handle, "i_sid: %u\n", (unsigned) a->i_sid);
    return handle;
}

static inline void *vl_api_l2_interface_pbb_tag_rewrite_reply_t_print (vl_api_l2_interface_pbb_tag_rewrite_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_l2_interface_pbb_tag_rewrite_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_l2_xconnect_details_t_endian (vl_api_l2_xconnect_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->rx_sw_if_index = clib_net_to_host_u32(a->rx_sw_if_index);
    a->tx_sw_if_index = clib_net_to_host_u32(a->tx_sw_if_index);
}

static inline void vl_api_l2_xconnect_dump_t_endian (vl_api_l2_xconnect_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_l2_fib_table_details_t_endian (vl_api_l2_fib_table_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    a->mac = clib_net_to_host_u64(a->mac);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->static_mac = a->static_mac (no-op) */
    /* a->filter_mac = a->filter_mac (no-op) */
    /* a->bvi_mac = a->bvi_mac (no-op) */
}

static inline void vl_api_l2_fib_table_dump_t_endian (vl_api_l2_fib_table_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
}

static inline void vl_api_l2_fib_clear_table_t_endian (vl_api_l2_fib_clear_table_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_l2_fib_clear_table_reply_t_endian (vl_api_l2_fib_clear_table_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2fib_flush_all_t_endian (vl_api_l2fib_flush_all_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_l2fib_flush_all_reply_t_endian (vl_api_l2fib_flush_all_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2fib_flush_bd_t_endian (vl_api_l2fib_flush_bd_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
}

static inline void vl_api_l2fib_flush_bd_reply_t_endian (vl_api_l2fib_flush_bd_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2fib_flush_int_t_endian (vl_api_l2fib_flush_int_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_l2fib_flush_int_reply_t_endian (vl_api_l2fib_flush_int_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2fib_add_del_t_endian (vl_api_l2fib_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->mac = clib_net_to_host_u64(a->mac);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_add = a->is_add (no-op) */
    /* a->static_mac = a->static_mac (no-op) */
    /* a->filter_mac = a->filter_mac (no-op) */
    /* a->bvi_mac = a->bvi_mac (no-op) */
}

static inline void vl_api_l2fib_add_del_reply_t_endian (vl_api_l2fib_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_want_l2_macs_events_t_endian (vl_api_want_l2_macs_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->learn_limit = clib_net_to_host_u32(a->learn_limit);
    /* a->scan_delay = a->scan_delay (no-op) */
    /* a->max_macs_in_event = a->max_macs_in_event (no-op) */
    /* a->enable_disable = a->enable_disable (no-op) */
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_l2_macs_events_reply_t_endian (vl_api_want_l2_macs_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_mac_entry_t_endian (vl_api_mac_entry_t *a)
{
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->mac_addr[0..5] = a->mac_addr[0..5] (no-op) */
    /* a->is_del = a->is_del (no-op) */
    /* a->spare = a->spare (no-op) */
}

static inline void vl_api_l2_macs_event_t_endian (vl_api_l2_macs_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->pid = clib_net_to_host_u32(a->pid);
    a->n_macs = clib_net_to_host_u32(a->n_macs);
    vl_api_mac_entry_t_endian(a->mac);
}

static inline void vl_api_l2_flags_t_endian (vl_api_l2_flags_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_set = a->is_set (no-op) */
    a->feature_bitmap = clib_net_to_host_u32(a->feature_bitmap);
}

static inline void vl_api_l2_flags_reply_t_endian (vl_api_l2_flags_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->resulting_feature_bitmap = clib_net_to_host_u32(a->resulting_feature_bitmap);
}

static inline void vl_api_bridge_domain_set_mac_age_t_endian (vl_api_bridge_domain_set_mac_age_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    /* a->mac_age = a->mac_age (no-op) */
}

static inline void vl_api_bridge_domain_set_mac_age_reply_t_endian (vl_api_bridge_domain_set_mac_age_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bridge_domain_add_del_t_endian (vl_api_bridge_domain_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    /* a->flood = a->flood (no-op) */
    /* a->uu_flood = a->uu_flood (no-op) */
    /* a->forward = a->forward (no-op) */
    /* a->learn = a->learn (no-op) */
    /* a->arp_term = a->arp_term (no-op) */
    /* a->mac_age = a->mac_age (no-op) */
    /* a->bd_tag[0..63] = a->bd_tag[0..63] (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_bridge_domain_add_del_reply_t_endian (vl_api_bridge_domain_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_bridge_domain_dump_t_endian (vl_api_bridge_domain_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
}

/***** manual: vl_api_bridge_domain_sw_if_t_endian  *****/

/***** manual: vl_api_bridge_domain_details_t_endian  *****/

static inline void vl_api_bridge_flags_t_endian (vl_api_bridge_flags_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd_id = clib_net_to_host_u32(a->bd_id);
    /* a->is_set = a->is_set (no-op) */
    a->feature_bitmap = clib_net_to_host_u32(a->feature_bitmap);
}

static inline void vl_api_bridge_flags_reply_t_endian (vl_api_bridge_flags_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->resulting_feature_bitmap = clib_net_to_host_u32(a->resulting_feature_bitmap);
}

static inline void vl_api_l2_interface_vlan_tag_rewrite_t_endian (vl_api_l2_interface_vlan_tag_rewrite_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->vtr_op = clib_net_to_host_u32(a->vtr_op);
    a->push_dot1q = clib_net_to_host_u32(a->push_dot1q);
    a->tag1 = clib_net_to_host_u32(a->tag1);
    a->tag2 = clib_net_to_host_u32(a->tag2);
}

static inline void vl_api_l2_interface_vlan_tag_rewrite_reply_t_endian (vl_api_l2_interface_vlan_tag_rewrite_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_l2_interface_pbb_tag_rewrite_t_endian (vl_api_l2_interface_pbb_tag_rewrite_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->vtr_op = clib_net_to_host_u32(a->vtr_op);
    a->outer_tag = clib_net_to_host_u16(a->outer_tag);
    /* a->b_dmac[0..5] = a->b_dmac[0..5] (no-op) */
    /* a->b_smac[0..5] = a->b_smac[0..5] (no-op) */
    a->b_vlanid = clib_net_to_host_u16(a->b_vlanid);
    a->i_sid = clib_net_to_host_u32(a->i_sid);
}

static inline void vl_api_l2_interface_pbb_tag_rewrite_reply_t_endian (vl_api_l2_interface_pbb_tag_rewrite_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(l2.api, 0x57745ea6)

#endif

