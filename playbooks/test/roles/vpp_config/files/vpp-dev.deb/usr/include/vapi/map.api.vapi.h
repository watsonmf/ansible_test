#ifndef __included_map_api_json
#define __included_map_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_map_add_domain_reply;
extern vapi_msg_id_t vapi_msg_id_map_domain_details;
extern vapi_msg_id_t vapi_msg_id_map_del_domain_reply;
extern vapi_msg_id_t vapi_msg_id_map_rule_dump;
extern vapi_msg_id_t vapi_msg_id_map_add_del_rule_reply;
extern vapi_msg_id_t vapi_msg_id_map_add_del_rule;
extern vapi_msg_id_t vapi_msg_id_map_summary_stats_reply;
extern vapi_msg_id_t vapi_msg_id_map_add_domain;
extern vapi_msg_id_t vapi_msg_id_map_summary_stats;
extern vapi_msg_id_t vapi_msg_id_map_del_domain;
extern vapi_msg_id_t vapi_msg_id_map_domain_dump;
extern vapi_msg_id_t vapi_msg_id_map_rule_details;

#define DEFINE_VAPI_MSG_IDS_MAP_API_JSON\
  vapi_msg_id_t vapi_msg_id_map_add_domain_reply;\
  vapi_msg_id_t vapi_msg_id_map_domain_details;\
  vapi_msg_id_t vapi_msg_id_map_del_domain_reply;\
  vapi_msg_id_t vapi_msg_id_map_rule_dump;\
  vapi_msg_id_t vapi_msg_id_map_add_del_rule_reply;\
  vapi_msg_id_t vapi_msg_id_map_add_del_rule;\
  vapi_msg_id_t vapi_msg_id_map_summary_stats_reply;\
  vapi_msg_id_t vapi_msg_id_map_add_domain;\
  vapi_msg_id_t vapi_msg_id_map_summary_stats;\
  vapi_msg_id_t vapi_msg_id_map_del_domain;\
  vapi_msg_id_t vapi_msg_id_map_domain_dump;\
  vapi_msg_id_t vapi_msg_id_map_rule_details;


typedef struct __attribute__ ((__packed__)) {
  u32 index;
  i32 retval; 
} vapi_payload_map_add_domain_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_add_domain_reply payload;
} vapi_msg_map_add_domain_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 domain_index;
  u8 ip6_prefix[16];
  u8 ip4_prefix[4];
  u8 ip6_src[16];
  u8 ip6_prefix_len;
  u8 ip4_prefix_len;
  u8 ip6_src_len;
  u8 ea_bits_len;
  u8 psid_offset;
  u8 psid_length;
  u8 flags;
  u16 mtu;
  u8 is_translation; 
} vapi_payload_map_domain_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_domain_details payload;
} vapi_msg_map_domain_details;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_map_del_domain_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_del_domain_reply payload;
} vapi_msg_map_del_domain_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 domain_index; 
} vapi_payload_map_rule_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_map_rule_dump payload;
} vapi_msg_map_rule_dump;

typedef struct __attribute__ ((__packed__)) {
  i32 retval; 
} vapi_payload_map_add_del_rule_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_add_del_rule_reply payload;
} vapi_msg_map_add_del_rule_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 index;
  u8 is_add;
  u8 ip6_dst[16];
  u16 psid; 
} vapi_payload_map_add_del_rule;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_map_add_del_rule payload;
} vapi_msg_map_add_del_rule;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u64 total_bindings;
  u64 total_pkts[2];
  u64 total_bytes[2];
  u64 total_ip4_fragments;
  u64 total_security_check[2]; 
} vapi_payload_map_summary_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_summary_stats_reply payload;
} vapi_msg_map_summary_stats_reply;

typedef struct __attribute__ ((__packed__)) {
  u8 ip6_prefix[16];
  u8 ip4_prefix[4];
  u8 ip6_src[16];
  u8 ip6_prefix_len;
  u8 ip4_prefix_len;
  u8 ip6_src_prefix_len;
  u8 ea_bits_len;
  u8 psid_offset;
  u8 psid_length;
  u8 is_translation;
  u16 mtu; 
} vapi_payload_map_add_domain;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_map_add_domain payload;
} vapi_msg_map_add_domain;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_map_summary_stats;

typedef struct __attribute__ ((__packed__)) {
  u32 index; 
} vapi_payload_map_del_domain;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_map_del_domain payload;
} vapi_msg_map_del_domain;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
} vapi_msg_map_domain_dump;

typedef struct __attribute__ ((__packed__)) {
  u8 ip6_dst[16];
  u16 psid; 
} vapi_payload_map_rule_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_map_rule_details payload;
} vapi_msg_map_rule_details;


static inline void vapi_msg_map_add_domain_reply_payload_hton(vapi_payload_map_add_domain_reply *payload)
{
  payload->index = htobe32(payload->index);
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_map_add_domain_reply_payload_ntoh(vapi_payload_map_add_domain_reply *payload)
{
  payload->index = be32toh(payload->index);
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_map_add_domain_reply_msg_size(vapi_msg_map_add_domain_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_add_domain_reply_hton(vapi_msg_map_add_domain_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_domain_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_add_domain_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_add_domain_reply_ntoh(vapi_msg_map_add_domain_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_domain_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_add_domain_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_domain_details_payload_hton(vapi_payload_map_domain_details *payload)
{
  payload->domain_index = htobe32(payload->domain_index);
  payload->mtu = htobe16(payload->mtu);
}

static inline void vapi_msg_map_domain_details_payload_ntoh(vapi_payload_map_domain_details *payload)
{
  payload->domain_index = be32toh(payload->domain_index);
  payload->mtu = be16toh(payload->mtu);
}

static inline uword vapi_calc_map_domain_details_msg_size(vapi_msg_map_domain_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_domain_details_hton(vapi_msg_map_domain_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_domain_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_domain_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_domain_details_ntoh(vapi_msg_map_domain_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_domain_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_domain_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_del_domain_reply_payload_hton(vapi_payload_map_del_domain_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_map_del_domain_reply_payload_ntoh(vapi_payload_map_del_domain_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_map_del_domain_reply_msg_size(vapi_msg_map_del_domain_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_del_domain_reply_hton(vapi_msg_map_del_domain_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_del_domain_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_del_domain_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_del_domain_reply_ntoh(vapi_msg_map_del_domain_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_del_domain_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_del_domain_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_rule_dump_payload_hton(vapi_payload_map_rule_dump *payload)
{
  payload->domain_index = htobe32(payload->domain_index);
}

static inline void vapi_msg_map_rule_dump_payload_ntoh(vapi_payload_map_rule_dump *payload)
{
  payload->domain_index = be32toh(payload->domain_index);
}

static inline uword vapi_calc_map_rule_dump_msg_size(vapi_msg_map_rule_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_rule_dump_hton(vapi_msg_map_rule_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_rule_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_map_rule_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_rule_dump_ntoh(vapi_msg_map_rule_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_rule_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_map_rule_dump_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_add_del_rule_reply_payload_hton(vapi_payload_map_add_del_rule_reply *payload)
{
  payload->retval = htobe32(payload->retval);
}

static inline void vapi_msg_map_add_del_rule_reply_payload_ntoh(vapi_payload_map_add_del_rule_reply *payload)
{
  payload->retval = be32toh(payload->retval);
}

static inline uword vapi_calc_map_add_del_rule_reply_msg_size(vapi_msg_map_add_del_rule_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_add_del_rule_reply_hton(vapi_msg_map_add_del_rule_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_del_rule_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_add_del_rule_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_add_del_rule_reply_ntoh(vapi_msg_map_add_del_rule_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_del_rule_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_add_del_rule_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_add_del_rule_payload_hton(vapi_payload_map_add_del_rule *payload)
{
  payload->index = htobe32(payload->index);
  payload->psid = htobe16(payload->psid);
}

static inline void vapi_msg_map_add_del_rule_payload_ntoh(vapi_payload_map_add_del_rule *payload)
{
  payload->index = be32toh(payload->index);
  payload->psid = be16toh(payload->psid);
}

static inline uword vapi_calc_map_add_del_rule_msg_size(vapi_msg_map_add_del_rule *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_add_del_rule_hton(vapi_msg_map_add_del_rule *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_del_rule'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_map_add_del_rule_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_add_del_rule_ntoh(vapi_msg_map_add_del_rule *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_del_rule'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_map_add_del_rule_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_summary_stats_reply_payload_hton(vapi_payload_map_summary_stats_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->total_bindings = htobe64(payload->total_bindings);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_pkts[i] = htobe64(payload->total_pkts[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_bytes[i] = htobe64(payload->total_bytes[i]); } } while(0);
  payload->total_ip4_fragments = htobe64(payload->total_ip4_fragments);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_security_check[i] = htobe64(payload->total_security_check[i]); } } while(0);
}

static inline void vapi_msg_map_summary_stats_reply_payload_ntoh(vapi_payload_map_summary_stats_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->total_bindings = be64toh(payload->total_bindings);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_pkts[i] = be64toh(payload->total_pkts[i]); } } while(0);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_bytes[i] = be64toh(payload->total_bytes[i]); } } while(0);
  payload->total_ip4_fragments = be64toh(payload->total_ip4_fragments);
  do { unsigned i; for (i = 0; i < 2; ++i) { payload->total_security_check[i] = be64toh(payload->total_security_check[i]); } } while(0);
}

static inline uword vapi_calc_map_summary_stats_reply_msg_size(vapi_msg_map_summary_stats_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_summary_stats_reply_hton(vapi_msg_map_summary_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_summary_stats_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_summary_stats_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_summary_stats_reply_ntoh(vapi_msg_map_summary_stats_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_summary_stats_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_summary_stats_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_map_add_domain_payload_hton(vapi_payload_map_add_domain *payload)
{
  payload->mtu = htobe16(payload->mtu);
}

static inline void vapi_msg_map_add_domain_payload_ntoh(vapi_payload_map_add_domain *payload)
{
  payload->mtu = be16toh(payload->mtu);
}

static inline uword vapi_calc_map_add_domain_msg_size(vapi_msg_map_add_domain *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_add_domain_hton(vapi_msg_map_add_domain *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_domain'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_map_add_domain_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_add_domain_ntoh(vapi_msg_map_add_domain *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_add_domain'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_map_add_domain_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_map_summary_stats_msg_size(vapi_msg_map_summary_stats *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_summary_stats_hton(vapi_msg_map_summary_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_summary_stats'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_map_summary_stats_ntoh(vapi_msg_map_summary_stats *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_summary_stats'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_map_del_domain_payload_hton(vapi_payload_map_del_domain *payload)
{
  payload->index = htobe32(payload->index);
}

static inline void vapi_msg_map_del_domain_payload_ntoh(vapi_payload_map_del_domain *payload)
{
  payload->index = be32toh(payload->index);
}

static inline uword vapi_calc_map_del_domain_msg_size(vapi_msg_map_del_domain *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_del_domain_hton(vapi_msg_map_del_domain *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_del_domain'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_map_del_domain_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_del_domain_ntoh(vapi_msg_map_del_domain *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_del_domain'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_map_del_domain_payload_ntoh(&msg->payload);
}

static inline uword vapi_calc_map_domain_dump_msg_size(vapi_msg_map_domain_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_domain_dump_hton(vapi_msg_map_domain_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_domain_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);

}

static inline void vapi_msg_map_domain_dump_ntoh(vapi_msg_map_domain_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_domain_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);

}

static inline void vapi_msg_map_rule_details_payload_hton(vapi_payload_map_rule_details *payload)
{
  payload->psid = htobe16(payload->psid);
}

static inline void vapi_msg_map_rule_details_payload_ntoh(vapi_payload_map_rule_details *payload)
{
  payload->psid = be16toh(payload->psid);
}

static inline uword vapi_calc_map_rule_details_msg_size(vapi_msg_map_rule_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_map_rule_details_hton(vapi_msg_map_rule_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_rule_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_map_rule_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_map_rule_details_ntoh(vapi_msg_map_rule_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_map_rule_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_map_rule_details_payload_ntoh(&msg->payload);
}

static inline vapi_msg_map_rule_dump* vapi_alloc_map_rule_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_rule_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_rule_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_rule_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_rule_dump);

  return msg;
}

static inline vapi_error_e vapi_map_rule_dump(struct vapi_ctx_s *ctx,
  vapi_msg_map_rule_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_rule_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_rule_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_rule_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_add_del_rule* vapi_alloc_map_add_del_rule(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_add_del_rule *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_add_del_rule);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_add_del_rule*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_add_del_rule);

  return msg;
}

static inline vapi_error_e vapi_map_add_del_rule(struct vapi_ctx_s *ctx,
  vapi_msg_map_add_del_rule *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_add_del_rule_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_add_del_rule_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_add_del_rule_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_add_domain* vapi_alloc_map_add_domain(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_add_domain *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_add_domain);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_add_domain*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_add_domain);

  return msg;
}

static inline vapi_error_e vapi_map_add_domain(struct vapi_ctx_s *ctx,
  vapi_msg_map_add_domain *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_add_domain_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_add_domain_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_add_domain_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_summary_stats* vapi_alloc_map_summary_stats(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_summary_stats *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_summary_stats);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_summary_stats*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_summary_stats);

  return msg;
}

static inline vapi_error_e vapi_map_summary_stats(struct vapi_ctx_s *ctx,
  vapi_msg_map_summary_stats *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_summary_stats_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_summary_stats_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_summary_stats_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_del_domain* vapi_alloc_map_del_domain(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_del_domain *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_del_domain);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_del_domain*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_del_domain);

  return msg;
}

static inline vapi_error_e vapi_map_del_domain(struct vapi_ctx_s *ctx,
  vapi_msg_map_del_domain *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_del_domain_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_del_domain_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_del_domain_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_map_domain_dump* vapi_alloc_map_domain_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_map_domain_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_map_domain_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_map_domain_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_map_domain_dump);

  return msg;
}

static inline vapi_error_e vapi_map_domain_dump(struct vapi_ctx_s *ctx,
  vapi_msg_map_domain_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_map_domain_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_map_domain_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_map_domain_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_map_add_domain_reply()
{
  static const char name[] = "map_add_domain_reply";
  static const char name_with_crc[] = "map_add_domain_reply_f6c61861";
  static vapi_message_desc_t __vapi_metadata_map_add_domain_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_add_domain_reply, payload),
    sizeof(vapi_msg_map_add_domain_reply),
    (generic_swap_fn_t)vapi_msg_map_add_domain_reply_hton,
    (generic_swap_fn_t)vapi_msg_map_add_domain_reply_ntoh,
    ~0,
  };

  vapi_msg_id_map_add_domain_reply = vapi_register_msg(&__vapi_metadata_map_add_domain_reply);
  VAPI_DBG("Assigned msg id %d to map_add_domain_reply", vapi_msg_id_map_add_domain_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_domain_details()
{
  static const char name[] = "map_domain_details";
  static const char name_with_crc[] = "map_domain_details_caa121eb";
  static vapi_message_desc_t __vapi_metadata_map_domain_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_domain_details, payload),
    sizeof(vapi_msg_map_domain_details),
    (generic_swap_fn_t)vapi_msg_map_domain_details_hton,
    (generic_swap_fn_t)vapi_msg_map_domain_details_ntoh,
    ~0,
  };

  vapi_msg_id_map_domain_details = vapi_register_msg(&__vapi_metadata_map_domain_details);
  VAPI_DBG("Assigned msg id %d to map_domain_details", vapi_msg_id_map_domain_details);
}

static void __attribute__((constructor)) __vapi_constructor_map_del_domain_reply()
{
  static const char name[] = "map_del_domain_reply";
  static const char name_with_crc[] = "map_del_domain_reply_7c61a925";
  static vapi_message_desc_t __vapi_metadata_map_del_domain_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_del_domain_reply, payload),
    sizeof(vapi_msg_map_del_domain_reply),
    (generic_swap_fn_t)vapi_msg_map_del_domain_reply_hton,
    (generic_swap_fn_t)vapi_msg_map_del_domain_reply_ntoh,
    ~0,
  };

  vapi_msg_id_map_del_domain_reply = vapi_register_msg(&__vapi_metadata_map_del_domain_reply);
  VAPI_DBG("Assigned msg id %d to map_del_domain_reply", vapi_msg_id_map_del_domain_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_rule_dump()
{
  static const char name[] = "map_rule_dump";
  static const char name_with_crc[] = "map_rule_dump_11d0e36b";
  static vapi_message_desc_t __vapi_metadata_map_rule_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_map_rule_dump, payload),
    sizeof(vapi_msg_map_rule_dump),
    (generic_swap_fn_t)vapi_msg_map_rule_dump_hton,
    (generic_swap_fn_t)vapi_msg_map_rule_dump_ntoh,
    ~0,
  };

  vapi_msg_id_map_rule_dump = vapi_register_msg(&__vapi_metadata_map_rule_dump);
  VAPI_DBG("Assigned msg id %d to map_rule_dump", vapi_msg_id_map_rule_dump);
}

static void __attribute__((constructor)) __vapi_constructor_map_add_del_rule_reply()
{
  static const char name[] = "map_add_del_rule_reply";
  static const char name_with_crc[] = "map_add_del_rule_reply_02c9e765";
  static vapi_message_desc_t __vapi_metadata_map_add_del_rule_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_add_del_rule_reply, payload),
    sizeof(vapi_msg_map_add_del_rule_reply),
    (generic_swap_fn_t)vapi_msg_map_add_del_rule_reply_hton,
    (generic_swap_fn_t)vapi_msg_map_add_del_rule_reply_ntoh,
    ~0,
  };

  vapi_msg_id_map_add_del_rule_reply = vapi_register_msg(&__vapi_metadata_map_add_del_rule_reply);
  VAPI_DBG("Assigned msg id %d to map_add_del_rule_reply", vapi_msg_id_map_add_del_rule_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_add_del_rule()
{
  static const char name[] = "map_add_del_rule";
  static const char name_with_crc[] = "map_add_del_rule_3e3644ad";
  static vapi_message_desc_t __vapi_metadata_map_add_del_rule = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_map_add_del_rule, payload),
    sizeof(vapi_msg_map_add_del_rule),
    (generic_swap_fn_t)vapi_msg_map_add_del_rule_hton,
    (generic_swap_fn_t)vapi_msg_map_add_del_rule_ntoh,
    ~0,
  };

  vapi_msg_id_map_add_del_rule = vapi_register_msg(&__vapi_metadata_map_add_del_rule);
  VAPI_DBG("Assigned msg id %d to map_add_del_rule", vapi_msg_id_map_add_del_rule);
}

static void __attribute__((constructor)) __vapi_constructor_map_summary_stats_reply()
{
  static const char name[] = "map_summary_stats_reply";
  static const char name_with_crc[] = "map_summary_stats_reply_700b3e21";
  static vapi_message_desc_t __vapi_metadata_map_summary_stats_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_summary_stats_reply, payload),
    sizeof(vapi_msg_map_summary_stats_reply),
    (generic_swap_fn_t)vapi_msg_map_summary_stats_reply_hton,
    (generic_swap_fn_t)vapi_msg_map_summary_stats_reply_ntoh,
    ~0,
  };

  vapi_msg_id_map_summary_stats_reply = vapi_register_msg(&__vapi_metadata_map_summary_stats_reply);
  VAPI_DBG("Assigned msg id %d to map_summary_stats_reply", vapi_msg_id_map_summary_stats_reply);
}

static void __attribute__((constructor)) __vapi_constructor_map_add_domain()
{
  static const char name[] = "map_add_domain";
  static const char name_with_crc[] = "map_add_domain_e83fafb7";
  static vapi_message_desc_t __vapi_metadata_map_add_domain = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_map_add_domain, payload),
    sizeof(vapi_msg_map_add_domain),
    (generic_swap_fn_t)vapi_msg_map_add_domain_hton,
    (generic_swap_fn_t)vapi_msg_map_add_domain_ntoh,
    ~0,
  };

  vapi_msg_id_map_add_domain = vapi_register_msg(&__vapi_metadata_map_add_domain);
  VAPI_DBG("Assigned msg id %d to map_add_domain", vapi_msg_id_map_add_domain);
}

static void __attribute__((constructor)) __vapi_constructor_map_summary_stats()
{
  static const char name[] = "map_summary_stats";
  static const char name_with_crc[] = "map_summary_stats_f6a12980";
  static vapi_message_desc_t __vapi_metadata_map_summary_stats = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_map_summary_stats),
    (generic_swap_fn_t)vapi_msg_map_summary_stats_hton,
    (generic_swap_fn_t)vapi_msg_map_summary_stats_ntoh,
    ~0,
  };

  vapi_msg_id_map_summary_stats = vapi_register_msg(&__vapi_metadata_map_summary_stats);
  VAPI_DBG("Assigned msg id %d to map_summary_stats", vapi_msg_id_map_summary_stats);
}

static void __attribute__((constructor)) __vapi_constructor_map_del_domain()
{
  static const char name[] = "map_del_domain";
  static const char name_with_crc[] = "map_del_domain_4c06875c";
  static vapi_message_desc_t __vapi_metadata_map_del_domain = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_map_del_domain, payload),
    sizeof(vapi_msg_map_del_domain),
    (generic_swap_fn_t)vapi_msg_map_del_domain_hton,
    (generic_swap_fn_t)vapi_msg_map_del_domain_ntoh,
    ~0,
  };

  vapi_msg_id_map_del_domain = vapi_register_msg(&__vapi_metadata_map_del_domain);
  VAPI_DBG("Assigned msg id %d to map_del_domain", vapi_msg_id_map_del_domain);
}

static void __attribute__((constructor)) __vapi_constructor_map_domain_dump()
{
  static const char name[] = "map_domain_dump";
  static const char name_with_crc[] = "map_domain_dump_b64dff5d";
  static vapi_message_desc_t __vapi_metadata_map_domain_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    ~0,
    sizeof(vapi_msg_map_domain_dump),
    (generic_swap_fn_t)vapi_msg_map_domain_dump_hton,
    (generic_swap_fn_t)vapi_msg_map_domain_dump_ntoh,
    ~0,
  };

  vapi_msg_id_map_domain_dump = vapi_register_msg(&__vapi_metadata_map_domain_dump);
  VAPI_DBG("Assigned msg id %d to map_domain_dump", vapi_msg_id_map_domain_dump);
}

static void __attribute__((constructor)) __vapi_constructor_map_rule_details()
{
  static const char name[] = "map_rule_details";
  static const char name_with_crc[] = "map_rule_details_7ef2b612";
  static vapi_message_desc_t __vapi_metadata_map_rule_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_map_rule_details, payload),
    sizeof(vapi_msg_map_rule_details),
    (generic_swap_fn_t)vapi_msg_map_rule_details_hton,
    (generic_swap_fn_t)vapi_msg_map_rule_details_ntoh,
    ~0,
  };

  vapi_msg_id_map_rule_details = vapi_register_msg(&__vapi_metadata_map_rule_details);
  VAPI_DBG("Assigned msg id %d to map_rule_details", vapi_msg_id_map_rule_details);
}


static inline void vapi_set_vapi_msg_map_add_domain_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_add_domain_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_add_domain_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_domain_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_domain_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_domain_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_del_domain_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_del_domain_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_del_domain_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_add_del_rule_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_add_del_rule_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_add_del_rule_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_summary_stats_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_summary_stats_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_summary_stats_reply, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_map_rule_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_map_rule_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_map_rule_details, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
