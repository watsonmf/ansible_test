/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/lisp-cp/one.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/lisp-cp/one.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
/* typeonly: one_local_locator */
vl_msg_id(VL_API_ONE_ADD_DEL_LOCATOR_SET, vl_api_one_add_del_locator_set_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_LOCATOR_SET_REPLY, vl_api_one_add_del_locator_set_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_LOCATOR, vl_api_one_add_del_locator_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_LOCATOR_REPLY, vl_api_one_add_del_locator_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_LOCAL_EID, vl_api_one_add_del_local_eid_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_LOCAL_EID_REPLY, vl_api_one_add_del_local_eid_reply_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_SET_TTL, vl_api_one_map_register_set_ttl_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_SET_TTL_REPLY, vl_api_one_map_register_set_ttl_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_TTL, vl_api_show_one_map_register_ttl_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_TTL_REPLY, vl_api_show_one_map_register_ttl_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_SERVER, vl_api_one_add_del_map_server_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_SERVER_REPLY, vl_api_one_add_del_map_server_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_RESOLVER, vl_api_one_add_del_map_resolver_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_RESOLVER_REPLY, vl_api_one_add_del_map_resolver_reply_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE, vl_api_one_enable_disable_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_REPLY, vl_api_one_enable_disable_reply_t_handler)
vl_msg_id(VL_API_ONE_NSH_SET_LOCATOR_SET, vl_api_one_nsh_set_locator_set_t_handler)
vl_msg_id(VL_API_ONE_NSH_SET_LOCATOR_SET_REPLY, vl_api_one_nsh_set_locator_set_reply_t_handler)
vl_msg_id(VL_API_ONE_PITR_SET_LOCATOR_SET, vl_api_one_pitr_set_locator_set_t_handler)
vl_msg_id(VL_API_ONE_PITR_SET_LOCATOR_SET_REPLY, vl_api_one_pitr_set_locator_set_reply_t_handler)
vl_msg_id(VL_API_ONE_USE_PETR, vl_api_one_use_petr_t_handler)
vl_msg_id(VL_API_ONE_USE_PETR_REPLY, vl_api_one_use_petr_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_USE_PETR, vl_api_show_one_use_petr_t_handler)
vl_msg_id(VL_API_SHOW_ONE_USE_PETR_REPLY, vl_api_show_one_use_petr_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_RLOC_PROBE_STATE, vl_api_show_one_rloc_probe_state_t_handler)
vl_msg_id(VL_API_SHOW_ONE_RLOC_PROBE_STATE_REPLY, vl_api_show_one_rloc_probe_state_reply_t_handler)
vl_msg_id(VL_API_ONE_RLOC_PROBE_ENABLE_DISABLE, vl_api_one_rloc_probe_enable_disable_t_handler)
vl_msg_id(VL_API_ONE_RLOC_PROBE_ENABLE_DISABLE_REPLY, vl_api_one_rloc_probe_enable_disable_reply_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_ENABLE_DISABLE, vl_api_one_map_register_enable_disable_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_ENABLE_DISABLE_REPLY, vl_api_one_map_register_enable_disable_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_STATE, vl_api_show_one_map_register_state_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_STATE_REPLY, vl_api_show_one_map_register_state_reply_t_handler)
vl_msg_id(VL_API_ONE_MAP_REQUEST_MODE, vl_api_one_map_request_mode_t_handler)
vl_msg_id(VL_API_ONE_MAP_REQUEST_MODE_REPLY, vl_api_one_map_request_mode_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REQUEST_MODE, vl_api_show_one_map_request_mode_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REQUEST_MODE_REPLY, vl_api_show_one_map_request_mode_reply_t_handler)
/* typeonly: one_remote_locator */
vl_msg_id(VL_API_ONE_ADD_DEL_REMOTE_MAPPING, vl_api_one_add_del_remote_mapping_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_REMOTE_MAPPING_REPLY, vl_api_one_add_del_remote_mapping_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_L2_ARP_ENTRY, vl_api_one_add_del_l2_arp_entry_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_L2_ARP_ENTRY_REPLY, vl_api_one_add_del_l2_arp_entry_reply_t_handler)
vl_msg_id(VL_API_ONE_L2_ARP_ENTRIES_GET, vl_api_one_l2_arp_entries_get_t_handler)
/* typeonly: one_l2_arp_entry */
vl_msg_id(VL_API_ONE_L2_ARP_ENTRIES_GET_REPLY, vl_api_one_l2_arp_entries_get_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_NDP_ENTRY, vl_api_one_add_del_ndp_entry_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_NDP_ENTRY_REPLY, vl_api_one_add_del_ndp_entry_reply_t_handler)
vl_msg_id(VL_API_ONE_NDP_ENTRIES_GET, vl_api_one_ndp_entries_get_t_handler)
/* typeonly: one_ndp_entry */
vl_msg_id(VL_API_ONE_NDP_ENTRIES_GET_REPLY, vl_api_one_ndp_entries_get_reply_t_handler)
vl_msg_id(VL_API_ONE_SET_TRANSPORT_PROTOCOL, vl_api_one_set_transport_protocol_t_handler)
vl_msg_id(VL_API_ONE_SET_TRANSPORT_PROTOCOL_REPLY, vl_api_one_set_transport_protocol_reply_t_handler)
vl_msg_id(VL_API_ONE_GET_TRANSPORT_PROTOCOL, vl_api_one_get_transport_protocol_t_handler)
vl_msg_id(VL_API_ONE_GET_TRANSPORT_PROTOCOL_REPLY, vl_api_one_get_transport_protocol_reply_t_handler)
vl_msg_id(VL_API_ONE_NDP_BD_GET, vl_api_one_ndp_bd_get_t_handler)
vl_msg_id(VL_API_ONE_NDP_BD_GET_REPLY, vl_api_one_ndp_bd_get_reply_t_handler)
vl_msg_id(VL_API_ONE_L2_ARP_BD_GET, vl_api_one_l2_arp_bd_get_t_handler)
vl_msg_id(VL_API_ONE_L2_ARP_BD_GET_REPLY, vl_api_one_l2_arp_bd_get_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_ADJACENCY, vl_api_one_add_del_adjacency_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_ADJACENCY_REPLY, vl_api_one_add_del_adjacency_reply_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_REQUEST_ITR_RLOCS, vl_api_one_add_del_map_request_itr_rlocs_t_handler)
vl_msg_id(VL_API_ONE_ADD_DEL_MAP_REQUEST_ITR_RLOCS_REPLY, vl_api_one_add_del_map_request_itr_rlocs_reply_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_ADD_DEL_MAP, vl_api_one_eid_table_add_del_map_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_ADD_DEL_MAP_REPLY, vl_api_one_eid_table_add_del_map_reply_t_handler)
vl_msg_id(VL_API_ONE_LOCATOR_DUMP, vl_api_one_locator_dump_t_handler)
vl_msg_id(VL_API_ONE_LOCATOR_DETAILS, vl_api_one_locator_details_t_handler)
vl_msg_id(VL_API_ONE_LOCATOR_SET_DETAILS, vl_api_one_locator_set_details_t_handler)
vl_msg_id(VL_API_ONE_LOCATOR_SET_DUMP, vl_api_one_locator_set_dump_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_DETAILS, vl_api_one_eid_table_details_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_DUMP, vl_api_one_eid_table_dump_t_handler)
/* typeonly: one_adjacency */
vl_msg_id(VL_API_ONE_ADJACENCIES_GET_REPLY, vl_api_one_adjacencies_get_reply_t_handler)
vl_msg_id(VL_API_ONE_ADJACENCIES_GET, vl_api_one_adjacencies_get_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_MAP_DETAILS, vl_api_one_eid_table_map_details_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_MAP_DUMP, vl_api_one_eid_table_map_dump_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_VNI_DUMP, vl_api_one_eid_table_vni_dump_t_handler)
vl_msg_id(VL_API_ONE_EID_TABLE_VNI_DETAILS, vl_api_one_eid_table_vni_details_t_handler)
vl_msg_id(VL_API_ONE_MAP_RESOLVER_DETAILS, vl_api_one_map_resolver_details_t_handler)
vl_msg_id(VL_API_ONE_MAP_RESOLVER_DUMP, vl_api_one_map_resolver_dump_t_handler)
vl_msg_id(VL_API_ONE_MAP_SERVER_DETAILS, vl_api_one_map_server_details_t_handler)
vl_msg_id(VL_API_ONE_MAP_SERVER_DUMP, vl_api_one_map_server_dump_t_handler)
vl_msg_id(VL_API_SHOW_ONE_STATUS, vl_api_show_one_status_t_handler)
vl_msg_id(VL_API_SHOW_ONE_STATUS_REPLY, vl_api_show_one_status_reply_t_handler)
vl_msg_id(VL_API_ONE_GET_MAP_REQUEST_ITR_RLOCS, vl_api_one_get_map_request_itr_rlocs_t_handler)
vl_msg_id(VL_API_ONE_GET_MAP_REQUEST_ITR_RLOCS_REPLY, vl_api_one_get_map_request_itr_rlocs_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_NSH_MAPPING, vl_api_show_one_nsh_mapping_t_handler)
vl_msg_id(VL_API_SHOW_ONE_NSH_MAPPING_REPLY, vl_api_show_one_nsh_mapping_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_PITR, vl_api_show_one_pitr_t_handler)
vl_msg_id(VL_API_SHOW_ONE_PITR_REPLY, vl_api_show_one_pitr_reply_t_handler)
vl_msg_id(VL_API_ONE_STATS_DUMP, vl_api_one_stats_dump_t_handler)
vl_msg_id(VL_API_ONE_STATS_DETAILS, vl_api_one_stats_details_t_handler)
vl_msg_id(VL_API_ONE_STATS_FLUSH, vl_api_one_stats_flush_t_handler)
vl_msg_id(VL_API_ONE_STATS_FLUSH_REPLY, vl_api_one_stats_flush_reply_t_handler)
vl_msg_id(VL_API_ONE_STATS_ENABLE_DISABLE, vl_api_one_stats_enable_disable_t_handler)
vl_msg_id(VL_API_ONE_STATS_ENABLE_DISABLE_REPLY, vl_api_one_stats_enable_disable_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_STATS_ENABLE_DISABLE, vl_api_show_one_stats_enable_disable_t_handler)
vl_msg_id(VL_API_SHOW_ONE_STATS_ENABLE_DISABLE_REPLY, vl_api_show_one_stats_enable_disable_reply_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_FALLBACK_THRESHOLD, vl_api_one_map_register_fallback_threshold_t_handler)
vl_msg_id(VL_API_ONE_MAP_REGISTER_FALLBACK_THRESHOLD_REPLY, vl_api_one_map_register_fallback_threshold_reply_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_FALLBACK_THRESHOLD, vl_api_show_one_map_register_fallback_threshold_t_handler)
vl_msg_id(VL_API_SHOW_ONE_MAP_REGISTER_FALLBACK_THRESHOLD_REPLY, vl_api_show_one_map_register_fallback_threshold_reply_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_XTR_MODE, vl_api_one_enable_disable_xtr_mode_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_XTR_MODE_REPLY, vl_api_one_enable_disable_xtr_mode_reply_t_handler)
vl_msg_id(VL_API_ONE_SHOW_XTR_MODE, vl_api_one_show_xtr_mode_t_handler)
vl_msg_id(VL_API_ONE_SHOW_XTR_MODE_REPLY, vl_api_one_show_xtr_mode_reply_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_PETR_MODE, vl_api_one_enable_disable_petr_mode_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_PETR_MODE_REPLY, vl_api_one_enable_disable_petr_mode_reply_t_handler)
vl_msg_id(VL_API_ONE_SHOW_PETR_MODE, vl_api_one_show_petr_mode_t_handler)
vl_msg_id(VL_API_ONE_SHOW_PETR_MODE_REPLY, vl_api_one_show_petr_mode_reply_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_PITR_MODE, vl_api_one_enable_disable_pitr_mode_t_handler)
vl_msg_id(VL_API_ONE_ENABLE_DISABLE_PITR_MODE_REPLY, vl_api_one_enable_disable_pitr_mode_reply_t_handler)
vl_msg_id(VL_API_ONE_SHOW_PITR_MODE, vl_api_one_show_pitr_mode_t_handler)
vl_msg_id(VL_API_ONE_SHOW_PITR_MODE_REPLY, vl_api_one_show_pitr_mode_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
/* typeonly: one_local_locator */
vl_msg_name(vl_api_one_add_del_locator_set_t, 1)
vl_msg_name(vl_api_one_add_del_locator_set_reply_t, 1)
vl_msg_name(vl_api_one_add_del_locator_t, 1)
vl_msg_name(vl_api_one_add_del_locator_reply_t, 1)
vl_msg_name(vl_api_one_add_del_local_eid_t, 1)
vl_msg_name(vl_api_one_add_del_local_eid_reply_t, 1)
vl_msg_name(vl_api_one_map_register_set_ttl_t, 1)
vl_msg_name(vl_api_one_map_register_set_ttl_reply_t, 1)
vl_msg_name(vl_api_show_one_map_register_ttl_t, 1)
vl_msg_name(vl_api_show_one_map_register_ttl_reply_t, 1)
vl_msg_name(vl_api_one_add_del_map_server_t, 1)
vl_msg_name(vl_api_one_add_del_map_server_reply_t, 1)
vl_msg_name(vl_api_one_add_del_map_resolver_t, 1)
vl_msg_name(vl_api_one_add_del_map_resolver_reply_t, 1)
vl_msg_name(vl_api_one_enable_disable_t, 1)
vl_msg_name(vl_api_one_enable_disable_reply_t, 1)
vl_msg_name(vl_api_one_nsh_set_locator_set_t, 1)
vl_msg_name(vl_api_one_nsh_set_locator_set_reply_t, 1)
vl_msg_name(vl_api_one_pitr_set_locator_set_t, 1)
vl_msg_name(vl_api_one_pitr_set_locator_set_reply_t, 1)
vl_msg_name(vl_api_one_use_petr_t, 1)
vl_msg_name(vl_api_one_use_petr_reply_t, 1)
vl_msg_name(vl_api_show_one_use_petr_t, 1)
vl_msg_name(vl_api_show_one_use_petr_reply_t, 1)
vl_msg_name(vl_api_show_one_rloc_probe_state_t, 1)
vl_msg_name(vl_api_show_one_rloc_probe_state_reply_t, 1)
vl_msg_name(vl_api_one_rloc_probe_enable_disable_t, 1)
vl_msg_name(vl_api_one_rloc_probe_enable_disable_reply_t, 1)
vl_msg_name(vl_api_one_map_register_enable_disable_t, 1)
vl_msg_name(vl_api_one_map_register_enable_disable_reply_t, 1)
vl_msg_name(vl_api_show_one_map_register_state_t, 1)
vl_msg_name(vl_api_show_one_map_register_state_reply_t, 1)
vl_msg_name(vl_api_one_map_request_mode_t, 1)
vl_msg_name(vl_api_one_map_request_mode_reply_t, 1)
vl_msg_name(vl_api_show_one_map_request_mode_t, 1)
vl_msg_name(vl_api_show_one_map_request_mode_reply_t, 1)
/* typeonly: one_remote_locator */
vl_msg_name(vl_api_one_add_del_remote_mapping_t, 1)
vl_msg_name(vl_api_one_add_del_remote_mapping_reply_t, 1)
vl_msg_name(vl_api_one_add_del_l2_arp_entry_t, 1)
vl_msg_name(vl_api_one_add_del_l2_arp_entry_reply_t, 1)
vl_msg_name(vl_api_one_l2_arp_entries_get_t, 1)
/* typeonly: one_l2_arp_entry */
vl_msg_name(vl_api_one_l2_arp_entries_get_reply_t, 1)
vl_msg_name(vl_api_one_add_del_ndp_entry_t, 1)
vl_msg_name(vl_api_one_add_del_ndp_entry_reply_t, 1)
vl_msg_name(vl_api_one_ndp_entries_get_t, 1)
/* typeonly: one_ndp_entry */
vl_msg_name(vl_api_one_ndp_entries_get_reply_t, 1)
vl_msg_name(vl_api_one_set_transport_protocol_t, 1)
vl_msg_name(vl_api_one_set_transport_protocol_reply_t, 1)
vl_msg_name(vl_api_one_get_transport_protocol_t, 1)
vl_msg_name(vl_api_one_get_transport_protocol_reply_t, 1)
vl_msg_name(vl_api_one_ndp_bd_get_t, 1)
vl_msg_name(vl_api_one_ndp_bd_get_reply_t, 1)
vl_msg_name(vl_api_one_l2_arp_bd_get_t, 1)
vl_msg_name(vl_api_one_l2_arp_bd_get_reply_t, 1)
vl_msg_name(vl_api_one_add_del_adjacency_t, 1)
vl_msg_name(vl_api_one_add_del_adjacency_reply_t, 1)
vl_msg_name(vl_api_one_add_del_map_request_itr_rlocs_t, 1)
vl_msg_name(vl_api_one_add_del_map_request_itr_rlocs_reply_t, 1)
vl_msg_name(vl_api_one_eid_table_add_del_map_t, 1)
vl_msg_name(vl_api_one_eid_table_add_del_map_reply_t, 1)
vl_msg_name(vl_api_one_locator_dump_t, 1)
vl_msg_name(vl_api_one_locator_details_t, 1)
vl_msg_name(vl_api_one_locator_set_details_t, 1)
vl_msg_name(vl_api_one_locator_set_dump_t, 1)
vl_msg_name(vl_api_one_eid_table_details_t, 1)
vl_msg_name(vl_api_one_eid_table_dump_t, 1)
/* typeonly: one_adjacency */
vl_msg_name(vl_api_one_adjacencies_get_reply_t, 1)
vl_msg_name(vl_api_one_adjacencies_get_t, 1)
vl_msg_name(vl_api_one_eid_table_map_details_t, 1)
vl_msg_name(vl_api_one_eid_table_map_dump_t, 1)
vl_msg_name(vl_api_one_eid_table_vni_dump_t, 1)
vl_msg_name(vl_api_one_eid_table_vni_details_t, 1)
vl_msg_name(vl_api_one_map_resolver_details_t, 1)
vl_msg_name(vl_api_one_map_resolver_dump_t, 1)
vl_msg_name(vl_api_one_map_server_details_t, 1)
vl_msg_name(vl_api_one_map_server_dump_t, 1)
vl_msg_name(vl_api_show_one_status_t, 1)
vl_msg_name(vl_api_show_one_status_reply_t, 1)
vl_msg_name(vl_api_one_get_map_request_itr_rlocs_t, 1)
vl_msg_name(vl_api_one_get_map_request_itr_rlocs_reply_t, 1)
vl_msg_name(vl_api_show_one_nsh_mapping_t, 1)
vl_msg_name(vl_api_show_one_nsh_mapping_reply_t, 1)
vl_msg_name(vl_api_show_one_pitr_t, 1)
vl_msg_name(vl_api_show_one_pitr_reply_t, 1)
vl_msg_name(vl_api_one_stats_dump_t, 1)
vl_msg_name(vl_api_one_stats_details_t, 1)
vl_msg_name(vl_api_one_stats_flush_t, 1)
vl_msg_name(vl_api_one_stats_flush_reply_t, 1)
vl_msg_name(vl_api_one_stats_enable_disable_t, 1)
vl_msg_name(vl_api_one_stats_enable_disable_reply_t, 1)
vl_msg_name(vl_api_show_one_stats_enable_disable_t, 1)
vl_msg_name(vl_api_show_one_stats_enable_disable_reply_t, 1)
vl_msg_name(vl_api_one_map_register_fallback_threshold_t, 1)
vl_msg_name(vl_api_one_map_register_fallback_threshold_reply_t, 1)
vl_msg_name(vl_api_show_one_map_register_fallback_threshold_t, 1)
vl_msg_name(vl_api_show_one_map_register_fallback_threshold_reply_t, 1)
vl_msg_name(vl_api_one_enable_disable_xtr_mode_t, 1)
vl_msg_name(vl_api_one_enable_disable_xtr_mode_reply_t, 1)
vl_msg_name(vl_api_one_show_xtr_mode_t, 1)
vl_msg_name(vl_api_one_show_xtr_mode_reply_t, 1)
vl_msg_name(vl_api_one_enable_disable_petr_mode_t, 1)
vl_msg_name(vl_api_one_enable_disable_petr_mode_reply_t, 1)
vl_msg_name(vl_api_one_show_petr_mode_t, 1)
vl_msg_name(vl_api_one_show_petr_mode_reply_t, 1)
vl_msg_name(vl_api_one_enable_disable_pitr_mode_t, 1)
vl_msg_name(vl_api_one_enable_disable_pitr_mode_reply_t, 1)
vl_msg_name(vl_api_one_show_pitr_mode_t, 1)
vl_msg_name(vl_api_one_show_pitr_mode_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_one \
_(VL_API_ONE_ADD_DEL_LOCATOR_SET, one_add_del_locator_set, 57cc6026) \
_(VL_API_ONE_ADD_DEL_LOCATOR_SET_REPLY, one_add_del_locator_set_reply, c6af12ec) \
_(VL_API_ONE_ADD_DEL_LOCATOR, one_add_del_locator, fc816f2d) \
_(VL_API_ONE_ADD_DEL_LOCATOR_REPLY, one_add_del_locator_reply, 72b93e34) \
_(VL_API_ONE_ADD_DEL_LOCAL_EID, one_add_del_local_eid, 9fa2e1b7) \
_(VL_API_ONE_ADD_DEL_LOCAL_EID_REPLY, one_add_del_local_eid_reply, b0e4330b) \
_(VL_API_ONE_MAP_REGISTER_SET_TTL, one_map_register_set_ttl, aa9edc77) \
_(VL_API_ONE_MAP_REGISTER_SET_TTL_REPLY, one_map_register_set_ttl_reply, f62b964e) \
_(VL_API_SHOW_ONE_MAP_REGISTER_TTL, show_one_map_register_ttl, 275be0f7) \
_(VL_API_SHOW_ONE_MAP_REGISTER_TTL_REPLY, show_one_map_register_ttl_reply, 17837136) \
_(VL_API_ONE_ADD_DEL_MAP_SERVER, one_add_del_map_server, 731cfa38) \
_(VL_API_ONE_ADD_DEL_MAP_SERVER_REPLY, one_add_del_map_server_reply, ce8d6a33) \
_(VL_API_ONE_ADD_DEL_MAP_RESOLVER, one_add_del_map_resolver, a627ab50) \
_(VL_API_ONE_ADD_DEL_MAP_RESOLVER_REPLY, one_add_del_map_resolver_reply, e46fb226) \
_(VL_API_ONE_ENABLE_DISABLE, one_enable_disable, 3486b168) \
_(VL_API_ONE_ENABLE_DISABLE_REPLY, one_enable_disable_reply, 000bda40) \
_(VL_API_ONE_NSH_SET_LOCATOR_SET, one_nsh_set_locator_set, 70487f3b) \
_(VL_API_ONE_NSH_SET_LOCATOR_SET_REPLY, one_nsh_set_locator_set_reply, 58606afb) \
_(VL_API_ONE_PITR_SET_LOCATOR_SET, one_pitr_set_locator_set, 4b46f7e0) \
_(VL_API_ONE_PITR_SET_LOCATOR_SET_REPLY, one_pitr_set_locator_set_reply, 78fb5604) \
_(VL_API_ONE_USE_PETR, one_use_petr, 5d87b0c3) \
_(VL_API_ONE_USE_PETR_REPLY, one_use_petr_reply, 20d789f4) \
_(VL_API_SHOW_ONE_USE_PETR, show_one_use_petr, 762fcd06) \
_(VL_API_SHOW_ONE_USE_PETR_REPLY, show_one_use_petr_reply, df47b6f3) \
_(VL_API_SHOW_ONE_RLOC_PROBE_STATE, show_one_rloc_probe_state, c9274fad) \
_(VL_API_SHOW_ONE_RLOC_PROBE_STATE_REPLY, show_one_rloc_probe_state_reply, 0bb0ebf4) \
_(VL_API_ONE_RLOC_PROBE_ENABLE_DISABLE, one_rloc_probe_enable_disable, 6072518f) \
_(VL_API_ONE_RLOC_PROBE_ENABLE_DISABLE_REPLY, one_rloc_probe_enable_disable_reply, bdfc3a16) \
_(VL_API_ONE_MAP_REGISTER_ENABLE_DISABLE, one_map_register_enable_disable, 14b0953c) \
_(VL_API_ONE_MAP_REGISTER_ENABLE_DISABLE_REPLY, one_map_register_enable_disable_reply, 161e60df) \
_(VL_API_SHOW_ONE_MAP_REGISTER_STATE, show_one_map_register_state, afbe60cb) \
_(VL_API_SHOW_ONE_MAP_REGISTER_STATE_REPLY, show_one_map_register_state_reply, d2d76c22) \
_(VL_API_ONE_MAP_REQUEST_MODE, one_map_request_mode, 67508836) \
_(VL_API_ONE_MAP_REQUEST_MODE_REPLY, one_map_request_mode_reply, 25f76bca) \
_(VL_API_SHOW_ONE_MAP_REQUEST_MODE, show_one_map_request_mode, d3ef6eac) \
_(VL_API_SHOW_ONE_MAP_REQUEST_MODE_REPLY, show_one_map_request_mode_reply, f3c29518) \
_(VL_API_ONE_ADD_DEL_REMOTE_MAPPING, one_add_del_remote_mapping, 02550000) \
_(VL_API_ONE_ADD_DEL_REMOTE_MAPPING_REPLY, one_add_del_remote_mapping_reply, e23807e0) \
_(VL_API_ONE_ADD_DEL_L2_ARP_ENTRY, one_add_del_l2_arp_entry, 60c76a18) \
_(VL_API_ONE_ADD_DEL_L2_ARP_ENTRY_REPLY, one_add_del_l2_arp_entry_reply, ddcfb571) \
_(VL_API_ONE_L2_ARP_ENTRIES_GET, one_l2_arp_entries_get, a1d3eb74) \
_(VL_API_ONE_L2_ARP_ENTRIES_GET_REPLY, one_l2_arp_entries_get_reply, 45c91753) \
_(VL_API_ONE_ADD_DEL_NDP_ENTRY, one_add_del_ndp_entry, 601086d0) \
_(VL_API_ONE_ADD_DEL_NDP_ENTRY_REPLY, one_add_del_ndp_entry_reply, c2ced457) \
_(VL_API_ONE_NDP_ENTRIES_GET, one_ndp_entries_get, ac304878) \
_(VL_API_ONE_NDP_ENTRIES_GET_REPLY, one_ndp_entries_get_reply, 5acc96d0) \
_(VL_API_ONE_SET_TRANSPORT_PROTOCOL, one_set_transport_protocol, a96195a5) \
_(VL_API_ONE_SET_TRANSPORT_PROTOCOL_REPLY, one_set_transport_protocol_reply, aa26992f) \
_(VL_API_ONE_GET_TRANSPORT_PROTOCOL, one_get_transport_protocol, 84845d3e) \
_(VL_API_ONE_GET_TRANSPORT_PROTOCOL_REPLY, one_get_transport_protocol_reply, d537d3b2) \
_(VL_API_ONE_NDP_BD_GET, one_ndp_bd_get, 8c23a347) \
_(VL_API_ONE_NDP_BD_GET_REPLY, one_ndp_bd_get_reply, a36b1ed0) \
_(VL_API_ONE_L2_ARP_BD_GET, one_l2_arp_bd_get, b37527e1) \
_(VL_API_ONE_L2_ARP_BD_GET_REPLY, one_l2_arp_bd_get_reply, 63372c9c) \
_(VL_API_ONE_ADD_DEL_ADJACENCY, one_add_del_adjacency, ebba0b82) \
_(VL_API_ONE_ADD_DEL_ADJACENCY_REPLY, one_add_del_adjacency_reply, 224ad6d3) \
_(VL_API_ONE_ADD_DEL_MAP_REQUEST_ITR_RLOCS, one_add_del_map_request_itr_rlocs, 11184601) \
_(VL_API_ONE_ADD_DEL_MAP_REQUEST_ITR_RLOCS_REPLY, one_add_del_map_request_itr_rlocs_reply, ba0b92e3) \
_(VL_API_ONE_EID_TABLE_ADD_DEL_MAP, one_eid_table_add_del_map, e2ae3961) \
_(VL_API_ONE_EID_TABLE_ADD_DEL_MAP_REPLY, one_eid_table_add_del_map_reply, 798662b9) \
_(VL_API_ONE_LOCATOR_DUMP, one_locator_dump, 9ba86482) \
_(VL_API_ONE_LOCATOR_DETAILS, one_locator_details, 46aff68e) \
_(VL_API_ONE_LOCATOR_SET_DETAILS, one_locator_set_details, 4d7a0c92) \
_(VL_API_ONE_LOCATOR_SET_DUMP, one_locator_set_dump, 3dff8c66) \
_(VL_API_ONE_EID_TABLE_DETAILS, one_eid_table_details, c059f5a4) \
_(VL_API_ONE_EID_TABLE_DUMP, one_eid_table_dump, ab7f0498) \
_(VL_API_ONE_ADJACENCIES_GET_REPLY, one_adjacencies_get_reply, 73a0a09b) \
_(VL_API_ONE_ADJACENCIES_GET, one_adjacencies_get, a884eff5) \
_(VL_API_ONE_EID_TABLE_MAP_DETAILS, one_eid_table_map_details, efdce03b) \
_(VL_API_ONE_EID_TABLE_MAP_DUMP, one_eid_table_map_dump, 3f898ffc) \
_(VL_API_ONE_EID_TABLE_VNI_DUMP, one_eid_table_vni_dump, dc237d6b) \
_(VL_API_ONE_EID_TABLE_VNI_DETAILS, one_eid_table_vni_details, 29d7a2ee) \
_(VL_API_ONE_MAP_RESOLVER_DETAILS, one_map_resolver_details, b1223d87) \
_(VL_API_ONE_MAP_RESOLVER_DUMP, one_map_resolver_dump, 2a3c1778) \
_(VL_API_ONE_MAP_SERVER_DETAILS, one_map_server_details, 493b5607) \
_(VL_API_ONE_MAP_SERVER_DUMP, one_map_server_dump, d05edf96) \
_(VL_API_SHOW_ONE_STATUS, show_one_status, 34b8c69d) \
_(VL_API_SHOW_ONE_STATUS_REPLY, show_one_status_reply, e0f96f92) \
_(VL_API_ONE_GET_MAP_REQUEST_ITR_RLOCS, one_get_map_request_itr_rlocs, 34014276) \
_(VL_API_ONE_GET_MAP_REQUEST_ITR_RLOCS_REPLY, one_get_map_request_itr_rlocs_reply, d45b9cde) \
_(VL_API_SHOW_ONE_NSH_MAPPING, show_one_nsh_mapping, 10083094) \
_(VL_API_SHOW_ONE_NSH_MAPPING_REPLY, show_one_nsh_mapping_reply, 4bce982f) \
_(VL_API_SHOW_ONE_PITR, show_one_pitr, 110fb2d5) \
_(VL_API_SHOW_ONE_PITR_REPLY, show_one_pitr_reply, d60a3bf4) \
_(VL_API_ONE_STATS_DUMP, one_stats_dump, 8c9b17a1) \
_(VL_API_ONE_STATS_DETAILS, one_stats_details, 759f7b5d) \
_(VL_API_ONE_STATS_FLUSH, one_stats_flush, 8472634b) \
_(VL_API_ONE_STATS_FLUSH_REPLY, one_stats_flush_reply, c08bb290) \
_(VL_API_ONE_STATS_ENABLE_DISABLE, one_stats_enable_disable, 5586aa83) \
_(VL_API_ONE_STATS_ENABLE_DISABLE_REPLY, one_stats_enable_disable_reply, 1c5d305c) \
_(VL_API_SHOW_ONE_STATS_ENABLE_DISABLE, show_one_stats_enable_disable, fd8b1e1f) \
_(VL_API_SHOW_ONE_STATS_ENABLE_DISABLE_REPLY, show_one_stats_enable_disable_reply, 7f197887) \
_(VL_API_ONE_MAP_REGISTER_FALLBACK_THRESHOLD, one_map_register_fallback_threshold, c9ea793a) \
_(VL_API_ONE_MAP_REGISTER_FALLBACK_THRESHOLD_REPLY, one_map_register_fallback_threshold_reply, 929bb0fc) \
_(VL_API_SHOW_ONE_MAP_REGISTER_FALLBACK_THRESHOLD, show_one_map_register_fallback_threshold, ed361e58) \
_(VL_API_SHOW_ONE_MAP_REGISTER_FALLBACK_THRESHOLD_REPLY, show_one_map_register_fallback_threshold_reply, d2294e16) \
_(VL_API_ONE_ENABLE_DISABLE_XTR_MODE, one_enable_disable_xtr_mode, 90dba949) \
_(VL_API_ONE_ENABLE_DISABLE_XTR_MODE_REPLY, one_enable_disable_xtr_mode_reply, 30d58736) \
_(VL_API_ONE_SHOW_XTR_MODE, one_show_xtr_mode, 87465117) \
_(VL_API_ONE_SHOW_XTR_MODE_REPLY, one_show_xtr_mode_reply, 996998bc) \
_(VL_API_ONE_ENABLE_DISABLE_PETR_MODE, one_enable_disable_petr_mode, 23fa5da9) \
_(VL_API_ONE_ENABLE_DISABLE_PETR_MODE_REPLY, one_enable_disable_petr_mode_reply, ba4230a7) \
_(VL_API_ONE_SHOW_PETR_MODE, one_show_petr_mode, 66c4cc36) \
_(VL_API_ONE_SHOW_PETR_MODE_REPLY, one_show_petr_mode_reply, 408dcbc7) \
_(VL_API_ONE_ENABLE_DISABLE_PITR_MODE, one_enable_disable_pitr_mode, 88b36a86) \
_(VL_API_ONE_ENABLE_DISABLE_PITR_MODE_REPLY, one_enable_disable_pitr_mode_reply, 7d9ef44d) \
_(VL_API_ONE_SHOW_PITR_MODE, one_show_pitr_mode, a11808dc) \
_(VL_API_ONE_SHOW_PITR_MODE_REPLY, one_show_pitr_mode_reply, ebc4fce8) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_one_local_locator {
    u32 sw_if_index;
    u8 priority;
    u8 weight;
}) vl_api_one_local_locator_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 locator_num;
    vl_api_one_local_locator_t locators[0];
}) vl_api_one_add_del_locator_set_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ls_index;
}) vl_api_one_add_del_locator_set_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_locator {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
    u32 sw_if_index;
    u8 priority;
    u8 weight;
}) vl_api_one_add_del_locator_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_locator_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_locator_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_local_eid {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 eid_type;
    u8 eid[16];
    u8 prefix_len;
    u8 locator_set_name[64];
    u32 vni;
    u16 key_id;
    u8 key[64];
}) vl_api_one_add_del_local_eid_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_local_eid_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_local_eid_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_set_ttl {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ttl;
}) vl_api_one_map_register_set_ttl_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_set_ttl_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_map_register_set_ttl_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_ttl {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_map_register_ttl_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_ttl_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 ttl;
}) vl_api_show_one_map_register_ttl_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_server {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_one_add_del_map_server_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_server_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_map_server_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_resolver {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_one_add_del_map_resolver_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_resolver_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_map_resolver_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_one_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_nsh_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
}) vl_api_one_nsh_set_locator_set_t;

typedef VL_API_PACKED(struct _vl_api_one_nsh_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_nsh_set_locator_set_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_pitr_set_locator_set {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 ls_name[64];
}) vl_api_one_pitr_set_locator_set_t;

typedef VL_API_PACKED(struct _vl_api_one_pitr_set_locator_set_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_pitr_set_locator_set_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 address[16];
    u8 is_add;
}) vl_api_one_use_petr_t;

typedef VL_API_PACKED(struct _vl_api_one_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_use_petr_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_use_petr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_use_petr_t;

typedef VL_API_PACKED(struct _vl_api_show_one_use_petr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 is_ip4;
    u8 address[16];
}) vl_api_show_one_use_petr_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_rloc_probe_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_rloc_probe_state_t;

typedef VL_API_PACKED(struct _vl_api_show_one_rloc_probe_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
}) vl_api_show_one_rloc_probe_state_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_rloc_probe_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
}) vl_api_one_rloc_probe_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_one_rloc_probe_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_rloc_probe_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_enabled;
}) vl_api_one_map_register_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_map_register_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_state {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_map_register_state_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_state_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_enabled;
}) vl_api_show_one_map_register_state_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 mode;
}) vl_api_one_map_request_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_map_request_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_request_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_map_request_mode_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_request_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 mode;
}) vl_api_show_one_map_request_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_remote_locator {
    u8 is_ip4;
    u8 priority;
    u8 weight;
    u8 addr[16];
}) vl_api_one_remote_locator_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_remote_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_src_dst;
    u8 del_all;
    u32 vni;
    u8 action;
    u8 eid_type;
    u8 eid[16];
    u8 eid_len;
    u8 seid[16];
    u8 seid_len;
    u32 rloc_num;
    vl_api_one_remote_locator_t rlocs[0];
}) vl_api_one_add_del_remote_mapping_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_remote_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_remote_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_l2_arp_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 mac[6];
    u32 bd;
    u32 ip4;
}) vl_api_one_add_del_l2_arp_entry_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_l2_arp_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_l2_arp_entry_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_l2_arp_entries_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd;
}) vl_api_one_l2_arp_entries_get_t;

typedef VL_API_PACKED(struct _vl_api_one_l2_arp_entry {
    u8 mac[6];
    u32 ip4;
}) vl_api_one_l2_arp_entry_t;

typedef VL_API_PACKED(struct _vl_api_one_l2_arp_entries_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_l2_arp_entry_t entries[0];
}) vl_api_one_l2_arp_entries_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_ndp_entry {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 mac[6];
    u32 bd;
    u8 ip6[16];
}) vl_api_one_add_del_ndp_entry_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_ndp_entry_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_ndp_entry_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_ndp_entries_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 bd;
}) vl_api_one_ndp_entries_get_t;

typedef VL_API_PACKED(struct _vl_api_one_ndp_entry {
    u8 mac[6];
    u8 ip6[16];
}) vl_api_one_ndp_entry_t;

typedef VL_API_PACKED(struct _vl_api_one_ndp_entries_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_ndp_entry_t entries[0];
}) vl_api_one_ndp_entries_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_set_transport_protocol {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 protocol;
}) vl_api_one_set_transport_protocol_t;

typedef VL_API_PACKED(struct _vl_api_one_set_transport_protocol_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_set_transport_protocol_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_get_transport_protocol {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_get_transport_protocol_t;

typedef VL_API_PACKED(struct _vl_api_one_get_transport_protocol_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 protocol;
}) vl_api_one_get_transport_protocol_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_ndp_bd_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_ndp_bd_get_t;

typedef VL_API_PACKED(struct _vl_api_one_ndp_bd_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 bridge_domains[0];
}) vl_api_one_ndp_bd_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_l2_arp_bd_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_l2_arp_bd_get_t;

typedef VL_API_PACKED(struct _vl_api_one_l2_arp_bd_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    u32 bridge_domains[0];
}) vl_api_one_l2_arp_bd_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_adjacency {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_len;
    u8 leid_len;
}) vl_api_one_add_del_adjacency_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_adjacency_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_adjacency_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 locator_set_name[64];
}) vl_api_one_add_del_map_request_itr_rlocs_t;

typedef VL_API_PACKED(struct _vl_api_one_add_del_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_add_del_map_request_itr_rlocs_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_add_del_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 vni;
    u32 dp_table;
    u8 is_l2;
}) vl_api_one_eid_table_add_del_map_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_add_del_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_eid_table_add_del_map_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_locator_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
    u8 is_index_set;
}) vl_api_one_locator_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_locator_details {
    u16 _vl_msg_id;
    u32 context;
    u8 local;
    u32 sw_if_index;
    u8 is_ipv6;
    u8 ip_address[16];
    u8 priority;
    u8 weight;
}) vl_api_one_locator_details_t;

typedef VL_API_PACKED(struct _vl_api_one_locator_set_details {
    u16 _vl_msg_id;
    u32 context;
    u32 ls_index;
    u8 ls_name[64];
}) vl_api_one_locator_set_details_t;

typedef VL_API_PACKED(struct _vl_api_one_locator_set_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 filter;
}) vl_api_one_locator_set_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_details {
    u16 _vl_msg_id;
    u32 context;
    u32 locator_set_index;
    u8 action;
    u8 is_local;
    u8 eid_type;
    u8 is_src_dst;
    u32 vni;
    u8 eid[16];
    u8 eid_prefix_len;
    u8 seid[16];
    u8 seid_prefix_len;
    u32 ttl;
    u8 authoritative;
    u16 key_id;
    u8 key[64];
}) vl_api_one_eid_table_details_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 eid_set;
    u8 prefix_length;
    u32 vni;
    u8 eid_type;
    u8 eid[16];
    u8 filter;
}) vl_api_one_eid_table_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_adjacency {
    u8 eid_type;
    u8 reid[16];
    u8 leid[16];
    u8 reid_prefix_len;
    u8 leid_prefix_len;
}) vl_api_one_adjacency_t;

typedef VL_API_PACKED(struct _vl_api_one_adjacencies_get_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 count;
    vl_api_one_adjacency_t adjacencies[0];
}) vl_api_one_adjacencies_get_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_adjacencies_get {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
}) vl_api_one_adjacencies_get_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_map_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u32 dp_table;
}) vl_api_one_eid_table_map_details_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_l2;
}) vl_api_one_eid_table_map_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_vni_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_eid_table_vni_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_eid_table_vni_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 vni;
}) vl_api_one_eid_table_vni_details_t;

typedef VL_API_PACKED(struct _vl_api_one_map_resolver_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_one_map_resolver_details_t;

typedef VL_API_PACKED(struct _vl_api_one_map_resolver_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_map_resolver_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_map_server_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ipv6;
    u8 ip_address[16];
}) vl_api_one_map_server_details_t;

typedef VL_API_PACKED(struct _vl_api_one_map_server_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_map_server_dump_t;

typedef VL_API_PACKED(struct _vl_api_show_one_status {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_status_t;

typedef VL_API_PACKED(struct _vl_api_show_one_status_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 feature_status;
    u8 gpe_status;
}) vl_api_show_one_status_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_get_map_request_itr_rlocs {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_get_map_request_itr_rlocs_t;

typedef VL_API_PACKED(struct _vl_api_one_get_map_request_itr_rlocs_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 locator_set_name[64];
}) vl_api_one_get_map_request_itr_rlocs_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_nsh_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_nsh_mapping_t;

typedef VL_API_PACKED(struct _vl_api_show_one_nsh_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_set;
    u8 locator_set_name[64];
}) vl_api_show_one_nsh_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_pitr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_pitr_t;

typedef VL_API_PACKED(struct _vl_api_show_one_pitr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 status;
    u8 locator_set_name[64];
}) vl_api_show_one_pitr_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_stats_dump_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vni;
    u8 eid_type;
    u8 deid[16];
    u8 seid[16];
    u8 deid_pref_len;
    u8 seid_pref_len;
    u8 is_ip4;
    u8 rloc[16];
    u8 lloc[16];
    u32 pkt_count;
    u32 bytes;
}) vl_api_one_stats_details_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_flush {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_stats_flush_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_flush_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_stats_flush_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_one_stats_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_one_stats_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_stats_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_stats_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_stats_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_show_one_stats_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
}) vl_api_show_one_stats_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_fallback_threshold {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 value;
}) vl_api_one_map_register_fallback_threshold_t;

typedef VL_API_PACKED(struct _vl_api_one_map_register_fallback_threshold_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_map_register_fallback_threshold_reply_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_fallback_threshold {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_show_one_map_register_fallback_threshold_t;

typedef VL_API_PACKED(struct _vl_api_show_one_map_register_fallback_threshold_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 value;
}) vl_api_show_one_map_register_fallback_threshold_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_xtr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_one_enable_disable_xtr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_xtr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_enable_disable_xtr_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_show_xtr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_show_xtr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_show_xtr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
}) vl_api_one_show_xtr_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_petr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_one_enable_disable_petr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_petr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_enable_disable_petr_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_show_petr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_show_petr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_show_petr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
}) vl_api_one_show_petr_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_pitr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_en;
}) vl_api_one_enable_disable_pitr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_enable_disable_pitr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_one_enable_disable_pitr_mode_reply_t;

typedef VL_API_PACKED(struct _vl_api_one_show_pitr_mode {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_one_show_pitr_mode_t;

typedef VL_API_PACKED(struct _vl_api_one_show_pitr_mode_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_en;
}) vl_api_one_show_pitr_mode_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

/***** manual: vl_api_one_local_locator_t_print  *****/

/***** manual: vl_api_one_add_del_locator_set_t_print  *****/

static inline void *vl_api_one_add_del_locator_set_reply_t_print (vl_api_one_add_del_locator_set_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_locator_set_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    return handle;
}

static inline void *vl_api_one_add_del_locator_t_print (vl_api_one_add_del_locator_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_locator_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "priority: %u\n", (unsigned) a->priority);
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    return handle;
}

static inline void *vl_api_one_add_del_locator_reply_t_print (vl_api_one_add_del_locator_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_locator_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_add_del_local_eid_t_print (vl_api_one_add_del_local_eid_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_local_eid_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "prefix_len: %u\n", (unsigned) a->prefix_len);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "key_id: %u\n", (unsigned) a->key_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "key[%d]: %u\n", _i, a->key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_add_del_local_eid_reply_t_print (vl_api_one_add_del_local_eid_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_local_eid_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_map_register_set_ttl_t_print (vl_api_one_map_register_set_ttl_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_set_ttl_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ttl: %u\n", (unsigned) a->ttl);
    return handle;
}

static inline void *vl_api_one_map_register_set_ttl_reply_t_print (vl_api_one_map_register_set_ttl_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_set_ttl_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_map_register_ttl_t_print (vl_api_show_one_map_register_ttl_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_ttl_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_map_register_ttl_reply_t_print (vl_api_show_one_map_register_ttl_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_ttl_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "ttl: %u\n", (unsigned) a->ttl);
    return handle;
}

static inline void *vl_api_one_add_del_map_server_t_print (vl_api_one_add_del_map_server_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_server_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_add_del_map_server_reply_t_print (vl_api_one_add_del_map_server_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_server_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_add_del_map_resolver_t_print (vl_api_one_add_del_map_resolver_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_resolver_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_add_del_map_resolver_reply_t_print (vl_api_one_add_del_map_resolver_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_resolver_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_enable_disable_t_print (vl_api_one_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_reply_t_print (vl_api_one_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_nsh_set_locator_set_t_print (vl_api_one_nsh_set_locator_set_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_nsh_set_locator_set_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_nsh_set_locator_set_reply_t_print (vl_api_one_nsh_set_locator_set_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_nsh_set_locator_set_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_pitr_set_locator_set_t_print (vl_api_one_pitr_set_locator_set_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_pitr_set_locator_set_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_pitr_set_locator_set_reply_t_print (vl_api_one_pitr_set_locator_set_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_pitr_set_locator_set_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_use_petr_t_print (vl_api_one_use_petr_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_use_petr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_one_use_petr_reply_t_print (vl_api_one_use_petr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_use_petr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_use_petr_t_print (vl_api_show_one_use_petr_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_use_petr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_use_petr_reply_t_print (vl_api_show_one_use_petr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_use_petr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "status: %u\n", (unsigned) a->status);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_show_one_rloc_probe_state_t_print (vl_api_show_one_rloc_probe_state_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_rloc_probe_state_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_rloc_probe_state_reply_t_print (vl_api_show_one_rloc_probe_state_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_rloc_probe_state_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_one_rloc_probe_enable_disable_t_print (vl_api_one_rloc_probe_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_rloc_probe_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_one_rloc_probe_enable_disable_reply_t_print (vl_api_one_rloc_probe_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_rloc_probe_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_map_register_enable_disable_t_print (vl_api_one_map_register_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_one_map_register_enable_disable_reply_t_print (vl_api_one_map_register_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_map_register_state_t_print (vl_api_show_one_map_register_state_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_state_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_map_register_state_reply_t_print (vl_api_show_one_map_register_state_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_state_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_enabled: %u\n", (unsigned) a->is_enabled);
    return handle;
}

static inline void *vl_api_one_map_request_mode_t_print (vl_api_one_map_request_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_request_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mode: %u\n", (unsigned) a->mode);
    return handle;
}

static inline void *vl_api_one_map_request_mode_reply_t_print (vl_api_one_map_request_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_request_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_map_request_mode_t_print (vl_api_show_one_map_request_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_request_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_map_request_mode_reply_t_print (vl_api_show_one_map_request_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_request_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "mode: %u\n", (unsigned) a->mode);
    return handle;
}

/***** manual: vl_api_one_remote_locator_t_print  *****/

/***** manual: vl_api_one_add_del_remote_mapping_t_print  *****/

static inline void *vl_api_one_add_del_remote_mapping_reply_t_print (vl_api_one_add_del_remote_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_remote_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_add_del_l2_arp_entry_t_print (vl_api_one_add_del_l2_arp_entry_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_l2_arp_entry_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac[%d]: %u\n", _i, a->mac[_i]);
        }
    }
    vl_print(handle, "bd: %u\n", (unsigned) a->bd);
    vl_print(handle, "ip4: %u\n", (unsigned) a->ip4);
    return handle;
}

static inline void *vl_api_one_add_del_l2_arp_entry_reply_t_print (vl_api_one_add_del_l2_arp_entry_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_l2_arp_entry_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_l2_arp_entries_get_t_print (vl_api_one_l2_arp_entries_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_l2_arp_entries_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd: %u\n", (unsigned) a->bd);
    return handle;
}

/***** manual: vl_api_one_l2_arp_entry_t_print  *****/

/***** manual: vl_api_one_l2_arp_entries_get_reply_t_print  *****/

static inline void *vl_api_one_add_del_ndp_entry_t_print (vl_api_one_add_del_ndp_entry_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_ndp_entry_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac[%d]: %u\n", _i, a->mac[_i]);
        }
    }
    vl_print(handle, "bd: %u\n", (unsigned) a->bd);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6[%d]: %u\n", _i, a->ip6[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_add_del_ndp_entry_reply_t_print (vl_api_one_add_del_ndp_entry_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_ndp_entry_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_ndp_entries_get_t_print (vl_api_one_ndp_entries_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_ndp_entries_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "bd: %u\n", (unsigned) a->bd);
    return handle;
}

/***** manual: vl_api_one_ndp_entry_t_print  *****/

/***** manual: vl_api_one_ndp_entries_get_reply_t_print  *****/

static inline void *vl_api_one_set_transport_protocol_t_print (vl_api_one_set_transport_protocol_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_set_transport_protocol_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    return handle;
}

static inline void *vl_api_one_set_transport_protocol_reply_t_print (vl_api_one_set_transport_protocol_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_set_transport_protocol_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_get_transport_protocol_t_print (vl_api_one_get_transport_protocol_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_get_transport_protocol_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_get_transport_protocol_reply_t_print (vl_api_one_get_transport_protocol_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_get_transport_protocol_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    return handle;
}

static inline void *vl_api_one_ndp_bd_get_t_print (vl_api_one_ndp_bd_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_ndp_bd_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_one_ndp_bd_get_reply_t_print  *****/

static inline void *vl_api_one_l2_arp_bd_get_t_print (vl_api_one_l2_arp_bd_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_l2_arp_bd_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_one_l2_arp_bd_get_reply_t_print  *****/

static inline void *vl_api_one_add_del_adjacency_t_print (vl_api_one_add_del_adjacency_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_adjacency_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "reid[%d]: %u\n", _i, a->reid[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "leid[%d]: %u\n", _i, a->leid[_i]);
        }
    }
    vl_print(handle, "reid_len: %u\n", (unsigned) a->reid_len);
    vl_print(handle, "leid_len: %u\n", (unsigned) a->leid_len);
    return handle;
}

static inline void *vl_api_one_add_del_adjacency_reply_t_print (vl_api_one_add_del_adjacency_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_adjacency_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_add_del_map_request_itr_rlocs_t_print (vl_api_one_add_del_map_request_itr_rlocs_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_request_itr_rlocs_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_add_del_map_request_itr_rlocs_reply_t_print (vl_api_one_add_del_map_request_itr_rlocs_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_add_del_map_request_itr_rlocs_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_eid_table_add_del_map_t_print (vl_api_one_eid_table_add_del_map_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_add_del_map_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "dp_table: %u\n", (unsigned) a->dp_table);
    vl_print(handle, "is_l2: %u\n", (unsigned) a->is_l2);
    return handle;
}

static inline void *vl_api_one_eid_table_add_del_map_reply_t_print (vl_api_one_eid_table_add_del_map_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_add_del_map_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_locator_dump_t_print (vl_api_one_locator_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_locator_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    vl_print(handle, "is_index_set: %u\n", (unsigned) a->is_index_set);
    return handle;
}

static inline void *vl_api_one_locator_details_t_print (vl_api_one_locator_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_locator_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "local: %u\n", (unsigned) a->local);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "priority: %u\n", (unsigned) a->priority);
    vl_print(handle, "weight: %u\n", (unsigned) a->weight);
    return handle;
}

static inline void *vl_api_one_locator_set_details_t_print (vl_api_one_locator_set_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_locator_set_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "ls_index: %u\n", (unsigned) a->ls_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "ls_name[%d]: %u\n", _i, a->ls_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_locator_set_dump_t_print (vl_api_one_locator_set_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_locator_set_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "filter: %u\n", (unsigned) a->filter);
    return handle;
}

static inline void *vl_api_one_eid_table_details_t_print (vl_api_one_eid_table_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "locator_set_index: %u\n", (unsigned) a->locator_set_index);
    vl_print(handle, "action: %u\n", (unsigned) a->action);
    vl_print(handle, "is_local: %u\n", (unsigned) a->is_local);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    vl_print(handle, "is_src_dst: %u\n", (unsigned) a->is_src_dst);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "eid_prefix_len: %u\n", (unsigned) a->eid_prefix_len);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "seid[%d]: %u\n", _i, a->seid[_i]);
        }
    }
    vl_print(handle, "seid_prefix_len: %u\n", (unsigned) a->seid_prefix_len);
    vl_print(handle, "ttl: %u\n", (unsigned) a->ttl);
    vl_print(handle, "authoritative: %u\n", (unsigned) a->authoritative);
    vl_print(handle, "key_id: %u\n", (unsigned) a->key_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "key[%d]: %u\n", _i, a->key[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_eid_table_dump_t_print (vl_api_one_eid_table_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "eid_set: %u\n", (unsigned) a->eid_set);
    vl_print(handle, "prefix_length: %u\n", (unsigned) a->prefix_length);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "eid[%d]: %u\n", _i, a->eid[_i]);
        }
    }
    vl_print(handle, "filter: %u\n", (unsigned) a->filter);
    return handle;
}

/***** manual: vl_api_one_adjacency_t_print  *****/

/***** manual: vl_api_one_adjacencies_get_reply_t_print  *****/

static inline void *vl_api_one_adjacencies_get_t_print (vl_api_one_adjacencies_get_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_adjacencies_get_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

static inline void *vl_api_one_eid_table_map_details_t_print (vl_api_one_eid_table_map_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_map_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "dp_table: %u\n", (unsigned) a->dp_table);
    return handle;
}

static inline void *vl_api_one_eid_table_map_dump_t_print (vl_api_one_eid_table_map_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_map_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_l2: %u\n", (unsigned) a->is_l2);
    return handle;
}

static inline void *vl_api_one_eid_table_vni_dump_t_print (vl_api_one_eid_table_vni_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_vni_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_eid_table_vni_details_t_print (vl_api_one_eid_table_vni_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_eid_table_vni_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    return handle;
}

static inline void *vl_api_one_map_resolver_details_t_print (vl_api_one_map_resolver_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_resolver_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_map_resolver_dump_t_print (vl_api_one_map_resolver_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_resolver_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_map_server_details_t_print (vl_api_one_map_server_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_server_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_map_server_dump_t_print (vl_api_one_map_server_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_server_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_status_t_print (vl_api_show_one_status_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_status_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_status_reply_t_print (vl_api_show_one_status_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_status_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "feature_status: %u\n", (unsigned) a->feature_status);
    vl_print(handle, "gpe_status: %u\n", (unsigned) a->gpe_status);
    return handle;
}

static inline void *vl_api_one_get_map_request_itr_rlocs_t_print (vl_api_one_get_map_request_itr_rlocs_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_get_map_request_itr_rlocs_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_get_map_request_itr_rlocs_reply_t_print (vl_api_one_get_map_request_itr_rlocs_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_get_map_request_itr_rlocs_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_show_one_nsh_mapping_t_print (vl_api_show_one_nsh_mapping_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_nsh_mapping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_nsh_mapping_reply_t_print (vl_api_show_one_nsh_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_nsh_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_set: %u\n", (unsigned) a->is_set);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_show_one_pitr_t_print (vl_api_show_one_pitr_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_pitr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_pitr_reply_t_print (vl_api_show_one_pitr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_pitr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "status: %u\n", (unsigned) a->status);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "locator_set_name[%d]: %u\n", _i, a->locator_set_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_one_stats_dump_t_print (vl_api_one_stats_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_stats_details_t_print (vl_api_one_stats_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vni: %u\n", (unsigned) a->vni);
    vl_print(handle, "eid_type: %u\n", (unsigned) a->eid_type);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "deid[%d]: %u\n", _i, a->deid[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "seid[%d]: %u\n", _i, a->seid[_i]);
        }
    }
    vl_print(handle, "deid_pref_len: %u\n", (unsigned) a->deid_pref_len);
    vl_print(handle, "seid_pref_len: %u\n", (unsigned) a->seid_pref_len);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "rloc[%d]: %u\n", _i, a->rloc[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "lloc[%d]: %u\n", _i, a->lloc[_i]);
        }
    }
    vl_print(handle, "pkt_count: %u\n", (unsigned) a->pkt_count);
    vl_print(handle, "bytes: %u\n", (unsigned) a->bytes);
    return handle;
}

static inline void *vl_api_one_stats_flush_t_print (vl_api_one_stats_flush_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_flush_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_stats_flush_reply_t_print (vl_api_one_stats_flush_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_flush_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_stats_enable_disable_t_print (vl_api_one_stats_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_stats_enable_disable_reply_t_print (vl_api_one_stats_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_stats_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_stats_enable_disable_t_print (vl_api_show_one_stats_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_stats_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_stats_enable_disable_reply_t_print (vl_api_show_one_stats_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_stats_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_map_register_fallback_threshold_t_print (vl_api_one_map_register_fallback_threshold_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_fallback_threshold_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "value: %u\n", (unsigned) a->value);
    return handle;
}

static inline void *vl_api_one_map_register_fallback_threshold_reply_t_print (vl_api_one_map_register_fallback_threshold_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_map_register_fallback_threshold_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_show_one_map_register_fallback_threshold_t_print (vl_api_show_one_map_register_fallback_threshold_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_fallback_threshold_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_show_one_map_register_fallback_threshold_reply_t_print (vl_api_show_one_map_register_fallback_threshold_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_show_one_map_register_fallback_threshold_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "value: %u\n", (unsigned) a->value);
    return handle;
}

static inline void *vl_api_one_enable_disable_xtr_mode_t_print (vl_api_one_enable_disable_xtr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_xtr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_xtr_mode_reply_t_print (vl_api_one_enable_disable_xtr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_xtr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_show_xtr_mode_t_print (vl_api_one_show_xtr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_xtr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_show_xtr_mode_reply_t_print (vl_api_one_show_xtr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_xtr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_petr_mode_t_print (vl_api_one_enable_disable_petr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_petr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_petr_mode_reply_t_print (vl_api_one_enable_disable_petr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_petr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_show_petr_mode_t_print (vl_api_one_show_petr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_petr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_show_petr_mode_reply_t_print (vl_api_one_show_petr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_petr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_pitr_mode_t_print (vl_api_one_enable_disable_pitr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_pitr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

static inline void *vl_api_one_enable_disable_pitr_mode_reply_t_print (vl_api_one_enable_disable_pitr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_enable_disable_pitr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_one_show_pitr_mode_t_print (vl_api_one_show_pitr_mode_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_pitr_mode_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_one_show_pitr_mode_reply_t_print (vl_api_one_show_pitr_mode_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_one_show_pitr_mode_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_en: %u\n", (unsigned) a->is_en);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

/***** manual: vl_api_one_local_locator_t_endian  *****/

/***** manual: vl_api_one_add_del_locator_set_t_endian  *****/

static inline void vl_api_one_add_del_locator_set_reply_t_endian (vl_api_one_add_del_locator_set_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
}

static inline void vl_api_one_add_del_locator_t_endian (vl_api_one_add_del_locator_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->priority = a->priority (no-op) */
    /* a->weight = a->weight (no-op) */
}

static inline void vl_api_one_add_del_locator_reply_t_endian (vl_api_one_add_del_locator_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_add_del_local_eid_t_endian (vl_api_one_add_del_local_eid_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->eid_type = a->eid_type (no-op) */
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->prefix_len = a->prefix_len (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    a->key_id = clib_net_to_host_u16(a->key_id);
    /* a->key[0..63] = a->key[0..63] (no-op) */
}

static inline void vl_api_one_add_del_local_eid_reply_t_endian (vl_api_one_add_del_local_eid_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_map_register_set_ttl_t_endian (vl_api_one_map_register_set_ttl_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ttl = clib_net_to_host_u32(a->ttl);
}

static inline void vl_api_one_map_register_set_ttl_reply_t_endian (vl_api_one_map_register_set_ttl_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_map_register_ttl_t_endian (vl_api_show_one_map_register_ttl_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_map_register_ttl_reply_t_endian (vl_api_show_one_map_register_ttl_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->ttl = clib_net_to_host_u32(a->ttl);
}

static inline void vl_api_one_add_del_map_server_t_endian (vl_api_one_add_del_map_server_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_one_add_del_map_server_reply_t_endian (vl_api_one_add_del_map_server_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_add_del_map_resolver_t_endian (vl_api_one_add_del_map_resolver_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_one_add_del_map_resolver_reply_t_endian (vl_api_one_add_del_map_resolver_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_enable_disable_t_endian (vl_api_one_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_reply_t_endian (vl_api_one_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_nsh_set_locator_set_t_endian (vl_api_one_nsh_set_locator_set_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
}

static inline void vl_api_one_nsh_set_locator_set_reply_t_endian (vl_api_one_nsh_set_locator_set_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_pitr_set_locator_set_t_endian (vl_api_one_pitr_set_locator_set_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
}

static inline void vl_api_one_pitr_set_locator_set_reply_t_endian (vl_api_one_pitr_set_locator_set_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_use_petr_t_endian (vl_api_one_use_petr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_one_use_petr_reply_t_endian (vl_api_one_use_petr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_use_petr_t_endian (vl_api_show_one_use_petr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_use_petr_reply_t_endian (vl_api_show_one_use_petr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->status = a->status (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_show_one_rloc_probe_state_t_endian (vl_api_show_one_rloc_probe_state_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_rloc_probe_state_reply_t_endian (vl_api_show_one_rloc_probe_state_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_one_rloc_probe_enable_disable_t_endian (vl_api_one_rloc_probe_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_one_rloc_probe_enable_disable_reply_t_endian (vl_api_one_rloc_probe_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_map_register_enable_disable_t_endian (vl_api_one_map_register_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_one_map_register_enable_disable_reply_t_endian (vl_api_one_map_register_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_map_register_state_t_endian (vl_api_show_one_map_register_state_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_map_register_state_reply_t_endian (vl_api_show_one_map_register_state_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_enabled = a->is_enabled (no-op) */
}

static inline void vl_api_one_map_request_mode_t_endian (vl_api_one_map_request_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->mode = a->mode (no-op) */
}

static inline void vl_api_one_map_request_mode_reply_t_endian (vl_api_one_map_request_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_map_request_mode_t_endian (vl_api_show_one_map_request_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_map_request_mode_reply_t_endian (vl_api_show_one_map_request_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->mode = a->mode (no-op) */
}

/***** manual: vl_api_one_remote_locator_t_endian  *****/

/***** manual: vl_api_one_add_del_remote_mapping_t_endian  *****/

static inline void vl_api_one_add_del_remote_mapping_reply_t_endian (vl_api_one_add_del_remote_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_add_del_l2_arp_entry_t_endian (vl_api_one_add_del_l2_arp_entry_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->mac[0..5] = a->mac[0..5] (no-op) */
    a->bd = clib_net_to_host_u32(a->bd);
    a->ip4 = clib_net_to_host_u32(a->ip4);
}

static inline void vl_api_one_add_del_l2_arp_entry_reply_t_endian (vl_api_one_add_del_l2_arp_entry_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_l2_arp_entries_get_t_endian (vl_api_one_l2_arp_entries_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd = clib_net_to_host_u32(a->bd);
}

/***** manual: vl_api_one_l2_arp_entry_t_endian  *****/

/***** manual: vl_api_one_l2_arp_entries_get_reply_t_endian  *****/

static inline void vl_api_one_add_del_ndp_entry_t_endian (vl_api_one_add_del_ndp_entry_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->mac[0..5] = a->mac[0..5] (no-op) */
    a->bd = clib_net_to_host_u32(a->bd);
    /* a->ip6[0..15] = a->ip6[0..15] (no-op) */
}

static inline void vl_api_one_add_del_ndp_entry_reply_t_endian (vl_api_one_add_del_ndp_entry_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_ndp_entries_get_t_endian (vl_api_one_ndp_entries_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->bd = clib_net_to_host_u32(a->bd);
}

/***** manual: vl_api_one_ndp_entry_t_endian  *****/

/***** manual: vl_api_one_ndp_entries_get_reply_t_endian  *****/

static inline void vl_api_one_set_transport_protocol_t_endian (vl_api_one_set_transport_protocol_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->protocol = a->protocol (no-op) */
}

static inline void vl_api_one_set_transport_protocol_reply_t_endian (vl_api_one_set_transport_protocol_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_get_transport_protocol_t_endian (vl_api_one_get_transport_protocol_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_get_transport_protocol_reply_t_endian (vl_api_one_get_transport_protocol_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->protocol = a->protocol (no-op) */
}

static inline void vl_api_one_ndp_bd_get_t_endian (vl_api_one_ndp_bd_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_one_ndp_bd_get_reply_t_endian  *****/

static inline void vl_api_one_l2_arp_bd_get_t_endian (vl_api_one_l2_arp_bd_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_one_l2_arp_bd_get_reply_t_endian  *****/

static inline void vl_api_one_add_del_adjacency_t_endian (vl_api_one_add_del_adjacency_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid_type = a->eid_type (no-op) */
    /* a->reid[0..15] = a->reid[0..15] (no-op) */
    /* a->leid[0..15] = a->leid[0..15] (no-op) */
    /* a->reid_len = a->reid_len (no-op) */
    /* a->leid_len = a->leid_len (no-op) */
}

static inline void vl_api_one_add_del_adjacency_reply_t_endian (vl_api_one_add_del_adjacency_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_add_del_map_request_itr_rlocs_t_endian (vl_api_one_add_del_map_request_itr_rlocs_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_one_add_del_map_request_itr_rlocs_reply_t_endian (vl_api_one_add_del_map_request_itr_rlocs_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_eid_table_add_del_map_t_endian (vl_api_one_eid_table_add_del_map_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    a->dp_table = clib_net_to_host_u32(a->dp_table);
    /* a->is_l2 = a->is_l2 (no-op) */
}

static inline void vl_api_one_eid_table_add_del_map_reply_t_endian (vl_api_one_eid_table_add_del_map_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_locator_dump_t_endian (vl_api_one_locator_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
    /* a->is_index_set = a->is_index_set (no-op) */
}

static inline void vl_api_one_locator_details_t_endian (vl_api_one_locator_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->local = a->local (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    /* a->priority = a->priority (no-op) */
    /* a->weight = a->weight (no-op) */
}

static inline void vl_api_one_locator_set_details_t_endian (vl_api_one_locator_set_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->ls_index = clib_net_to_host_u32(a->ls_index);
    /* a->ls_name[0..63] = a->ls_name[0..63] (no-op) */
}

static inline void vl_api_one_locator_set_dump_t_endian (vl_api_one_locator_set_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->filter = a->filter (no-op) */
}

static inline void vl_api_one_eid_table_details_t_endian (vl_api_one_eid_table_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->locator_set_index = clib_net_to_host_u32(a->locator_set_index);
    /* a->action = a->action (no-op) */
    /* a->is_local = a->is_local (no-op) */
    /* a->eid_type = a->eid_type (no-op) */
    /* a->is_src_dst = a->is_src_dst (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->eid_prefix_len = a->eid_prefix_len (no-op) */
    /* a->seid[0..15] = a->seid[0..15] (no-op) */
    /* a->seid_prefix_len = a->seid_prefix_len (no-op) */
    a->ttl = clib_net_to_host_u32(a->ttl);
    /* a->authoritative = a->authoritative (no-op) */
    a->key_id = clib_net_to_host_u16(a->key_id);
    /* a->key[0..63] = a->key[0..63] (no-op) */
}

static inline void vl_api_one_eid_table_dump_t_endian (vl_api_one_eid_table_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->eid_set = a->eid_set (no-op) */
    /* a->prefix_length = a->prefix_length (no-op) */
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid_type = a->eid_type (no-op) */
    /* a->eid[0..15] = a->eid[0..15] (no-op) */
    /* a->filter = a->filter (no-op) */
}

/***** manual: vl_api_one_adjacency_t_endian  *****/

/***** manual: vl_api_one_adjacencies_get_reply_t_endian  *****/

static inline void vl_api_one_adjacencies_get_t_endian (vl_api_one_adjacencies_get_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_one_eid_table_map_details_t_endian (vl_api_one_eid_table_map_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
    a->dp_table = clib_net_to_host_u32(a->dp_table);
}

static inline void vl_api_one_eid_table_map_dump_t_endian (vl_api_one_eid_table_map_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_l2 = a->is_l2 (no-op) */
}

static inline void vl_api_one_eid_table_vni_dump_t_endian (vl_api_one_eid_table_vni_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_eid_table_vni_details_t_endian (vl_api_one_eid_table_vni_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
}

static inline void vl_api_one_map_resolver_details_t_endian (vl_api_one_map_resolver_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_one_map_resolver_dump_t_endian (vl_api_one_map_resolver_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_map_server_details_t_endian (vl_api_one_map_server_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
}

static inline void vl_api_one_map_server_dump_t_endian (vl_api_one_map_server_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_status_t_endian (vl_api_show_one_status_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_status_reply_t_endian (vl_api_show_one_status_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->feature_status = a->feature_status (no-op) */
    /* a->gpe_status = a->gpe_status (no-op) */
}

static inline void vl_api_one_get_map_request_itr_rlocs_t_endian (vl_api_one_get_map_request_itr_rlocs_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_get_map_request_itr_rlocs_reply_t_endian (vl_api_one_get_map_request_itr_rlocs_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_show_one_nsh_mapping_t_endian (vl_api_show_one_nsh_mapping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_nsh_mapping_reply_t_endian (vl_api_show_one_nsh_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_set = a->is_set (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_show_one_pitr_t_endian (vl_api_show_one_pitr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_pitr_reply_t_endian (vl_api_show_one_pitr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->status = a->status (no-op) */
    /* a->locator_set_name[0..63] = a->locator_set_name[0..63] (no-op) */
}

static inline void vl_api_one_stats_dump_t_endian (vl_api_one_stats_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_stats_details_t_endian (vl_api_one_stats_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->vni = clib_net_to_host_u32(a->vni);
    /* a->eid_type = a->eid_type (no-op) */
    /* a->deid[0..15] = a->deid[0..15] (no-op) */
    /* a->seid[0..15] = a->seid[0..15] (no-op) */
    /* a->deid_pref_len = a->deid_pref_len (no-op) */
    /* a->seid_pref_len = a->seid_pref_len (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->rloc[0..15] = a->rloc[0..15] (no-op) */
    /* a->lloc[0..15] = a->lloc[0..15] (no-op) */
    a->pkt_count = clib_net_to_host_u32(a->pkt_count);
    a->bytes = clib_net_to_host_u32(a->bytes);
}

static inline void vl_api_one_stats_flush_t_endian (vl_api_one_stats_flush_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_stats_flush_reply_t_endian (vl_api_one_stats_flush_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_stats_enable_disable_t_endian (vl_api_one_stats_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_stats_enable_disable_reply_t_endian (vl_api_one_stats_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_stats_enable_disable_t_endian (vl_api_show_one_stats_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_stats_enable_disable_reply_t_endian (vl_api_show_one_stats_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_map_register_fallback_threshold_t_endian (vl_api_one_map_register_fallback_threshold_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->value = clib_net_to_host_u32(a->value);
}

static inline void vl_api_one_map_register_fallback_threshold_reply_t_endian (vl_api_one_map_register_fallback_threshold_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_show_one_map_register_fallback_threshold_t_endian (vl_api_show_one_map_register_fallback_threshold_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_show_one_map_register_fallback_threshold_reply_t_endian (vl_api_show_one_map_register_fallback_threshold_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->value = clib_net_to_host_u32(a->value);
}

static inline void vl_api_one_enable_disable_xtr_mode_t_endian (vl_api_one_enable_disable_xtr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_xtr_mode_reply_t_endian (vl_api_one_enable_disable_xtr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_show_xtr_mode_t_endian (vl_api_one_show_xtr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_show_xtr_mode_reply_t_endian (vl_api_one_show_xtr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_petr_mode_t_endian (vl_api_one_enable_disable_petr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_petr_mode_reply_t_endian (vl_api_one_enable_disable_petr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_show_petr_mode_t_endian (vl_api_one_show_petr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_show_petr_mode_reply_t_endian (vl_api_one_show_petr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_pitr_mode_t_endian (vl_api_one_enable_disable_pitr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_en = a->is_en (no-op) */
}

static inline void vl_api_one_enable_disable_pitr_mode_reply_t_endian (vl_api_one_enable_disable_pitr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_one_show_pitr_mode_t_endian (vl_api_one_show_pitr_mode_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_one_show_pitr_mode_reply_t_endian (vl_api_one_show_pitr_mode_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_en = a->is_en (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(one.api, 0x13c6cf62)

#endif

