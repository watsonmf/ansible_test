/*
 * VLIB API definitions Wed Nov 15 17:02:22 2017
 * Input file: vnet/unix/tap.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/unix/tap.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_TAP_CONNECT, vl_api_tap_connect_t_handler)
vl_msg_id(VL_API_TAP_CONNECT_REPLY, vl_api_tap_connect_reply_t_handler)
vl_msg_id(VL_API_TAP_MODIFY, vl_api_tap_modify_t_handler)
vl_msg_id(VL_API_TAP_MODIFY_REPLY, vl_api_tap_modify_reply_t_handler)
vl_msg_id(VL_API_TAP_DELETE, vl_api_tap_delete_t_handler)
vl_msg_id(VL_API_TAP_DELETE_REPLY, vl_api_tap_delete_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAP_DUMP, vl_api_sw_interface_tap_dump_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAP_DETAILS, vl_api_sw_interface_tap_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_tap_connect_t, 1)
vl_msg_name(vl_api_tap_connect_reply_t, 1)
vl_msg_name(vl_api_tap_modify_t, 1)
vl_msg_name(vl_api_tap_modify_reply_t, 1)
vl_msg_name(vl_api_tap_delete_t, 1)
vl_msg_name(vl_api_tap_delete_reply_t, 1)
vl_msg_name(vl_api_sw_interface_tap_dump_t, 1)
vl_msg_name(vl_api_sw_interface_tap_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_tap \
_(VL_API_TAP_CONNECT, tap_connect, 91720de3) \
_(VL_API_TAP_CONNECT_REPLY, tap_connect_reply, f47feac1) \
_(VL_API_TAP_MODIFY, tap_modify, 8abcd5f3) \
_(VL_API_TAP_MODIFY_REPLY, tap_modify_reply, 00aaf940) \
_(VL_API_TAP_DELETE, tap_delete, e99d41c1) \
_(VL_API_TAP_DELETE_REPLY, tap_delete_reply, 0e47d140) \
_(VL_API_SW_INTERFACE_TAP_DUMP, sw_interface_tap_dump, bc6ddbe2) \
_(VL_API_SW_INTERFACE_TAP_DETAILS, sw_interface_tap_details, 0df07bc3) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_tap_connect {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 use_random_mac;
    u8 tap_name[64];
    u8 mac_address[6];
    u8 renumber;
    u32 custom_dev_instance;
    u8 ip4_address_set;
    u8 ip4_address[4];
    u8 ip4_mask_width;
    u8 ip6_address_set;
    u8 ip6_address[16];
    u8 ip6_mask_width;
    u8 tag[64];
}) vl_api_tap_connect_t;

typedef VL_API_PACKED(struct _vl_api_tap_connect_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_tap_connect_reply_t;

typedef VL_API_PACKED(struct _vl_api_tap_modify {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 use_random_mac;
    u8 tap_name[64];
    u8 mac_address[6];
    u8 renumber;
    u32 custom_dev_instance;
}) vl_api_tap_modify_t;

typedef VL_API_PACKED(struct _vl_api_tap_modify_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_tap_modify_reply_t;

typedef VL_API_PACKED(struct _vl_api_tap_delete {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_tap_delete_t;

typedef VL_API_PACKED(struct _vl_api_tap_delete_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_tap_delete_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_tap_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_sw_interface_tap_dump_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_tap_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u8 dev_name[64];
}) vl_api_sw_interface_tap_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_tap_connect_t_print (vl_api_tap_connect_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_connect_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "use_random_mac: %u\n", (unsigned) a->use_random_mac);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "tap_name[%d]: %u\n", _i, a->tap_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    vl_print(handle, "renumber: %u\n", (unsigned) a->renumber);
    vl_print(handle, "custom_dev_instance: %u\n", (unsigned) a->custom_dev_instance);
    vl_print(handle, "ip4_address_set: %u\n", (unsigned) a->ip4_address_set);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip4_address[%d]: %u\n", _i, a->ip4_address[_i]);
        }
    }
    vl_print(handle, "ip4_mask_width: %u\n", (unsigned) a->ip4_mask_width);
    vl_print(handle, "ip6_address_set: %u\n", (unsigned) a->ip6_address_set);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip6_address[%d]: %u\n", _i, a->ip6_address[_i]);
        }
    }
    vl_print(handle, "ip6_mask_width: %u\n", (unsigned) a->ip6_mask_width);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "tag[%d]: %u\n", _i, a->tag[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_tap_connect_reply_t_print (vl_api_tap_connect_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_connect_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_tap_modify_t_print (vl_api_tap_modify_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_modify_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "use_random_mac: %u\n", (unsigned) a->use_random_mac);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "tap_name[%d]: %u\n", _i, a->tap_name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    vl_print(handle, "renumber: %u\n", (unsigned) a->renumber);
    vl_print(handle, "custom_dev_instance: %u\n", (unsigned) a->custom_dev_instance);
    return handle;
}

static inline void *vl_api_tap_modify_reply_t_print (vl_api_tap_modify_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_modify_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_tap_delete_t_print (vl_api_tap_delete_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_delete_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_tap_delete_reply_t_print (vl_api_tap_delete_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_tap_delete_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_tap_dump_t_print (vl_api_sw_interface_tap_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_tap_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_sw_interface_tap_details_t_print (vl_api_sw_interface_tap_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_tap_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "dev_name[%d]: %u\n", _i, a->dev_name[_i]);
        }
    }
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_tap_connect_t_endian (vl_api_tap_connect_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->use_random_mac = a->use_random_mac (no-op) */
    /* a->tap_name[0..63] = a->tap_name[0..63] (no-op) */
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
    /* a->renumber = a->renumber (no-op) */
    a->custom_dev_instance = clib_net_to_host_u32(a->custom_dev_instance);
    /* a->ip4_address_set = a->ip4_address_set (no-op) */
    /* a->ip4_address[0..3] = a->ip4_address[0..3] (no-op) */
    /* a->ip4_mask_width = a->ip4_mask_width (no-op) */
    /* a->ip6_address_set = a->ip6_address_set (no-op) */
    /* a->ip6_address[0..15] = a->ip6_address[0..15] (no-op) */
    /* a->ip6_mask_width = a->ip6_mask_width (no-op) */
    /* a->tag[0..63] = a->tag[0..63] (no-op) */
}

static inline void vl_api_tap_connect_reply_t_endian (vl_api_tap_connect_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_tap_modify_t_endian (vl_api_tap_modify_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->use_random_mac = a->use_random_mac (no-op) */
    /* a->tap_name[0..63] = a->tap_name[0..63] (no-op) */
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
    /* a->renumber = a->renumber (no-op) */
    a->custom_dev_instance = clib_net_to_host_u32(a->custom_dev_instance);
}

static inline void vl_api_tap_modify_reply_t_endian (vl_api_tap_modify_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_tap_delete_t_endian (vl_api_tap_delete_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_tap_delete_reply_t_endian (vl_api_tap_delete_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_tap_dump_t_endian (vl_api_sw_interface_tap_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_sw_interface_tap_details_t_endian (vl_api_sw_interface_tap_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->dev_name[0..63] = a->dev_name[0..63] (no-op) */
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(tap.api, 0x4eaa2b5a)

#endif

