/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/mpls/mpls.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/mpls/mpls.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_MPLS_IP_BIND_UNBIND, vl_api_mpls_ip_bind_unbind_t_handler)
vl_msg_id(VL_API_MPLS_IP_BIND_UNBIND_REPLY, vl_api_mpls_ip_bind_unbind_reply_t_handler)
vl_msg_id(VL_API_MPLS_TUNNEL_ADD_DEL, vl_api_mpls_tunnel_add_del_t_handler)
vl_msg_id(VL_API_MPLS_TUNNEL_ADD_DEL_REPLY, vl_api_mpls_tunnel_add_del_reply_t_handler)
vl_msg_id(VL_API_MPLS_TUNNEL_DUMP, vl_api_mpls_tunnel_dump_t_handler)
/* typeonly: fib_path2 */
vl_msg_id(VL_API_MPLS_TUNNEL_DETAILS, vl_api_mpls_tunnel_details_t_handler)
vl_msg_id(VL_API_MPLS_TABLE_ADD_DEL, vl_api_mpls_table_add_del_t_handler)
vl_msg_id(VL_API_MPLS_TABLE_ADD_DEL_REPLY, vl_api_mpls_table_add_del_reply_t_handler)
vl_msg_id(VL_API_MPLS_ROUTE_ADD_DEL, vl_api_mpls_route_add_del_t_handler)
vl_msg_id(VL_API_MPLS_ROUTE_ADD_DEL_REPLY, vl_api_mpls_route_add_del_reply_t_handler)
vl_msg_id(VL_API_MPLS_FIB_DUMP, vl_api_mpls_fib_dump_t_handler)
vl_msg_id(VL_API_MPLS_FIB_DETAILS, vl_api_mpls_fib_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_mpls_ip_bind_unbind_t, 1)
vl_msg_name(vl_api_mpls_ip_bind_unbind_reply_t, 1)
vl_msg_name(vl_api_mpls_tunnel_add_del_t, 1)
vl_msg_name(vl_api_mpls_tunnel_add_del_reply_t, 1)
vl_msg_name(vl_api_mpls_tunnel_dump_t, 1)
/* typeonly: fib_path2 */
vl_msg_name(vl_api_mpls_tunnel_details_t, 1)
vl_msg_name(vl_api_mpls_table_add_del_t, 1)
vl_msg_name(vl_api_mpls_table_add_del_reply_t, 1)
vl_msg_name(vl_api_mpls_route_add_del_t, 1)
vl_msg_name(vl_api_mpls_route_add_del_reply_t, 1)
vl_msg_name(vl_api_mpls_fib_dump_t, 1)
vl_msg_name(vl_api_mpls_fib_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_mpls \
_(VL_API_MPLS_IP_BIND_UNBIND, mpls_ip_bind_unbind, 167f24bd) \
_(VL_API_MPLS_IP_BIND_UNBIND_REPLY, mpls_ip_bind_unbind_reply, 5753d1ed) \
_(VL_API_MPLS_TUNNEL_ADD_DEL, mpls_tunnel_add_del, afb8f594) \
_(VL_API_MPLS_TUNNEL_ADD_DEL_REPLY, mpls_tunnel_add_del_reply, bb483273) \
_(VL_API_MPLS_TUNNEL_DUMP, mpls_tunnel_dump, be9ada9c) \
_(VL_API_MPLS_TUNNEL_DETAILS, mpls_tunnel_details, f43de2ca) \
_(VL_API_MPLS_TABLE_ADD_DEL, mpls_table_add_del, 943bd589) \
_(VL_API_MPLS_TABLE_ADD_DEL_REPLY, mpls_table_add_del_reply, e1e78638) \
_(VL_API_MPLS_ROUTE_ADD_DEL, mpls_route_add_del, d509645a) \
_(VL_API_MPLS_ROUTE_ADD_DEL_REPLY, mpls_route_add_del_reply, 21a12fe9) \
_(VL_API_MPLS_FIB_DUMP, mpls_fib_dump, 7e82659e) \
_(VL_API_MPLS_FIB_DETAILS, mpls_fib_details, 2a1ab162) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_mpls_ip_bind_unbind {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 mb_mpls_table_id;
    u32 mb_label;
    u32 mb_ip_table_id;
    u8 mb_create_table_if_needed;
    u8 mb_is_bind;
    u8 mb_is_ip4;
    u8 mb_address_length;
    u8 mb_address[16];
}) vl_api_mpls_ip_bind_unbind_t;

typedef VL_API_PACKED(struct _vl_api_mpls_ip_bind_unbind_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_mpls_ip_bind_unbind_reply_t;

typedef VL_API_PACKED(struct _vl_api_mpls_tunnel_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 mt_sw_if_index;
    u8 mt_is_add;
    u8 mt_l2_only;
    u8 mt_is_multicast;
    u8 mt_next_hop_proto_is_ip4;
    u8 mt_next_hop_weight;
    u8 mt_next_hop_preference;
    u8 mt_next_hop[16];
    u8 mt_next_hop_n_out_labels;
    u32 mt_next_hop_sw_if_index;
    u32 mt_next_hop_table_id;
    u32 mt_next_hop_out_label_stack[0];
}) vl_api_mpls_tunnel_add_del_t;

typedef VL_API_PACKED(struct _vl_api_mpls_tunnel_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 sw_if_index;
}) vl_api_mpls_tunnel_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_mpls_tunnel_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 tunnel_index;
}) vl_api_mpls_tunnel_dump_t;

typedef VL_API_PACKED(struct _vl_api_fib_path2 {
    u32 sw_if_index;
    u8 weight;
    u8 preference;
    u8 is_local;
    u8 is_drop;
    u8 is_unreach;
    u8 is_prohibit;
    u8 afi;
    u8 next_hop[16];
    u32 labels[16];
}) vl_api_fib_path2_t;

typedef VL_API_PACKED(struct _vl_api_mpls_tunnel_details {
    u16 _vl_msg_id;
    u32 context;
    u8 mt_sw_if_index;
    u8 mt_tunnel_index;
    u8 mt_l2_only;
    u8 mt_is_multicast;
    u32 mt_count;
    vl_api_fib_path2_t mt_paths[0];
}) vl_api_mpls_tunnel_details_t;

typedef VL_API_PACKED(struct _vl_api_mpls_table_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 mt_table_id;
    u8 mt_is_add;
    u8 mt_name[64];
}) vl_api_mpls_table_add_del_t;

typedef VL_API_PACKED(struct _vl_api_mpls_table_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_mpls_table_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_mpls_route_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 mr_label;
    u8 mr_eos;
    u32 mr_table_id;
    u32 mr_classify_table_index;
    u8 mr_create_table_if_needed;
    u8 mr_is_add;
    u8 mr_is_classify;
    u8 mr_is_multicast;
    u8 mr_is_multipath;
    u8 mr_is_resolve_host;
    u8 mr_is_resolve_attached;
    u8 mr_is_interface_rx;
    u8 mr_is_rpf_id;
    u8 mr_next_hop_proto;
    u8 mr_next_hop_weight;
    u8 mr_next_hop_preference;
    u8 mr_next_hop[16];
    u8 mr_next_hop_n_out_labels;
    u32 mr_next_hop_sw_if_index;
    u32 mr_next_hop_table_id;
    u32 mr_next_hop_via_label;
    u32 mr_next_hop_out_label_stack[0];
}) vl_api_mpls_route_add_del_t;

typedef VL_API_PACKED(struct _vl_api_mpls_route_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_mpls_route_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_mpls_fib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_mpls_fib_dump_t;

typedef VL_API_PACKED(struct _vl_api_mpls_fib_details {
    u16 _vl_msg_id;
    u32 context;
    u32 table_id;
    u8 table_name[64];
    u8 eos_bit;
    u32 label;
    u32 count;
    vl_api_fib_path2_t path[0];
}) vl_api_mpls_fib_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_mpls_ip_bind_unbind_t_print (vl_api_mpls_ip_bind_unbind_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_ip_bind_unbind_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mb_mpls_table_id: %u\n", (unsigned) a->mb_mpls_table_id);
    vl_print(handle, "mb_label: %u\n", (unsigned) a->mb_label);
    vl_print(handle, "mb_ip_table_id: %u\n", (unsigned) a->mb_ip_table_id);
    vl_print(handle, "mb_create_table_if_needed: %u\n", (unsigned) a->mb_create_table_if_needed);
    vl_print(handle, "mb_is_bind: %u\n", (unsigned) a->mb_is_bind);
    vl_print(handle, "mb_is_ip4: %u\n", (unsigned) a->mb_is_ip4);
    vl_print(handle, "mb_address_length: %u\n", (unsigned) a->mb_address_length);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "mb_address[%d]: %u\n", _i, a->mb_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_mpls_ip_bind_unbind_reply_t_print (vl_api_mpls_ip_bind_unbind_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_ip_bind_unbind_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_mpls_tunnel_add_del_t_print (vl_api_mpls_tunnel_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_tunnel_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mt_sw_if_index: %u\n", (unsigned) a->mt_sw_if_index);
    vl_print(handle, "mt_is_add: %u\n", (unsigned) a->mt_is_add);
    vl_print(handle, "mt_l2_only: %u\n", (unsigned) a->mt_l2_only);
    vl_print(handle, "mt_is_multicast: %u\n", (unsigned) a->mt_is_multicast);
    vl_print(handle, "mt_next_hop_proto_is_ip4: %u\n", (unsigned) a->mt_next_hop_proto_is_ip4);
    vl_print(handle, "mt_next_hop_weight: %u\n", (unsigned) a->mt_next_hop_weight);
    vl_print(handle, "mt_next_hop_preference: %u\n", (unsigned) a->mt_next_hop_preference);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "mt_next_hop[%d]: %u\n", _i, a->mt_next_hop[_i]);
        }
    }
    vl_print(handle, "mt_next_hop_n_out_labels: %u\n", (unsigned) a->mt_next_hop_n_out_labels);
    vl_print(handle, "mt_next_hop_sw_if_index: %u\n", (unsigned) a->mt_next_hop_sw_if_index);
    vl_print(handle, "mt_next_hop_table_id: %u\n", (unsigned) a->mt_next_hop_table_id);
    return handle;
}

static inline void *vl_api_mpls_tunnel_add_del_reply_t_print (vl_api_mpls_tunnel_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_tunnel_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_mpls_tunnel_dump_t_print (vl_api_mpls_tunnel_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_tunnel_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "tunnel_index: %ld\n", (long) a->tunnel_index);
    return handle;
}

/***** manual: vl_api_fib_path2_t_print  *****/

/***** manual: vl_api_mpls_tunnel_details_t_print  *****/

static inline void *vl_api_mpls_table_add_del_t_print (vl_api_mpls_table_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_table_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mt_table_id: %u\n", (unsigned) a->mt_table_id);
    vl_print(handle, "mt_is_add: %u\n", (unsigned) a->mt_is_add);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "mt_name[%d]: %u\n", _i, a->mt_name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_mpls_table_add_del_reply_t_print (vl_api_mpls_table_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_table_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_mpls_route_add_del_t_print (vl_api_mpls_route_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_route_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "mr_label: %u\n", (unsigned) a->mr_label);
    vl_print(handle, "mr_eos: %u\n", (unsigned) a->mr_eos);
    vl_print(handle, "mr_table_id: %u\n", (unsigned) a->mr_table_id);
    vl_print(handle, "mr_classify_table_index: %u\n", (unsigned) a->mr_classify_table_index);
    vl_print(handle, "mr_create_table_if_needed: %u\n", (unsigned) a->mr_create_table_if_needed);
    vl_print(handle, "mr_is_add: %u\n", (unsigned) a->mr_is_add);
    vl_print(handle, "mr_is_classify: %u\n", (unsigned) a->mr_is_classify);
    vl_print(handle, "mr_is_multicast: %u\n", (unsigned) a->mr_is_multicast);
    vl_print(handle, "mr_is_multipath: %u\n", (unsigned) a->mr_is_multipath);
    vl_print(handle, "mr_is_resolve_host: %u\n", (unsigned) a->mr_is_resolve_host);
    vl_print(handle, "mr_is_resolve_attached: %u\n", (unsigned) a->mr_is_resolve_attached);
    vl_print(handle, "mr_is_interface_rx: %u\n", (unsigned) a->mr_is_interface_rx);
    vl_print(handle, "mr_is_rpf_id: %u\n", (unsigned) a->mr_is_rpf_id);
    vl_print(handle, "mr_next_hop_proto: %u\n", (unsigned) a->mr_next_hop_proto);
    vl_print(handle, "mr_next_hop_weight: %u\n", (unsigned) a->mr_next_hop_weight);
    vl_print(handle, "mr_next_hop_preference: %u\n", (unsigned) a->mr_next_hop_preference);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "mr_next_hop[%d]: %u\n", _i, a->mr_next_hop[_i]);
        }
    }
    vl_print(handle, "mr_next_hop_n_out_labels: %u\n", (unsigned) a->mr_next_hop_n_out_labels);
    vl_print(handle, "mr_next_hop_sw_if_index: %u\n", (unsigned) a->mr_next_hop_sw_if_index);
    vl_print(handle, "mr_next_hop_table_id: %u\n", (unsigned) a->mr_next_hop_table_id);
    vl_print(handle, "mr_next_hop_via_label: %u\n", (unsigned) a->mr_next_hop_via_label);
    return handle;
}

static inline void *vl_api_mpls_route_add_del_reply_t_print (vl_api_mpls_route_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_route_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_mpls_fib_dump_t_print (vl_api_mpls_fib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_mpls_fib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_mpls_fib_details_t_print  *****/

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_mpls_ip_bind_unbind_t_endian (vl_api_mpls_ip_bind_unbind_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->mb_mpls_table_id = clib_net_to_host_u32(a->mb_mpls_table_id);
    a->mb_label = clib_net_to_host_u32(a->mb_label);
    a->mb_ip_table_id = clib_net_to_host_u32(a->mb_ip_table_id);
    /* a->mb_create_table_if_needed = a->mb_create_table_if_needed (no-op) */
    /* a->mb_is_bind = a->mb_is_bind (no-op) */
    /* a->mb_is_ip4 = a->mb_is_ip4 (no-op) */
    /* a->mb_address_length = a->mb_address_length (no-op) */
    /* a->mb_address[0..15] = a->mb_address[0..15] (no-op) */
}

static inline void vl_api_mpls_ip_bind_unbind_reply_t_endian (vl_api_mpls_ip_bind_unbind_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_mpls_tunnel_add_del_t_endian (vl_api_mpls_tunnel_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->mt_sw_if_index = clib_net_to_host_u32(a->mt_sw_if_index);
    /* a->mt_is_add = a->mt_is_add (no-op) */
    /* a->mt_l2_only = a->mt_l2_only (no-op) */
    /* a->mt_is_multicast = a->mt_is_multicast (no-op) */
    /* a->mt_next_hop_proto_is_ip4 = a->mt_next_hop_proto_is_ip4 (no-op) */
    /* a->mt_next_hop_weight = a->mt_next_hop_weight (no-op) */
    /* a->mt_next_hop_preference = a->mt_next_hop_preference (no-op) */
    /* a->mt_next_hop[0..15] = a->mt_next_hop[0..15] (no-op) */
    /* a->mt_next_hop_n_out_labels = a->mt_next_hop_n_out_labels (no-op) */
    a->mt_next_hop_sw_if_index = clib_net_to_host_u32(a->mt_next_hop_sw_if_index);
    a->mt_next_hop_table_id = clib_net_to_host_u32(a->mt_next_hop_table_id);
}

static inline void vl_api_mpls_tunnel_add_del_reply_t_endian (vl_api_mpls_tunnel_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_mpls_tunnel_dump_t_endian (vl_api_mpls_tunnel_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->tunnel_index = clib_net_to_host_u32(a->tunnel_index);
}

/***** manual: vl_api_fib_path2_t_endian  *****/

/***** manual: vl_api_mpls_tunnel_details_t_endian  *****/

static inline void vl_api_mpls_table_add_del_t_endian (vl_api_mpls_table_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->mt_table_id = clib_net_to_host_u32(a->mt_table_id);
    /* a->mt_is_add = a->mt_is_add (no-op) */
    /* a->mt_name[0..63] = a->mt_name[0..63] (no-op) */
}

static inline void vl_api_mpls_table_add_del_reply_t_endian (vl_api_mpls_table_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_mpls_route_add_del_t_endian (vl_api_mpls_route_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->mr_label = clib_net_to_host_u32(a->mr_label);
    /* a->mr_eos = a->mr_eos (no-op) */
    a->mr_table_id = clib_net_to_host_u32(a->mr_table_id);
    a->mr_classify_table_index = clib_net_to_host_u32(a->mr_classify_table_index);
    /* a->mr_create_table_if_needed = a->mr_create_table_if_needed (no-op) */
    /* a->mr_is_add = a->mr_is_add (no-op) */
    /* a->mr_is_classify = a->mr_is_classify (no-op) */
    /* a->mr_is_multicast = a->mr_is_multicast (no-op) */
    /* a->mr_is_multipath = a->mr_is_multipath (no-op) */
    /* a->mr_is_resolve_host = a->mr_is_resolve_host (no-op) */
    /* a->mr_is_resolve_attached = a->mr_is_resolve_attached (no-op) */
    /* a->mr_is_interface_rx = a->mr_is_interface_rx (no-op) */
    /* a->mr_is_rpf_id = a->mr_is_rpf_id (no-op) */
    /* a->mr_next_hop_proto = a->mr_next_hop_proto (no-op) */
    /* a->mr_next_hop_weight = a->mr_next_hop_weight (no-op) */
    /* a->mr_next_hop_preference = a->mr_next_hop_preference (no-op) */
    /* a->mr_next_hop[0..15] = a->mr_next_hop[0..15] (no-op) */
    /* a->mr_next_hop_n_out_labels = a->mr_next_hop_n_out_labels (no-op) */
    a->mr_next_hop_sw_if_index = clib_net_to_host_u32(a->mr_next_hop_sw_if_index);
    a->mr_next_hop_table_id = clib_net_to_host_u32(a->mr_next_hop_table_id);
    a->mr_next_hop_via_label = clib_net_to_host_u32(a->mr_next_hop_via_label);
}

static inline void vl_api_mpls_route_add_del_reply_t_endian (vl_api_mpls_route_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_mpls_fib_dump_t_endian (vl_api_mpls_fib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_mpls_fib_details_t_endian  *****/

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(mpls.api, 0x0d26f5f6)

#endif

