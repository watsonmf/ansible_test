#ifndef __included_gre_api_json
#define __included_gre_api_json

#include <stdlib.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <vapi/vapi_internal.h>
#include <vapi/vapi.h>
#include <vapi/vapi_dbg.h>

#ifdef __cplusplus
extern "C" {
#endif
#include <vapi/vpe.api.vapi.h>

extern vapi_msg_id_t vapi_msg_id_gre_tunnel_details;
extern vapi_msg_id_t vapi_msg_id_gre_add_del_tunnel;
extern vapi_msg_id_t vapi_msg_id_gre_add_del_tunnel_reply;
extern vapi_msg_id_t vapi_msg_id_gre_tunnel_dump;

#define DEFINE_VAPI_MSG_IDS_GRE_API_JSON\
  vapi_msg_id_t vapi_msg_id_gre_tunnel_details;\
  vapi_msg_id_t vapi_msg_id_gre_add_del_tunnel;\
  vapi_msg_id_t vapi_msg_id_gre_add_del_tunnel_reply;\
  vapi_msg_id_t vapi_msg_id_gre_tunnel_dump;


typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index;
  u8 is_ipv6;
  u8 teb;
  u8 src_address[16];
  u8 dst_address[16];
  u32 outer_fib_id; 
} vapi_payload_gre_tunnel_details;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_gre_tunnel_details payload;
} vapi_msg_gre_tunnel_details;

typedef struct __attribute__ ((__packed__)) {
  u8 is_add;
  u8 is_ipv6;
  u8 teb;
  u8 src_address[16];
  u8 dst_address[16];
  u32 outer_fib_id; 
} vapi_payload_gre_add_del_tunnel;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_gre_add_del_tunnel payload;
} vapi_msg_gre_add_del_tunnel;

typedef struct __attribute__ ((__packed__)) {
  i32 retval;
  u32 sw_if_index; 
} vapi_payload_gre_add_del_tunnel_reply;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header1_t header;
  vapi_payload_gre_add_del_tunnel_reply payload;
} vapi_msg_gre_add_del_tunnel_reply;

typedef struct __attribute__ ((__packed__)) {
  u32 sw_if_index; 
} vapi_payload_gre_tunnel_dump;

typedef struct __attribute__ ((__packed__)) {
  vapi_type_msg_header2_t header;
  vapi_payload_gre_tunnel_dump payload;
} vapi_msg_gre_tunnel_dump;


static inline void vapi_msg_gre_tunnel_details_payload_hton(vapi_payload_gre_tunnel_details *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
  payload->outer_fib_id = htobe32(payload->outer_fib_id);
}

static inline void vapi_msg_gre_tunnel_details_payload_ntoh(vapi_payload_gre_tunnel_details *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
  payload->outer_fib_id = be32toh(payload->outer_fib_id);
}

static inline uword vapi_calc_gre_tunnel_details_msg_size(vapi_msg_gre_tunnel_details *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_gre_tunnel_details_hton(vapi_msg_gre_tunnel_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_tunnel_details'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_gre_tunnel_details_payload_hton(&msg->payload);
}

static inline void vapi_msg_gre_tunnel_details_ntoh(vapi_msg_gre_tunnel_details *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_tunnel_details'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_gre_tunnel_details_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_gre_add_del_tunnel_payload_hton(vapi_payload_gre_add_del_tunnel *payload)
{
  payload->outer_fib_id = htobe32(payload->outer_fib_id);
}

static inline void vapi_msg_gre_add_del_tunnel_payload_ntoh(vapi_payload_gre_add_del_tunnel *payload)
{
  payload->outer_fib_id = be32toh(payload->outer_fib_id);
}

static inline uword vapi_calc_gre_add_del_tunnel_msg_size(vapi_msg_gre_add_del_tunnel *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_gre_add_del_tunnel_hton(vapi_msg_gre_add_del_tunnel *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_add_del_tunnel'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_gre_add_del_tunnel_payload_hton(&msg->payload);
}

static inline void vapi_msg_gre_add_del_tunnel_ntoh(vapi_msg_gre_add_del_tunnel *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_add_del_tunnel'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_gre_add_del_tunnel_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_gre_add_del_tunnel_reply_payload_hton(vapi_payload_gre_add_del_tunnel_reply *payload)
{
  payload->retval = htobe32(payload->retval);
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_gre_add_del_tunnel_reply_payload_ntoh(vapi_payload_gre_add_del_tunnel_reply *payload)
{
  payload->retval = be32toh(payload->retval);
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_gre_add_del_tunnel_reply_msg_size(vapi_msg_gre_add_del_tunnel_reply *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_gre_add_del_tunnel_reply_hton(vapi_msg_gre_add_del_tunnel_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_add_del_tunnel_reply'@%p to big endian", msg);
  vapi_type_msg_header1_t_hton(&msg->header);
  vapi_msg_gre_add_del_tunnel_reply_payload_hton(&msg->payload);
}

static inline void vapi_msg_gre_add_del_tunnel_reply_ntoh(vapi_msg_gre_add_del_tunnel_reply *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_add_del_tunnel_reply'@%p to host byte order", msg);
  vapi_type_msg_header1_t_ntoh(&msg->header);
  vapi_msg_gre_add_del_tunnel_reply_payload_ntoh(&msg->payload);
}

static inline void vapi_msg_gre_tunnel_dump_payload_hton(vapi_payload_gre_tunnel_dump *payload)
{
  payload->sw_if_index = htobe32(payload->sw_if_index);
}

static inline void vapi_msg_gre_tunnel_dump_payload_ntoh(vapi_payload_gre_tunnel_dump *payload)
{
  payload->sw_if_index = be32toh(payload->sw_if_index);
}

static inline uword vapi_calc_gre_tunnel_dump_msg_size(vapi_msg_gre_tunnel_dump *msg)
{
  return sizeof(*msg);
}

static inline void vapi_msg_gre_tunnel_dump_hton(vapi_msg_gre_tunnel_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_tunnel_dump'@%p to big endian", msg);
  vapi_type_msg_header2_t_hton(&msg->header);
  vapi_msg_gre_tunnel_dump_payload_hton(&msg->payload);
}

static inline void vapi_msg_gre_tunnel_dump_ntoh(vapi_msg_gre_tunnel_dump *msg)
{
  VAPI_DBG("Swapping `vapi_msg_gre_tunnel_dump'@%p to host byte order", msg);
  vapi_type_msg_header2_t_ntoh(&msg->header);
  vapi_msg_gre_tunnel_dump_payload_ntoh(&msg->payload);
}

static inline vapi_msg_gre_add_del_tunnel* vapi_alloc_gre_add_del_tunnel(struct vapi_ctx_s *ctx)
{
  vapi_msg_gre_add_del_tunnel *msg = NULL;
  const size_t size = sizeof(vapi_msg_gre_add_del_tunnel);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_gre_add_del_tunnel*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_gre_add_del_tunnel);

  return msg;
}

static inline vapi_error_e vapi_gre_add_del_tunnel(struct vapi_ctx_s *ctx,
  vapi_msg_gre_add_del_tunnel *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_gre_add_del_tunnel_reply *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_gre_add_del_tunnel_hton(msg);
  if (VAPI_OK == (rv = vapi_send (ctx, msg))) {
    vapi_store_request(ctx, req_context, false, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_gre_add_del_tunnel_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}


static inline vapi_msg_gre_tunnel_dump* vapi_alloc_gre_tunnel_dump(struct vapi_ctx_s *ctx)
{
  vapi_msg_gre_tunnel_dump *msg = NULL;
  const size_t size = sizeof(vapi_msg_gre_tunnel_dump);
  /* cast here required to play nicely with C++ world ... */
  msg = (vapi_msg_gre_tunnel_dump*)vapi_msg_alloc(ctx, size);
  if (!msg) {
    return NULL;
  }
  msg->header.client_index = vapi_get_client_index(ctx);
  msg->header.context = 0;
  msg->header._vl_msg_id = vapi_lookup_vl_msg_id(ctx, vapi_msg_id_gre_tunnel_dump);

  return msg;
}

static inline vapi_error_e vapi_gre_tunnel_dump(struct vapi_ctx_s *ctx,
  vapi_msg_gre_tunnel_dump *msg,
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx,
                           void *callback_ctx,
                           vapi_error_e rv,
                           bool is_last,
                           vapi_payload_gre_tunnel_details *reply),
  void *callback_ctx)
{
  if (!msg || !callback) {
    return VAPI_EINVAL;
  }
  if (vapi_is_nonblocking(ctx) && vapi_requests_full(ctx)) {
    return VAPI_EAGAIN;
  }
  vapi_error_e rv;
  if (VAPI_OK != (rv = vapi_producer_lock (ctx))) {
    return rv;
  }
  u32 req_context = vapi_gen_req_context(ctx);
  msg->header.context = req_context;
  vapi_msg_gre_tunnel_dump_hton(msg);
  if (VAPI_OK == (rv = vapi_send_with_control_ping (ctx, msg, req_context))) {
    vapi_store_request(ctx, req_context, true, (vapi_cb_t)callback, callback_ctx);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
    if (vapi_is_nonblocking(ctx)) {
      rv = VAPI_OK;
    } else {
      rv = vapi_dispatch(ctx);
    }
  } else {
    vapi_msg_gre_tunnel_dump_ntoh(msg);
    if (VAPI_OK != vapi_producer_unlock (ctx)) {
      abort (); /* this really shouldn't happen */
    }
  }
  return rv;
}



static void __attribute__((constructor)) __vapi_constructor_gre_tunnel_details()
{
  static const char name[] = "gre_tunnel_details";
  static const char name_with_crc[] = "gre_tunnel_details_dd1d50aa";
  static vapi_message_desc_t __vapi_metadata_gre_tunnel_details = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_gre_tunnel_details, payload),
    sizeof(vapi_msg_gre_tunnel_details),
    (generic_swap_fn_t)vapi_msg_gre_tunnel_details_hton,
    (generic_swap_fn_t)vapi_msg_gre_tunnel_details_ntoh,
    ~0,
  };

  vapi_msg_id_gre_tunnel_details = vapi_register_msg(&__vapi_metadata_gre_tunnel_details);
  VAPI_DBG("Assigned msg id %d to gre_tunnel_details", vapi_msg_id_gre_tunnel_details);
}

static void __attribute__((constructor)) __vapi_constructor_gre_add_del_tunnel()
{
  static const char name[] = "gre_add_del_tunnel";
  static const char name_with_crc[] = "gre_add_del_tunnel_8ab92528";
  static vapi_message_desc_t __vapi_metadata_gre_add_del_tunnel = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_gre_add_del_tunnel, payload),
    sizeof(vapi_msg_gre_add_del_tunnel),
    (generic_swap_fn_t)vapi_msg_gre_add_del_tunnel_hton,
    (generic_swap_fn_t)vapi_msg_gre_add_del_tunnel_ntoh,
    ~0,
  };

  vapi_msg_id_gre_add_del_tunnel = vapi_register_msg(&__vapi_metadata_gre_add_del_tunnel);
  VAPI_DBG("Assigned msg id %d to gre_add_del_tunnel", vapi_msg_id_gre_add_del_tunnel);
}

static void __attribute__((constructor)) __vapi_constructor_gre_add_del_tunnel_reply()
{
  static const char name[] = "gre_add_del_tunnel_reply";
  static const char name_with_crc[] = "gre_add_del_tunnel_reply_754a5956";
  static vapi_message_desc_t __vapi_metadata_gre_add_del_tunnel_reply = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header1_t, context),
    offsetof(vapi_msg_gre_add_del_tunnel_reply, payload),
    sizeof(vapi_msg_gre_add_del_tunnel_reply),
    (generic_swap_fn_t)vapi_msg_gre_add_del_tunnel_reply_hton,
    (generic_swap_fn_t)vapi_msg_gre_add_del_tunnel_reply_ntoh,
    ~0,
  };

  vapi_msg_id_gre_add_del_tunnel_reply = vapi_register_msg(&__vapi_metadata_gre_add_del_tunnel_reply);
  VAPI_DBG("Assigned msg id %d to gre_add_del_tunnel_reply", vapi_msg_id_gre_add_del_tunnel_reply);
}

static void __attribute__((constructor)) __vapi_constructor_gre_tunnel_dump()
{
  static const char name[] = "gre_tunnel_dump";
  static const char name_with_crc[] = "gre_tunnel_dump_23d04dc0";
  static vapi_message_desc_t __vapi_metadata_gre_tunnel_dump = {
    name,
    sizeof(name) - 1,
    name_with_crc,
    sizeof(name_with_crc) - 1,
    true,
    offsetof(vapi_type_msg_header2_t, context),
    offsetof(vapi_msg_gre_tunnel_dump, payload),
    sizeof(vapi_msg_gre_tunnel_dump),
    (generic_swap_fn_t)vapi_msg_gre_tunnel_dump_hton,
    (generic_swap_fn_t)vapi_msg_gre_tunnel_dump_ntoh,
    ~0,
  };

  vapi_msg_id_gre_tunnel_dump = vapi_register_msg(&__vapi_metadata_gre_tunnel_dump);
  VAPI_DBG("Assigned msg id %d to gre_tunnel_dump", vapi_msg_id_gre_tunnel_dump);
}


static inline void vapi_set_vapi_msg_gre_tunnel_details_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_gre_tunnel_details *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_gre_tunnel_details, (vapi_event_cb)callback, callback_ctx);
};

static inline void vapi_set_vapi_msg_gre_add_del_tunnel_reply_event_cb (
  struct vapi_ctx_s *ctx, 
  vapi_error_e (*callback)(struct vapi_ctx_s *ctx, void *callback_ctx, vapi_payload_gre_add_del_tunnel_reply *payload),
  void *callback_ctx)
{
  vapi_set_event_cb(ctx, vapi_msg_id_gre_add_del_tunnel_reply, (vapi_event_cb)callback, callback_ctx);
};


#ifdef __cplusplus
}
#endif

#endif
