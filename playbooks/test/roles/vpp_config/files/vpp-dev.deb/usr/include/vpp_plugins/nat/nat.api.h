/*
 * VLIB API definitions Wed Nov 15 17:05:07 2017
 * Input file: nat/nat.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from nat/nat.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_SNAT_ADD_ADDRESS_RANGE, vl_api_snat_add_address_range_t_handler)
vl_msg_id(VL_API_SNAT_ADD_ADDRESS_RANGE_REPLY, vl_api_snat_add_address_range_reply_t_handler)
vl_msg_id(VL_API_SNAT_ADDRESS_DUMP, vl_api_snat_address_dump_t_handler)
vl_msg_id(VL_API_SNAT_ADDRESS_DETAILS, vl_api_snat_address_details_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADD_DEL_FEATURE, vl_api_snat_interface_add_del_feature_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADD_DEL_FEATURE_REPLY, vl_api_snat_interface_add_del_feature_reply_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_DUMP, vl_api_snat_interface_dump_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_DETAILS, vl_api_snat_interface_details_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADD_DEL_OUTPUT_FEATURE, vl_api_snat_interface_add_del_output_feature_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADD_DEL_OUTPUT_FEATURE_REPLY, vl_api_snat_interface_add_del_output_feature_reply_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_OUTPUT_FEATURE_DUMP, vl_api_snat_interface_output_feature_dump_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_OUTPUT_FEATURE_DETAILS, vl_api_snat_interface_output_feature_details_t_handler)
vl_msg_id(VL_API_SNAT_ADD_STATIC_MAPPING, vl_api_snat_add_static_mapping_t_handler)
vl_msg_id(VL_API_SNAT_ADD_STATIC_MAPPING_REPLY, vl_api_snat_add_static_mapping_reply_t_handler)
vl_msg_id(VL_API_SNAT_STATIC_MAPPING_DUMP, vl_api_snat_static_mapping_dump_t_handler)
vl_msg_id(VL_API_SNAT_STATIC_MAPPING_DETAILS, vl_api_snat_static_mapping_details_t_handler)
vl_msg_id(VL_API_SNAT_CONTROL_PING, vl_api_snat_control_ping_t_handler)
vl_msg_id(VL_API_SNAT_CONTROL_PING_REPLY, vl_api_snat_control_ping_reply_t_handler)
vl_msg_id(VL_API_SNAT_SHOW_CONFIG, vl_api_snat_show_config_t_handler)
vl_msg_id(VL_API_SNAT_SHOW_CONFIG_REPLY, vl_api_snat_show_config_reply_t_handler)
vl_msg_id(VL_API_SNAT_SET_WORKERS, vl_api_snat_set_workers_t_handler)
vl_msg_id(VL_API_SNAT_SET_WORKERS_REPLY, vl_api_snat_set_workers_reply_t_handler)
vl_msg_id(VL_API_SNAT_WORKER_DUMP, vl_api_snat_worker_dump_t_handler)
vl_msg_id(VL_API_SNAT_WORKER_DETAILS, vl_api_snat_worker_details_t_handler)
vl_msg_id(VL_API_SNAT_ADD_DEL_INTERFACE_ADDR, vl_api_snat_add_del_interface_addr_t_handler)
vl_msg_id(VL_API_SNAT_ADD_DEL_INTERFACE_ADDR_REPLY, vl_api_snat_add_del_interface_addr_reply_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADDR_DUMP, vl_api_snat_interface_addr_dump_t_handler)
vl_msg_id(VL_API_SNAT_INTERFACE_ADDR_DETAILS, vl_api_snat_interface_addr_details_t_handler)
vl_msg_id(VL_API_SNAT_IPFIX_ENABLE_DISABLE, vl_api_snat_ipfix_enable_disable_t_handler)
vl_msg_id(VL_API_SNAT_IPFIX_ENABLE_DISABLE_REPLY, vl_api_snat_ipfix_enable_disable_reply_t_handler)
vl_msg_id(VL_API_SNAT_USER_DUMP, vl_api_snat_user_dump_t_handler)
vl_msg_id(VL_API_SNAT_USER_DETAILS, vl_api_snat_user_details_t_handler)
vl_msg_id(VL_API_SNAT_USER_SESSION_DUMP, vl_api_snat_user_session_dump_t_handler)
vl_msg_id(VL_API_SNAT_USER_SESSION_DETAILS, vl_api_snat_user_session_details_t_handler)
vl_msg_id(VL_API_SNAT_ADD_DET_MAP, vl_api_snat_add_det_map_t_handler)
vl_msg_id(VL_API_SNAT_ADD_DET_MAP_REPLY, vl_api_snat_add_det_map_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_FORWARD, vl_api_snat_det_forward_t_handler)
vl_msg_id(VL_API_SNAT_DET_FORWARD_REPLY, vl_api_snat_det_forward_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_REVERSE, vl_api_snat_det_reverse_t_handler)
vl_msg_id(VL_API_SNAT_DET_REVERSE_REPLY, vl_api_snat_det_reverse_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_MAP_DUMP, vl_api_snat_det_map_dump_t_handler)
vl_msg_id(VL_API_SNAT_DET_MAP_DETAILS, vl_api_snat_det_map_details_t_handler)
vl_msg_id(VL_API_SNAT_DET_SET_TIMEOUTS, vl_api_snat_det_set_timeouts_t_handler)
vl_msg_id(VL_API_SNAT_DET_SET_TIMEOUTS_REPLY, vl_api_snat_det_set_timeouts_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_GET_TIMEOUTS, vl_api_snat_det_get_timeouts_t_handler)
vl_msg_id(VL_API_SNAT_DET_GET_TIMEOUTS_REPLY, vl_api_snat_det_get_timeouts_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_CLOSE_SESSION_OUT, vl_api_snat_det_close_session_out_t_handler)
vl_msg_id(VL_API_SNAT_DET_CLOSE_SESSION_OUT_REPLY, vl_api_snat_det_close_session_out_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_CLOSE_SESSION_IN, vl_api_snat_det_close_session_in_t_handler)
vl_msg_id(VL_API_SNAT_DET_CLOSE_SESSION_IN_REPLY, vl_api_snat_det_close_session_in_reply_t_handler)
vl_msg_id(VL_API_SNAT_DET_SESSION_DUMP, vl_api_snat_det_session_dump_t_handler)
vl_msg_id(VL_API_SNAT_DET_SESSION_DETAILS, vl_api_snat_det_session_details_t_handler)
vl_msg_id(VL_API_NAT_CONTROL_PING, vl_api_nat_control_ping_t_handler)
vl_msg_id(VL_API_NAT_CONTROL_PING_REPLY, vl_api_nat_control_ping_reply_t_handler)
vl_msg_id(VL_API_NAT_SHOW_CONFIG, vl_api_nat_show_config_t_handler)
vl_msg_id(VL_API_NAT_SHOW_CONFIG_REPLY, vl_api_nat_show_config_reply_t_handler)
vl_msg_id(VL_API_NAT_SET_WORKERS, vl_api_nat_set_workers_t_handler)
vl_msg_id(VL_API_NAT_SET_WORKERS_REPLY, vl_api_nat_set_workers_reply_t_handler)
vl_msg_id(VL_API_NAT_WORKER_DUMP, vl_api_nat_worker_dump_t_handler)
vl_msg_id(VL_API_NAT_WORKER_DETAILS, vl_api_nat_worker_details_t_handler)
vl_msg_id(VL_API_NAT_IPFIX_ENABLE_DISABLE, vl_api_nat_ipfix_enable_disable_t_handler)
vl_msg_id(VL_API_NAT_IPFIX_ENABLE_DISABLE_REPLY, vl_api_nat_ipfix_enable_disable_reply_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_ADDRESS_RANGE, vl_api_nat44_add_del_address_range_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_ADDRESS_RANGE_REPLY, vl_api_nat44_add_del_address_range_reply_t_handler)
vl_msg_id(VL_API_NAT44_ADDRESS_DUMP, vl_api_nat44_address_dump_t_handler)
vl_msg_id(VL_API_NAT44_ADDRESS_DETAILS, vl_api_nat44_address_details_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADD_DEL_FEATURE, vl_api_nat44_interface_add_del_feature_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADD_DEL_FEATURE_REPLY, vl_api_nat44_interface_add_del_feature_reply_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_DUMP, vl_api_nat44_interface_dump_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_DETAILS, vl_api_nat44_interface_details_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADD_DEL_OUTPUT_FEATURE, vl_api_nat44_interface_add_del_output_feature_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADD_DEL_OUTPUT_FEATURE_REPLY, vl_api_nat44_interface_add_del_output_feature_reply_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_OUTPUT_FEATURE_DUMP, vl_api_nat44_interface_output_feature_dump_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_OUTPUT_FEATURE_DETAILS, vl_api_nat44_interface_output_feature_details_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_STATIC_MAPPING, vl_api_nat44_add_del_static_mapping_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_STATIC_MAPPING_REPLY, vl_api_nat44_add_del_static_mapping_reply_t_handler)
vl_msg_id(VL_API_NAT44_STATIC_MAPPING_DUMP, vl_api_nat44_static_mapping_dump_t_handler)
vl_msg_id(VL_API_NAT44_STATIC_MAPPING_DETAILS, vl_api_nat44_static_mapping_details_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_INTERFACE_ADDR, vl_api_nat44_add_del_interface_addr_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_INTERFACE_ADDR_REPLY, vl_api_nat44_add_del_interface_addr_reply_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADDR_DUMP, vl_api_nat44_interface_addr_dump_t_handler)
vl_msg_id(VL_API_NAT44_INTERFACE_ADDR_DETAILS, vl_api_nat44_interface_addr_details_t_handler)
vl_msg_id(VL_API_NAT44_USER_DUMP, vl_api_nat44_user_dump_t_handler)
vl_msg_id(VL_API_NAT44_USER_DETAILS, vl_api_nat44_user_details_t_handler)
vl_msg_id(VL_API_NAT44_USER_SESSION_DUMP, vl_api_nat44_user_session_dump_t_handler)
vl_msg_id(VL_API_NAT44_USER_SESSION_DETAILS, vl_api_nat44_user_session_details_t_handler)
/* typeonly: nat44_lb_addr_port */
vl_msg_id(VL_API_NAT44_ADD_DEL_LB_STATIC_MAPPING, vl_api_nat44_add_del_lb_static_mapping_t_handler)
vl_msg_id(VL_API_NAT44_ADD_DEL_LB_STATIC_MAPPING_REPLY, vl_api_nat44_add_del_lb_static_mapping_reply_t_handler)
vl_msg_id(VL_API_NAT44_LB_STATIC_MAPPING_DUMP, vl_api_nat44_lb_static_mapping_dump_t_handler)
vl_msg_id(VL_API_NAT44_LB_STATIC_MAPPING_DETAILS, vl_api_nat44_lb_static_mapping_details_t_handler)
vl_msg_id(VL_API_NAT_DET_ADD_DEL_MAP, vl_api_nat_det_add_del_map_t_handler)
vl_msg_id(VL_API_NAT_DET_ADD_DEL_MAP_REPLY, vl_api_nat_det_add_del_map_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_FORWARD, vl_api_nat_det_forward_t_handler)
vl_msg_id(VL_API_NAT_DET_FORWARD_REPLY, vl_api_nat_det_forward_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_REVERSE, vl_api_nat_det_reverse_t_handler)
vl_msg_id(VL_API_NAT_DET_REVERSE_REPLY, vl_api_nat_det_reverse_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_MAP_DUMP, vl_api_nat_det_map_dump_t_handler)
vl_msg_id(VL_API_NAT_DET_MAP_DETAILS, vl_api_nat_det_map_details_t_handler)
vl_msg_id(VL_API_NAT_DET_SET_TIMEOUTS, vl_api_nat_det_set_timeouts_t_handler)
vl_msg_id(VL_API_NAT_DET_SET_TIMEOUTS_REPLY, vl_api_nat_det_set_timeouts_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_GET_TIMEOUTS, vl_api_nat_det_get_timeouts_t_handler)
vl_msg_id(VL_API_NAT_DET_GET_TIMEOUTS_REPLY, vl_api_nat_det_get_timeouts_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_CLOSE_SESSION_OUT, vl_api_nat_det_close_session_out_t_handler)
vl_msg_id(VL_API_NAT_DET_CLOSE_SESSION_OUT_REPLY, vl_api_nat_det_close_session_out_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_CLOSE_SESSION_IN, vl_api_nat_det_close_session_in_t_handler)
vl_msg_id(VL_API_NAT_DET_CLOSE_SESSION_IN_REPLY, vl_api_nat_det_close_session_in_reply_t_handler)
vl_msg_id(VL_API_NAT_DET_SESSION_DUMP, vl_api_nat_det_session_dump_t_handler)
vl_msg_id(VL_API_NAT_DET_SESSION_DETAILS, vl_api_nat_det_session_details_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_POOL_ADDR_RANGE, vl_api_nat64_add_del_pool_addr_range_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_POOL_ADDR_RANGE_REPLY, vl_api_nat64_add_del_pool_addr_range_reply_t_handler)
vl_msg_id(VL_API_NAT64_POOL_ADDR_DUMP, vl_api_nat64_pool_addr_dump_t_handler)
vl_msg_id(VL_API_NAT64_POOL_ADDR_DETAILS, vl_api_nat64_pool_addr_details_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_INTERFACE, vl_api_nat64_add_del_interface_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_INTERFACE_REPLY, vl_api_nat64_add_del_interface_reply_t_handler)
vl_msg_id(VL_API_NAT64_INTERFACE_DUMP, vl_api_nat64_interface_dump_t_handler)
vl_msg_id(VL_API_NAT64_INTERFACE_DETAILS, vl_api_nat64_interface_details_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_STATIC_BIB, vl_api_nat64_add_del_static_bib_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_STATIC_BIB_REPLY, vl_api_nat64_add_del_static_bib_reply_t_handler)
vl_msg_id(VL_API_NAT64_BIB_DUMP, vl_api_nat64_bib_dump_t_handler)
vl_msg_id(VL_API_NAT64_BIB_DETAILS, vl_api_nat64_bib_details_t_handler)
vl_msg_id(VL_API_NAT64_SET_TIMEOUTS, vl_api_nat64_set_timeouts_t_handler)
vl_msg_id(VL_API_NAT64_SET_TIMEOUTS_REPLY, vl_api_nat64_set_timeouts_reply_t_handler)
vl_msg_id(VL_API_NAT64_GET_TIMEOUTS, vl_api_nat64_get_timeouts_t_handler)
vl_msg_id(VL_API_NAT64_GET_TIMEOUTS_REPLY, vl_api_nat64_get_timeouts_reply_t_handler)
vl_msg_id(VL_API_NAT64_ST_DUMP, vl_api_nat64_st_dump_t_handler)
vl_msg_id(VL_API_NAT64_ST_DETAILS, vl_api_nat64_st_details_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_PREFIX, vl_api_nat64_add_del_prefix_t_handler)
vl_msg_id(VL_API_NAT64_ADD_DEL_PREFIX_REPLY, vl_api_nat64_add_del_prefix_reply_t_handler)
vl_msg_id(VL_API_NAT64_PREFIX_DUMP, vl_api_nat64_prefix_dump_t_handler)
vl_msg_id(VL_API_NAT64_PREFIX_DETAILS, vl_api_nat64_prefix_details_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_snat_add_address_range_t, 1)
vl_msg_name(vl_api_snat_add_address_range_reply_t, 1)
vl_msg_name(vl_api_snat_address_dump_t, 1)
vl_msg_name(vl_api_snat_address_details_t, 1)
vl_msg_name(vl_api_snat_interface_add_del_feature_t, 1)
vl_msg_name(vl_api_snat_interface_add_del_feature_reply_t, 1)
vl_msg_name(vl_api_snat_interface_dump_t, 1)
vl_msg_name(vl_api_snat_interface_details_t, 1)
vl_msg_name(vl_api_snat_interface_add_del_output_feature_t, 1)
vl_msg_name(vl_api_snat_interface_add_del_output_feature_reply_t, 1)
vl_msg_name(vl_api_snat_interface_output_feature_dump_t, 1)
vl_msg_name(vl_api_snat_interface_output_feature_details_t, 1)
vl_msg_name(vl_api_snat_add_static_mapping_t, 1)
vl_msg_name(vl_api_snat_add_static_mapping_reply_t, 1)
vl_msg_name(vl_api_snat_static_mapping_dump_t, 1)
vl_msg_name(vl_api_snat_static_mapping_details_t, 1)
vl_msg_name(vl_api_snat_control_ping_t, 1)
vl_msg_name(vl_api_snat_control_ping_reply_t, 1)
vl_msg_name(vl_api_snat_show_config_t, 1)
vl_msg_name(vl_api_snat_show_config_reply_t, 1)
vl_msg_name(vl_api_snat_set_workers_t, 1)
vl_msg_name(vl_api_snat_set_workers_reply_t, 1)
vl_msg_name(vl_api_snat_worker_dump_t, 1)
vl_msg_name(vl_api_snat_worker_details_t, 1)
vl_msg_name(vl_api_snat_add_del_interface_addr_t, 1)
vl_msg_name(vl_api_snat_add_del_interface_addr_reply_t, 1)
vl_msg_name(vl_api_snat_interface_addr_dump_t, 1)
vl_msg_name(vl_api_snat_interface_addr_details_t, 1)
vl_msg_name(vl_api_snat_ipfix_enable_disable_t, 1)
vl_msg_name(vl_api_snat_ipfix_enable_disable_reply_t, 1)
vl_msg_name(vl_api_snat_user_dump_t, 1)
vl_msg_name(vl_api_snat_user_details_t, 1)
vl_msg_name(vl_api_snat_user_session_dump_t, 1)
vl_msg_name(vl_api_snat_user_session_details_t, 1)
vl_msg_name(vl_api_snat_add_det_map_t, 1)
vl_msg_name(vl_api_snat_add_det_map_reply_t, 1)
vl_msg_name(vl_api_snat_det_forward_t, 1)
vl_msg_name(vl_api_snat_det_forward_reply_t, 1)
vl_msg_name(vl_api_snat_det_reverse_t, 1)
vl_msg_name(vl_api_snat_det_reverse_reply_t, 1)
vl_msg_name(vl_api_snat_det_map_dump_t, 1)
vl_msg_name(vl_api_snat_det_map_details_t, 1)
vl_msg_name(vl_api_snat_det_set_timeouts_t, 1)
vl_msg_name(vl_api_snat_det_set_timeouts_reply_t, 1)
vl_msg_name(vl_api_snat_det_get_timeouts_t, 1)
vl_msg_name(vl_api_snat_det_get_timeouts_reply_t, 1)
vl_msg_name(vl_api_snat_det_close_session_out_t, 1)
vl_msg_name(vl_api_snat_det_close_session_out_reply_t, 1)
vl_msg_name(vl_api_snat_det_close_session_in_t, 1)
vl_msg_name(vl_api_snat_det_close_session_in_reply_t, 1)
vl_msg_name(vl_api_snat_det_session_dump_t, 1)
vl_msg_name(vl_api_snat_det_session_details_t, 1)
vl_msg_name(vl_api_nat_control_ping_t, 1)
vl_msg_name(vl_api_nat_control_ping_reply_t, 1)
vl_msg_name(vl_api_nat_show_config_t, 1)
vl_msg_name(vl_api_nat_show_config_reply_t, 1)
vl_msg_name(vl_api_nat_set_workers_t, 1)
vl_msg_name(vl_api_nat_set_workers_reply_t, 1)
vl_msg_name(vl_api_nat_worker_dump_t, 1)
vl_msg_name(vl_api_nat_worker_details_t, 1)
vl_msg_name(vl_api_nat_ipfix_enable_disable_t, 1)
vl_msg_name(vl_api_nat_ipfix_enable_disable_reply_t, 1)
vl_msg_name(vl_api_nat44_add_del_address_range_t, 1)
vl_msg_name(vl_api_nat44_add_del_address_range_reply_t, 1)
vl_msg_name(vl_api_nat44_address_dump_t, 1)
vl_msg_name(vl_api_nat44_address_details_t, 1)
vl_msg_name(vl_api_nat44_interface_add_del_feature_t, 1)
vl_msg_name(vl_api_nat44_interface_add_del_feature_reply_t, 1)
vl_msg_name(vl_api_nat44_interface_dump_t, 1)
vl_msg_name(vl_api_nat44_interface_details_t, 1)
vl_msg_name(vl_api_nat44_interface_add_del_output_feature_t, 1)
vl_msg_name(vl_api_nat44_interface_add_del_output_feature_reply_t, 1)
vl_msg_name(vl_api_nat44_interface_output_feature_dump_t, 1)
vl_msg_name(vl_api_nat44_interface_output_feature_details_t, 1)
vl_msg_name(vl_api_nat44_add_del_static_mapping_t, 1)
vl_msg_name(vl_api_nat44_add_del_static_mapping_reply_t, 1)
vl_msg_name(vl_api_nat44_static_mapping_dump_t, 1)
vl_msg_name(vl_api_nat44_static_mapping_details_t, 1)
vl_msg_name(vl_api_nat44_add_del_interface_addr_t, 1)
vl_msg_name(vl_api_nat44_add_del_interface_addr_reply_t, 1)
vl_msg_name(vl_api_nat44_interface_addr_dump_t, 1)
vl_msg_name(vl_api_nat44_interface_addr_details_t, 1)
vl_msg_name(vl_api_nat44_user_dump_t, 1)
vl_msg_name(vl_api_nat44_user_details_t, 1)
vl_msg_name(vl_api_nat44_user_session_dump_t, 1)
vl_msg_name(vl_api_nat44_user_session_details_t, 1)
/* typeonly: nat44_lb_addr_port */
vl_msg_name(vl_api_nat44_add_del_lb_static_mapping_t, 1)
vl_msg_name(vl_api_nat44_add_del_lb_static_mapping_reply_t, 1)
vl_msg_name(vl_api_nat44_lb_static_mapping_dump_t, 1)
vl_msg_name(vl_api_nat44_lb_static_mapping_details_t, 1)
vl_msg_name(vl_api_nat_det_add_del_map_t, 1)
vl_msg_name(vl_api_nat_det_add_del_map_reply_t, 1)
vl_msg_name(vl_api_nat_det_forward_t, 1)
vl_msg_name(vl_api_nat_det_forward_reply_t, 1)
vl_msg_name(vl_api_nat_det_reverse_t, 1)
vl_msg_name(vl_api_nat_det_reverse_reply_t, 1)
vl_msg_name(vl_api_nat_det_map_dump_t, 1)
vl_msg_name(vl_api_nat_det_map_details_t, 1)
vl_msg_name(vl_api_nat_det_set_timeouts_t, 1)
vl_msg_name(vl_api_nat_det_set_timeouts_reply_t, 1)
vl_msg_name(vl_api_nat_det_get_timeouts_t, 1)
vl_msg_name(vl_api_nat_det_get_timeouts_reply_t, 1)
vl_msg_name(vl_api_nat_det_close_session_out_t, 1)
vl_msg_name(vl_api_nat_det_close_session_out_reply_t, 1)
vl_msg_name(vl_api_nat_det_close_session_in_t, 1)
vl_msg_name(vl_api_nat_det_close_session_in_reply_t, 1)
vl_msg_name(vl_api_nat_det_session_dump_t, 1)
vl_msg_name(vl_api_nat_det_session_details_t, 1)
vl_msg_name(vl_api_nat64_add_del_pool_addr_range_t, 1)
vl_msg_name(vl_api_nat64_add_del_pool_addr_range_reply_t, 1)
vl_msg_name(vl_api_nat64_pool_addr_dump_t, 1)
vl_msg_name(vl_api_nat64_pool_addr_details_t, 1)
vl_msg_name(vl_api_nat64_add_del_interface_t, 1)
vl_msg_name(vl_api_nat64_add_del_interface_reply_t, 1)
vl_msg_name(vl_api_nat64_interface_dump_t, 1)
vl_msg_name(vl_api_nat64_interface_details_t, 1)
vl_msg_name(vl_api_nat64_add_del_static_bib_t, 1)
vl_msg_name(vl_api_nat64_add_del_static_bib_reply_t, 1)
vl_msg_name(vl_api_nat64_bib_dump_t, 1)
vl_msg_name(vl_api_nat64_bib_details_t, 1)
vl_msg_name(vl_api_nat64_set_timeouts_t, 1)
vl_msg_name(vl_api_nat64_set_timeouts_reply_t, 1)
vl_msg_name(vl_api_nat64_get_timeouts_t, 1)
vl_msg_name(vl_api_nat64_get_timeouts_reply_t, 1)
vl_msg_name(vl_api_nat64_st_dump_t, 1)
vl_msg_name(vl_api_nat64_st_details_t, 1)
vl_msg_name(vl_api_nat64_add_del_prefix_t, 1)
vl_msg_name(vl_api_nat64_add_del_prefix_reply_t, 1)
vl_msg_name(vl_api_nat64_prefix_dump_t, 1)
vl_msg_name(vl_api_nat64_prefix_details_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_nat \
_(VL_API_SNAT_ADD_ADDRESS_RANGE, snat_add_address_range, d45f0a85) \
_(VL_API_SNAT_ADD_ADDRESS_RANGE_REPLY, snat_add_address_range_reply, 7d360766) \
_(VL_API_SNAT_ADDRESS_DUMP, snat_address_dump, 27c92402) \
_(VL_API_SNAT_ADDRESS_DETAILS, snat_address_details, f4e07104) \
_(VL_API_SNAT_INTERFACE_ADD_DEL_FEATURE, snat_interface_add_del_feature, dd74ea24) \
_(VL_API_SNAT_INTERFACE_ADD_DEL_FEATURE_REPLY, snat_interface_add_del_feature_reply, abd1e17f) \
_(VL_API_SNAT_INTERFACE_DUMP, snat_interface_dump, 01fe9590) \
_(VL_API_SNAT_INTERFACE_DETAILS, snat_interface_details, 8e43ab7a) \
_(VL_API_SNAT_INTERFACE_ADD_DEL_OUTPUT_FEATURE, snat_interface_add_del_output_feature, 30f11708) \
_(VL_API_SNAT_INTERFACE_ADD_DEL_OUTPUT_FEATURE_REPLY, snat_interface_add_del_output_feature_reply, 731bfbcb) \
_(VL_API_SNAT_INTERFACE_OUTPUT_FEATURE_DUMP, snat_interface_output_feature_dump, aa907749) \
_(VL_API_SNAT_INTERFACE_OUTPUT_FEATURE_DETAILS, snat_interface_output_feature_details, d47ddb87) \
_(VL_API_SNAT_ADD_STATIC_MAPPING, snat_add_static_mapping, d478ee49) \
_(VL_API_SNAT_ADD_STATIC_MAPPING_REPLY, snat_add_static_mapping_reply, c9db5568) \
_(VL_API_SNAT_STATIC_MAPPING_DUMP, snat_static_mapping_dump, 84172d2b) \
_(VL_API_SNAT_STATIC_MAPPING_DETAILS, snat_static_mapping_details, 5e4d17bf) \
_(VL_API_SNAT_CONTROL_PING, snat_control_ping, 7a3d60f6) \
_(VL_API_SNAT_CONTROL_PING_REPLY, snat_control_ping_reply, 979a5618) \
_(VL_API_SNAT_SHOW_CONFIG, snat_show_config, 2c6077c4) \
_(VL_API_SNAT_SHOW_CONFIG_REPLY, snat_show_config_reply, bf9c4060) \
_(VL_API_SNAT_SET_WORKERS, snat_set_workers, e884f45e) \
_(VL_API_SNAT_SET_WORKERS_REPLY, snat_set_workers_reply, 47fb5f11) \
_(VL_API_SNAT_WORKER_DUMP, snat_worker_dump, b7593228) \
_(VL_API_SNAT_WORKER_DETAILS, snat_worker_details, 6a1d1344) \
_(VL_API_SNAT_ADD_DEL_INTERFACE_ADDR, snat_add_del_interface_addr, 42b97914) \
_(VL_API_SNAT_ADD_DEL_INTERFACE_ADDR_REPLY, snat_add_del_interface_addr_reply, 8d0be39e) \
_(VL_API_SNAT_INTERFACE_ADDR_DUMP, snat_interface_addr_dump, 3e801286) \
_(VL_API_SNAT_INTERFACE_ADDR_DETAILS, snat_interface_addr_details, d65481ed) \
_(VL_API_SNAT_IPFIX_ENABLE_DISABLE, snat_ipfix_enable_disable, 88f422c2) \
_(VL_API_SNAT_IPFIX_ENABLE_DISABLE_REPLY, snat_ipfix_enable_disable_reply, a7f6c343) \
_(VL_API_SNAT_USER_DUMP, snat_user_dump, 062dc900) \
_(VL_API_SNAT_USER_DETAILS, snat_user_details, fe7dad8e) \
_(VL_API_SNAT_USER_SESSION_DUMP, snat_user_session_dump, 98bd1a88) \
_(VL_API_SNAT_USER_SESSION_DETAILS, snat_user_session_details, 1a632582) \
_(VL_API_SNAT_ADD_DET_MAP, snat_add_det_map, b62c5cfd) \
_(VL_API_SNAT_ADD_DET_MAP_REPLY, snat_add_det_map_reply, d84be59c) \
_(VL_API_SNAT_DET_FORWARD, snat_det_forward, 8584635a) \
_(VL_API_SNAT_DET_FORWARD_REPLY, snat_det_forward_reply, c04ce963) \
_(VL_API_SNAT_DET_REVERSE, snat_det_reverse, f6c78383) \
_(VL_API_SNAT_DET_REVERSE_REPLY, snat_det_reverse_reply, 0b0c08d5) \
_(VL_API_SNAT_DET_MAP_DUMP, snat_det_map_dump, 9da7fd51) \
_(VL_API_SNAT_DET_MAP_DETAILS, snat_det_map_details, 0b0ddd08) \
_(VL_API_SNAT_DET_SET_TIMEOUTS, snat_det_set_timeouts, fe713877) \
_(VL_API_SNAT_DET_SET_TIMEOUTS_REPLY, snat_det_set_timeouts_reply, 194bb7e2) \
_(VL_API_SNAT_DET_GET_TIMEOUTS, snat_det_get_timeouts, 834fa3bc) \
_(VL_API_SNAT_DET_GET_TIMEOUTS_REPLY, snat_det_get_timeouts_reply, 4d03d12e) \
_(VL_API_SNAT_DET_CLOSE_SESSION_OUT, snat_det_close_session_out, aacd5d95) \
_(VL_API_SNAT_DET_CLOSE_SESSION_OUT_REPLY, snat_det_close_session_out_reply, a9997082) \
_(VL_API_SNAT_DET_CLOSE_SESSION_IN, snat_det_close_session_in, 170dc301) \
_(VL_API_SNAT_DET_CLOSE_SESSION_IN_REPLY, snat_det_close_session_in_reply, 1150e58b) \
_(VL_API_SNAT_DET_SESSION_DUMP, snat_det_session_dump, e412e169) \
_(VL_API_SNAT_DET_SESSION_DETAILS, snat_det_session_details, 6e9cddb1) \
_(VL_API_NAT_CONTROL_PING, nat_control_ping, 96e6a834) \
_(VL_API_NAT_CONTROL_PING_REPLY, nat_control_ping_reply, 2d86a59b) \
_(VL_API_NAT_SHOW_CONFIG, nat_show_config, f1e6587b) \
_(VL_API_NAT_SHOW_CONFIG_REPLY, nat_show_config_reply, 4a456e3a) \
_(VL_API_NAT_SET_WORKERS, nat_set_workers, f7b85189) \
_(VL_API_NAT_SET_WORKERS_REPLY, nat_set_workers_reply, 9a7d70ae) \
_(VL_API_NAT_WORKER_DUMP, nat_worker_dump, 6adf1d97) \
_(VL_API_NAT_WORKER_DETAILS, nat_worker_details, d001e0c7) \
_(VL_API_NAT_IPFIX_ENABLE_DISABLE, nat_ipfix_enable_disable, c1b2fbba) \
_(VL_API_NAT_IPFIX_ENABLE_DISABLE_REPLY, nat_ipfix_enable_disable_reply, 3bb820c4) \
_(VL_API_NAT44_ADD_DEL_ADDRESS_RANGE, nat44_add_del_address_range, 1ca67820) \
_(VL_API_NAT44_ADD_DEL_ADDRESS_RANGE_REPLY, nat44_add_del_address_range_reply, 4e9b159d) \
_(VL_API_NAT44_ADDRESS_DUMP, nat44_address_dump, e75a129a) \
_(VL_API_NAT44_ADDRESS_DETAILS, nat44_address_details, f4b08b70) \
_(VL_API_NAT44_INTERFACE_ADD_DEL_FEATURE, nat44_interface_add_del_feature, c5aa4c6e) \
_(VL_API_NAT44_INTERFACE_ADD_DEL_FEATURE_REPLY, nat44_interface_add_del_feature_reply, fefe38af) \
_(VL_API_NAT44_INTERFACE_DUMP, nat44_interface_dump, 4eae339a) \
_(VL_API_NAT44_INTERFACE_DETAILS, nat44_interface_details, c3f78d04) \
_(VL_API_NAT44_INTERFACE_ADD_DEL_OUTPUT_FEATURE, nat44_interface_add_del_output_feature, b819e4dd) \
_(VL_API_NAT44_INTERFACE_ADD_DEL_OUTPUT_FEATURE_REPLY, nat44_interface_add_del_output_feature_reply, afb362f5) \
_(VL_API_NAT44_INTERFACE_OUTPUT_FEATURE_DUMP, nat44_interface_output_feature_dump, e7245137) \
_(VL_API_NAT44_INTERFACE_OUTPUT_FEATURE_DETAILS, nat44_interface_output_feature_details, 119c7053) \
_(VL_API_NAT44_ADD_DEL_STATIC_MAPPING, nat44_add_del_static_mapping, 6e24fd82) \
_(VL_API_NAT44_ADD_DEL_STATIC_MAPPING_REPLY, nat44_add_del_static_mapping_reply, a30f3c34) \
_(VL_API_NAT44_STATIC_MAPPING_DUMP, nat44_static_mapping_dump, df3b078e) \
_(VL_API_NAT44_STATIC_MAPPING_DETAILS, nat44_static_mapping_details, fd6c218f) \
_(VL_API_NAT44_ADD_DEL_INTERFACE_ADDR, nat44_add_del_interface_addr, d194c451) \
_(VL_API_NAT44_ADD_DEL_INTERFACE_ADDR_REPLY, nat44_add_del_interface_addr_reply, 74d308ac) \
_(VL_API_NAT44_INTERFACE_ADDR_DUMP, nat44_interface_addr_dump, 65ac3823) \
_(VL_API_NAT44_INTERFACE_ADDR_DETAILS, nat44_interface_addr_details, 446b9c77) \
_(VL_API_NAT44_USER_DUMP, nat44_user_dump, bf92f8eb) \
_(VL_API_NAT44_USER_DETAILS, nat44_user_details, 77ce783b) \
_(VL_API_NAT44_USER_SESSION_DUMP, nat44_user_session_dump, 597cec3f) \
_(VL_API_NAT44_USER_SESSION_DETAILS, nat44_user_session_details, 9abeddd4) \
_(VL_API_NAT44_ADD_DEL_LB_STATIC_MAPPING, nat44_add_del_lb_static_mapping, e8ad23b1) \
_(VL_API_NAT44_ADD_DEL_LB_STATIC_MAPPING_REPLY, nat44_add_del_lb_static_mapping_reply, c24bab18) \
_(VL_API_NAT44_LB_STATIC_MAPPING_DUMP, nat44_lb_static_mapping_dump, 1ddda4c8) \
_(VL_API_NAT44_LB_STATIC_MAPPING_DETAILS, nat44_lb_static_mapping_details, 4663e4a4) \
_(VL_API_NAT_DET_ADD_DEL_MAP, nat_det_add_del_map, 477b07ed) \
_(VL_API_NAT_DET_ADD_DEL_MAP_REPLY, nat_det_add_del_map_reply, 2fa49765) \
_(VL_API_NAT_DET_FORWARD, nat_det_forward, 85b74d31) \
_(VL_API_NAT_DET_FORWARD_REPLY, nat_det_forward_reply, 037762b9) \
_(VL_API_NAT_DET_REVERSE, nat_det_reverse, bb55c1d1) \
_(VL_API_NAT_DET_REVERSE_REPLY, nat_det_reverse_reply, 61420be4) \
_(VL_API_NAT_DET_MAP_DUMP, nat_det_map_dump, 717c3593) \
_(VL_API_NAT_DET_MAP_DETAILS, nat_det_map_details, c403648b) \
_(VL_API_NAT_DET_SET_TIMEOUTS, nat_det_set_timeouts, f957576e) \
_(VL_API_NAT_DET_SET_TIMEOUTS_REPLY, nat_det_set_timeouts_reply, 17a80a73) \
_(VL_API_NAT_DET_GET_TIMEOUTS, nat_det_get_timeouts, 8dac1e2d) \
_(VL_API_NAT_DET_GET_TIMEOUTS_REPLY, nat_det_get_timeouts_reply, 4a25be37) \
_(VL_API_NAT_DET_CLOSE_SESSION_OUT, nat_det_close_session_out, fa5c6cc6) \
_(VL_API_NAT_DET_CLOSE_SESSION_OUT_REPLY, nat_det_close_session_out_reply, ff3961f2) \
_(VL_API_NAT_DET_CLOSE_SESSION_IN, nat_det_close_session_in, ff933811) \
_(VL_API_NAT_DET_CLOSE_SESSION_IN_REPLY, nat_det_close_session_in_reply, 8d1e060c) \
_(VL_API_NAT_DET_SESSION_DUMP, nat_det_session_dump, e265f99d) \
_(VL_API_NAT_DET_SESSION_DETAILS, nat_det_session_details, 7e7399c3) \
_(VL_API_NAT64_ADD_DEL_POOL_ADDR_RANGE, nat64_add_del_pool_addr_range, 669df3f0) \
_(VL_API_NAT64_ADD_DEL_POOL_ADDR_RANGE_REPLY, nat64_add_del_pool_addr_range_reply, 9c968408) \
_(VL_API_NAT64_POOL_ADDR_DUMP, nat64_pool_addr_dump, 4ab68b4e) \
_(VL_API_NAT64_POOL_ADDR_DETAILS, nat64_pool_addr_details, 235db4a3) \
_(VL_API_NAT64_ADD_DEL_INTERFACE, nat64_add_del_interface, df24a879) \
_(VL_API_NAT64_ADD_DEL_INTERFACE_REPLY, nat64_add_del_interface_reply, cfbb3de6) \
_(VL_API_NAT64_INTERFACE_DUMP, nat64_interface_dump, 039fac3f) \
_(VL_API_NAT64_INTERFACE_DETAILS, nat64_interface_details, 3d95fdbc) \
_(VL_API_NAT64_ADD_DEL_STATIC_BIB, nat64_add_del_static_bib, cb5fb6e9) \
_(VL_API_NAT64_ADD_DEL_STATIC_BIB_REPLY, nat64_add_del_static_bib_reply, 7045bd17) \
_(VL_API_NAT64_BIB_DUMP, nat64_bib_dump, d48143dd) \
_(VL_API_NAT64_BIB_DETAILS, nat64_bib_details, dc57f1a9) \
_(VL_API_NAT64_SET_TIMEOUTS, nat64_set_timeouts, 1b9f767e) \
_(VL_API_NAT64_SET_TIMEOUTS_REPLY, nat64_set_timeouts_reply, f8de0c6d) \
_(VL_API_NAT64_GET_TIMEOUTS, nat64_get_timeouts, 62da1833) \
_(VL_API_NAT64_GET_TIMEOUTS_REPLY, nat64_get_timeouts_reply, 3829fa1a) \
_(VL_API_NAT64_ST_DUMP, nat64_st_dump, df3cd00f) \
_(VL_API_NAT64_ST_DETAILS, nat64_st_details, 5ac62548) \
_(VL_API_NAT64_ADD_DEL_PREFIX, nat64_add_del_prefix, 1e126638) \
_(VL_API_NAT64_ADD_DEL_PREFIX_REPLY, nat64_add_del_prefix_reply, 098c2c7a) \
_(VL_API_NAT64_PREFIX_DUMP, nat64_prefix_dump, 333a751d) \
_(VL_API_NAT64_PREFIX_DETAILS, nat64_prefix_details, 521be2eb) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_snat_add_address_range {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 first_ip_address[16];
    u8 last_ip_address[16];
    u32 vrf_id;
    u8 is_add;
}) vl_api_snat_add_address_range_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_address_range_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_add_address_range_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_address_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_address_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_address_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ip4;
    u8 ip_address[16];
    u32 vrf_id;
}) vl_api_snat_address_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_add_del_feature {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_snat_interface_add_del_feature_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_add_del_feature_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_interface_add_del_feature_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_interface_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_snat_interface_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_add_del_output_feature {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_snat_interface_add_del_output_feature_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_add_del_output_feature_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_interface_add_del_output_feature_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_output_feature_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_interface_output_feature_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_output_feature_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_snat_interface_output_feature_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_static_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ip4;
    u8 addr_only;
    u8 local_ip_address[16];
    u8 external_ip_address[16];
    u8 protocol;
    u16 local_port;
    u16 external_port;
    u32 external_sw_if_index;
    u32 vrf_id;
}) vl_api_snat_add_static_mapping_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_static_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_add_static_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_static_mapping_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_static_mapping_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_static_mapping_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ip4;
    u8 addr_only;
    u8 local_ip_address[16];
    u8 external_ip_address[16];
    u8 protocol;
    u16 local_port;
    u16 external_port;
    u32 external_sw_if_index;
    u32 vrf_id;
}) vl_api_snat_static_mapping_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_control_ping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_control_ping_t;

typedef VL_API_PACKED(struct _vl_api_snat_control_ping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 client_index;
    u32 vpe_pid;
}) vl_api_snat_control_ping_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_show_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_show_config_t;

typedef VL_API_PACKED(struct _vl_api_snat_show_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 static_mapping_only;
    u8 static_mapping_connection_tracking;
    u8 deterministic;
    u32 translation_buckets;
    u32 translation_memory_size;
    u32 user_buckets;
    u32 user_memory_size;
    u32 max_translations_per_user;
    u32 outside_vrf_id;
    u32 inside_vrf_id;
}) vl_api_snat_show_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_set_workers {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 worker_mask;
}) vl_api_snat_set_workers_t;

typedef VL_API_PACKED(struct _vl_api_snat_set_workers_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_set_workers_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_worker_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_worker_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_worker_details {
    u16 _vl_msg_id;
    u32 context;
    u32 worker_index;
    u32 lcore_id;
    u8 name[64];
}) vl_api_snat_worker_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_del_interface_addr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_snat_add_del_interface_addr_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_del_interface_addr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_add_del_interface_addr_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_addr_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_interface_addr_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_interface_addr_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
}) vl_api_snat_interface_addr_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_ipfix_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 domain_id;
    u16 src_port;
    u8 enable;
}) vl_api_snat_ipfix_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_snat_ipfix_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_ipfix_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_user_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_user_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_user_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vrf_id;
    u8 is_ip4;
    u8 ip_address[16];
    u32 nsessions;
    u32 nstaticsessions;
}) vl_api_snat_user_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_user_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 ip_address[16];
    u32 vrf_id;
}) vl_api_snat_user_session_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_user_session_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ip4;
    u8 outside_ip_address[16];
    u16 outside_port;
    u8 inside_ip_address[16];
    u16 inside_port;
    u16 protocol;
    u8 is_static;
    u64 last_heard;
    u64 total_bytes;
    u32 total_pkts;
}) vl_api_snat_user_session_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_det_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_ip4;
    u8 addr_only;
    u8 in_addr[16];
    u8 in_plen;
    u8 out_addr[16];
    u8 out_plen;
}) vl_api_snat_add_det_map_t;

typedef VL_API_PACKED(struct _vl_api_snat_add_det_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_add_det_map_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_forward {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 in_addr[16];
}) vl_api_snat_det_forward_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_forward_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u16 out_port_lo;
    u16 out_port_hi;
    u8 is_ip4;
    u8 out_addr[16];
}) vl_api_snat_det_forward_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_reverse {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 out_port;
    u8 is_ip4;
    u8 out_addr[16];
}) vl_api_snat_det_reverse_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_reverse_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_ip4;
    u8 in_addr[16];
}) vl_api_snat_det_reverse_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_det_map_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_map_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_ip4;
    u8 in_addr[16];
    u8 in_plen;
    u8 out_addr[16];
    u8 out_plen;
    u32 sharing_ratio;
    u16 ports_per_host;
    u32 ses_num;
}) vl_api_snat_det_map_details_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_set_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 udp;
    u32 tcp_established;
    u32 tcp_transitory;
    u32 icmp;
}) vl_api_snat_det_set_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_set_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_det_set_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_get_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_snat_det_get_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_get_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 udp;
    u32 tcp_established;
    u32 tcp_transitory;
    u32 icmp;
}) vl_api_snat_det_get_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_close_session_out {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 out_addr[16];
    u16 out_port;
    u8 ext_addr[16];
    u16 ext_port;
}) vl_api_snat_det_close_session_out_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_close_session_out_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_det_close_session_out_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_close_session_in {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 in_addr[16];
    u16 in_port;
    u8 ext_addr[16];
    u16 ext_port;
}) vl_api_snat_det_close_session_in_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_close_session_in_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_snat_det_close_session_in_reply_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u8 user_addr[16];
}) vl_api_snat_det_session_dump_t;

typedef VL_API_PACKED(struct _vl_api_snat_det_session_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_ip4;
    u16 in_port;
    u8 ext_addr[16];
    u16 ext_port;
    u16 out_port;
    u8 state;
    u32 expire;
}) vl_api_snat_det_session_details_t;

typedef VL_API_PACKED(struct _vl_api_nat_control_ping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat_control_ping_t;

typedef VL_API_PACKED(struct _vl_api_nat_control_ping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 client_index;
    u32 vpe_pid;
}) vl_api_nat_control_ping_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_show_config {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat_show_config_t;

typedef VL_API_PACKED(struct _vl_api_nat_show_config_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 static_mapping_only;
    u8 static_mapping_connection_tracking;
    u8 deterministic;
    u32 translation_buckets;
    u32 translation_memory_size;
    u32 user_buckets;
    u32 user_memory_size;
    u32 max_translations_per_user;
    u32 outside_vrf_id;
    u32 inside_vrf_id;
}) vl_api_nat_show_config_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_set_workers {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 worker_mask;
}) vl_api_nat_set_workers_t;

typedef VL_API_PACKED(struct _vl_api_nat_set_workers_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_set_workers_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_worker_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat_worker_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat_worker_details {
    u16 _vl_msg_id;
    u32 context;
    u32 worker_index;
    u32 lcore_id;
    u8 name[64];
}) vl_api_nat_worker_details_t;

typedef VL_API_PACKED(struct _vl_api_nat_ipfix_enable_disable {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 domain_id;
    u16 src_port;
    u8 enable;
}) vl_api_nat_ipfix_enable_disable_t;

typedef VL_API_PACKED(struct _vl_api_nat_ipfix_enable_disable_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_ipfix_enable_disable_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_address_range {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 first_ip_address[4];
    u8 last_ip_address[4];
    u32 vrf_id;
    u8 is_add;
}) vl_api_nat44_add_del_address_range_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_address_range_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_add_del_address_range_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_address_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_address_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_address_details {
    u16 _vl_msg_id;
    u32 context;
    u8 ip_address[4];
    u32 vrf_id;
}) vl_api_nat44_address_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_add_del_feature {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat44_interface_add_del_feature_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_add_del_feature_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_interface_add_del_feature_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_interface_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat44_interface_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_add_del_output_feature {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat44_interface_add_del_output_feature_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_add_del_output_feature_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_interface_add_del_output_feature_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_output_feature_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_interface_output_feature_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_output_feature_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat44_interface_output_feature_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_static_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 addr_only;
    u8 local_ip_address[4];
    u8 external_ip_address[4];
    u8 protocol;
    u16 local_port;
    u16 external_port;
    u32 external_sw_if_index;
    u32 vrf_id;
}) vl_api_nat44_add_del_static_mapping_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_static_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_add_del_static_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_static_mapping_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_static_mapping_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_static_mapping_details {
    u16 _vl_msg_id;
    u32 context;
    u8 addr_only;
    u8 local_ip_address[4];
    u8 external_ip_address[4];
    u8 protocol;
    u16 local_port;
    u16 external_port;
    u32 external_sw_if_index;
    u32 vrf_id;
}) vl_api_nat44_static_mapping_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_interface_addr {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat44_add_del_interface_addr_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_interface_addr_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_add_del_interface_addr_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_addr_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_interface_addr_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_interface_addr_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
}) vl_api_nat44_interface_addr_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_user_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_user_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_user_details {
    u16 _vl_msg_id;
    u32 context;
    u32 vrf_id;
    u8 ip_address[4];
    u32 nsessions;
    u32 nstaticsessions;
}) vl_api_nat44_user_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_user_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 ip_address[4];
    u32 vrf_id;
}) vl_api_nat44_user_session_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_user_session_details {
    u16 _vl_msg_id;
    u32 context;
    u8 outside_ip_address[4];
    u16 outside_port;
    u8 inside_ip_address[4];
    u16 inside_port;
    u16 protocol;
    u8 is_static;
    u64 last_heard;
    u64 total_bytes;
    u32 total_pkts;
}) vl_api_nat44_user_session_details_t;

typedef VL_API_PACKED(struct _vl_api_nat44_lb_addr_port {
    u8 addr[4];
    u16 port;
    u8 probability;
}) vl_api_nat44_lb_addr_port_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_lb_static_mapping {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 external_addr[4];
    u16 external_port;
    u8 protocol;
    u32 vrf_id;
    u8 local_num;
    vl_api_nat44_lb_addr_port_t locals[0];
}) vl_api_nat44_add_del_lb_static_mapping_t;

typedef VL_API_PACKED(struct _vl_api_nat44_add_del_lb_static_mapping_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat44_add_del_lb_static_mapping_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat44_lb_static_mapping_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat44_lb_static_mapping_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat44_lb_static_mapping_details {
    u16 _vl_msg_id;
    u32 context;
    u8 external_addr[4];
    u16 external_port;
    u8 protocol;
    u32 vrf_id;
    u8 local_num;
    vl_api_nat44_lb_addr_port_t locals[0];
}) vl_api_nat44_lb_static_mapping_details_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_add_del_map {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u8 is_nat44;
    u8 addr_only;
    u8 in_addr[16];
    u8 in_plen;
    u8 out_addr[4];
    u8 out_plen;
}) vl_api_nat_det_add_del_map_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_add_del_map_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_det_add_del_map_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_forward {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_nat44;
    u8 in_addr[16];
}) vl_api_nat_det_forward_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_forward_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u16 out_port_lo;
    u16 out_port_hi;
    u8 out_addr[4];
}) vl_api_nat_det_forward_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_reverse {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 out_port;
    u8 out_addr[4];
}) vl_api_nat_det_reverse_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_reverse_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u8 is_nat44;
    u8 in_addr[16];
}) vl_api_nat_det_reverse_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_map_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat_det_map_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_map_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_nat44;
    u8 in_addr[16];
    u8 in_plen;
    u8 out_addr[4];
    u8 out_plen;
    u32 sharing_ratio;
    u16 ports_per_host;
    u32 ses_num;
}) vl_api_nat_det_map_details_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_set_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 udp;
    u32 tcp_established;
    u32 tcp_transitory;
    u32 icmp;
}) vl_api_nat_det_set_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_set_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_det_set_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_get_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat_det_get_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_get_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 udp;
    u32 tcp_established;
    u32 tcp_transitory;
    u32 icmp;
}) vl_api_nat_det_get_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_close_session_out {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 out_addr[4];
    u16 out_port;
    u8 ext_addr[4];
    u16 ext_port;
}) vl_api_nat_det_close_session_out_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_close_session_out_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_det_close_session_out_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_close_session_in {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_nat44;
    u8 in_addr[16];
    u16 in_port;
    u8 ext_addr[16];
    u16 ext_port;
}) vl_api_nat_det_close_session_in_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_close_session_in_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat_det_close_session_in_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_session_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_nat44;
    u8 user_addr[16];
}) vl_api_nat_det_session_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat_det_session_details {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u16 in_port;
    u8 ext_addr[4];
    u16 ext_port;
    u16 out_port;
    u8 state;
    u32 expire;
}) vl_api_nat_det_session_details_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_pool_addr_range {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 start_addr[4];
    u8 end_addr[4];
    u32 vrf_id;
    u8 is_add;
}) vl_api_nat64_add_del_pool_addr_range_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_pool_addr_range_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat64_add_del_pool_addr_range_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_pool_addr_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat64_pool_addr_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat64_pool_addr_details {
    u16 _vl_msg_id;
    u32 context;
    u8 address[4];
    u32 vrf_id;
}) vl_api_nat64_pool_addr_details_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_interface {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_inside;
    u8 is_add;
}) vl_api_nat64_add_del_interface_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_interface_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat64_add_del_interface_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_interface_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat64_interface_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat64_interface_details {
    u16 _vl_msg_id;
    u32 context;
    u8 is_inside;
    u32 sw_if_index;
}) vl_api_nat64_interface_details_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_static_bib {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 i_addr[16];
    u8 o_addr[4];
    u16 i_port;
    u16 o_port;
    u32 vrf_id;
    u8 proto;
    u8 is_add;
}) vl_api_nat64_add_del_static_bib_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_static_bib_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat64_add_del_static_bib_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_bib_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 proto;
}) vl_api_nat64_bib_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat64_bib_details {
    u16 _vl_msg_id;
    u32 context;
    u8 i_addr[16];
    u8 o_addr[4];
    u16 i_port;
    u16 o_port;
    u32 vrf_id;
    u8 proto;
    u8 is_static;
    u32 ses_num;
}) vl_api_nat64_bib_details_t;

typedef VL_API_PACKED(struct _vl_api_nat64_set_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 udp;
    u32 icmp;
    u32 tcp_trans;
    u32 tcp_est;
    u32 tcp_incoming_syn;
}) vl_api_nat64_set_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_nat64_set_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat64_set_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_get_timeouts {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat64_get_timeouts_t;

typedef VL_API_PACKED(struct _vl_api_nat64_get_timeouts_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 udp;
    u32 icmp;
    u32 tcp_trans;
    u32 tcp_est;
    u32 tcp_incoming_syn;
}) vl_api_nat64_get_timeouts_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_st_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 proto;
}) vl_api_nat64_st_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat64_st_details {
    u16 _vl_msg_id;
    u32 context;
    u8 il_addr[16];
    u8 ol_addr[4];
    u16 il_port;
    u16 ol_port;
    u8 ir_addr[16];
    u8 or_addr[4];
    u16 r_port;
    u32 vrf_id;
    u8 proto;
}) vl_api_nat64_st_details_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_prefix {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 prefix[16];
    u8 prefix_len;
    u32 vrf_id;
    u8 is_add;
}) vl_api_nat64_add_del_prefix_t;

typedef VL_API_PACKED(struct _vl_api_nat64_add_del_prefix_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_nat64_add_del_prefix_reply_t;

typedef VL_API_PACKED(struct _vl_api_nat64_prefix_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
}) vl_api_nat64_prefix_dump_t;

typedef VL_API_PACKED(struct _vl_api_nat64_prefix_details {
    u16 _vl_msg_id;
    u32 context;
    u8 prefix[16];
    u8 prefix_len;
    u32 vrf_id;
}) vl_api_nat64_prefix_details_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_snat_add_address_range_t_print (vl_api_snat_add_address_range_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_address_range_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "first_ip_address[%d]: %u\n", _i, a->first_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "last_ip_address[%d]: %u\n", _i, a->last_ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_snat_add_address_range_reply_t_print (vl_api_snat_add_address_range_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_address_range_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_address_dump_t_print (vl_api_snat_address_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_address_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_address_details_t_print (vl_api_snat_address_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_address_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_snat_interface_add_del_feature_t_print (vl_api_snat_interface_add_del_feature_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_add_del_feature_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_interface_add_del_feature_reply_t_print (vl_api_snat_interface_add_del_feature_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_add_del_feature_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_interface_dump_t_print (vl_api_snat_interface_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_interface_details_t_print (vl_api_snat_interface_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_interface_add_del_output_feature_t_print (vl_api_snat_interface_add_del_output_feature_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_add_del_output_feature_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_interface_add_del_output_feature_reply_t_print (vl_api_snat_interface_add_del_output_feature_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_add_del_output_feature_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_interface_output_feature_dump_t_print (vl_api_snat_interface_output_feature_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_output_feature_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_interface_output_feature_details_t_print (vl_api_snat_interface_output_feature_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_output_feature_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_add_static_mapping_t_print (vl_api_snat_add_static_mapping_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_static_mapping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_ip_address[%d]: %u\n", _i, a->local_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "external_ip_address[%d]: %u\n", _i, a->external_ip_address[_i]);
        }
    }
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "local_port: %u\n", (unsigned) a->local_port);
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "external_sw_if_index: %u\n", (unsigned) a->external_sw_if_index);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_snat_add_static_mapping_reply_t_print (vl_api_snat_add_static_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_static_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_static_mapping_dump_t_print (vl_api_snat_static_mapping_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_static_mapping_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_static_mapping_details_t_print (vl_api_snat_static_mapping_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_static_mapping_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "local_ip_address[%d]: %u\n", _i, a->local_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "external_ip_address[%d]: %u\n", _i, a->external_ip_address[_i]);
        }
    }
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "local_port: %u\n", (unsigned) a->local_port);
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "external_sw_if_index: %u\n", (unsigned) a->external_sw_if_index);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_snat_control_ping_t_print (vl_api_snat_control_ping_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_control_ping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_control_ping_reply_t_print (vl_api_snat_control_ping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_control_ping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "vpe_pid: %u\n", (unsigned) a->vpe_pid);
    return handle;
}

static inline void *vl_api_snat_show_config_t_print (vl_api_snat_show_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_show_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_show_config_reply_t_print (vl_api_snat_show_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_show_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "static_mapping_only: %u\n", (unsigned) a->static_mapping_only);
    vl_print(handle, "static_mapping_connection_tracking: %u\n", (unsigned) a->static_mapping_connection_tracking);
    vl_print(handle, "deterministic: %u\n", (unsigned) a->deterministic);
    vl_print(handle, "translation_buckets: %u\n", (unsigned) a->translation_buckets);
    vl_print(handle, "translation_memory_size: %u\n", (unsigned) a->translation_memory_size);
    vl_print(handle, "user_buckets: %u\n", (unsigned) a->user_buckets);
    vl_print(handle, "user_memory_size: %u\n", (unsigned) a->user_memory_size);
    vl_print(handle, "max_translations_per_user: %u\n", (unsigned) a->max_translations_per_user);
    vl_print(handle, "outside_vrf_id: %u\n", (unsigned) a->outside_vrf_id);
    vl_print(handle, "inside_vrf_id: %u\n", (unsigned) a->inside_vrf_id);
    return handle;
}

static inline void *vl_api_snat_set_workers_t_print (vl_api_snat_set_workers_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_set_workers_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "worker_mask: %llu\n", (long long) a->worker_mask);
    return handle;
}

static inline void *vl_api_snat_set_workers_reply_t_print (vl_api_snat_set_workers_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_set_workers_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_worker_dump_t_print (vl_api_snat_worker_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_worker_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_worker_details_t_print (vl_api_snat_worker_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_worker_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "worker_index: %u\n", (unsigned) a->worker_index);
    vl_print(handle, "lcore_id: %u\n", (unsigned) a->lcore_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_add_del_interface_addr_t_print (vl_api_snat_add_del_interface_addr_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_del_interface_addr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_add_del_interface_addr_reply_t_print (vl_api_snat_add_del_interface_addr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_del_interface_addr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_interface_addr_dump_t_print (vl_api_snat_interface_addr_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_addr_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_interface_addr_details_t_print (vl_api_snat_interface_addr_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_interface_addr_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_snat_ipfix_enable_disable_t_print (vl_api_snat_ipfix_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_ipfix_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_id: %u\n", (unsigned) a->domain_id);
    vl_print(handle, "src_port: %u\n", (unsigned) a->src_port);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_snat_ipfix_enable_disable_reply_t_print (vl_api_snat_ipfix_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_ipfix_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_user_dump_t_print (vl_api_snat_user_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_user_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_user_details_t_print (vl_api_snat_user_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_user_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "nsessions: %u\n", (unsigned) a->nsessions);
    vl_print(handle, "nstaticsessions: %u\n", (unsigned) a->nstaticsessions);
    return handle;
}

static inline void *vl_api_snat_user_session_dump_t_print (vl_api_snat_user_session_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_user_session_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_snat_user_session_details_t_print (vl_api_snat_user_session_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_user_session_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "outside_ip_address[%d]: %u\n", _i, a->outside_ip_address[_i]);
        }
    }
    vl_print(handle, "outside_port: %u\n", (unsigned) a->outside_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "inside_ip_address[%d]: %u\n", _i, a->inside_ip_address[_i]);
        }
    }
    vl_print(handle, "inside_port: %u\n", (unsigned) a->inside_port);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "is_static: %u\n", (unsigned) a->is_static);
    vl_print(handle, "last_heard: %llu\n", (long long) a->last_heard);
    vl_print(handle, "total_bytes: %llu\n", (long long) a->total_bytes);
    vl_print(handle, "total_pkts: %u\n", (unsigned) a->total_pkts);
    return handle;
}

static inline void *vl_api_snat_add_det_map_t_print (vl_api_snat_add_det_map_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_det_map_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_plen: %u\n", (unsigned) a->in_plen);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_plen: %u\n", (unsigned) a->out_plen);
    return handle;
}

static inline void *vl_api_snat_add_det_map_reply_t_print (vl_api_snat_add_det_map_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_add_det_map_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_det_forward_t_print (vl_api_snat_det_forward_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_forward_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_det_forward_reply_t_print (vl_api_snat_det_forward_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_forward_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "out_port_lo: %u\n", (unsigned) a->out_port_lo);
    vl_print(handle, "out_port_hi: %u\n", (unsigned) a->out_port_hi);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_det_reverse_t_print (vl_api_snat_det_reverse_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_reverse_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_det_reverse_reply_t_print (vl_api_snat_det_reverse_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_reverse_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_det_map_dump_t_print (vl_api_snat_det_map_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_map_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_det_map_details_t_print (vl_api_snat_det_map_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_map_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_plen: %u\n", (unsigned) a->in_plen);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_plen: %u\n", (unsigned) a->out_plen);
    vl_print(handle, "sharing_ratio: %u\n", (unsigned) a->sharing_ratio);
    vl_print(handle, "ports_per_host: %u\n", (unsigned) a->ports_per_host);
    vl_print(handle, "ses_num: %u\n", (unsigned) a->ses_num);
    return handle;
}

static inline void *vl_api_snat_det_set_timeouts_t_print (vl_api_snat_det_set_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_set_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "tcp_established: %u\n", (unsigned) a->tcp_established);
    vl_print(handle, "tcp_transitory: %u\n", (unsigned) a->tcp_transitory);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    return handle;
}

static inline void *vl_api_snat_det_set_timeouts_reply_t_print (vl_api_snat_det_set_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_set_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_det_get_timeouts_t_print (vl_api_snat_det_get_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_get_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_snat_det_get_timeouts_reply_t_print (vl_api_snat_det_get_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_get_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "tcp_established: %u\n", (unsigned) a->tcp_established);
    vl_print(handle, "tcp_transitory: %u\n", (unsigned) a->tcp_transitory);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    return handle;
}

static inline void *vl_api_snat_det_close_session_out_t_print (vl_api_snat_det_close_session_out_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_close_session_out_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    return handle;
}

static inline void *vl_api_snat_det_close_session_out_reply_t_print (vl_api_snat_det_close_session_out_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_close_session_out_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_det_close_session_in_t_print (vl_api_snat_det_close_session_in_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_close_session_in_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_port: %u\n", (unsigned) a->in_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    return handle;
}

static inline void *vl_api_snat_det_close_session_in_reply_t_print (vl_api_snat_det_close_session_in_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_close_session_in_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_snat_det_session_dump_t_print (vl_api_snat_det_session_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_session_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "user_addr[%d]: %u\n", _i, a->user_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_snat_det_session_details_t_print (vl_api_snat_det_session_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_snat_det_session_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_ip4: %u\n", (unsigned) a->is_ip4);
    vl_print(handle, "in_port: %u\n", (unsigned) a->in_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    vl_print(handle, "state: %u\n", (unsigned) a->state);
    vl_print(handle, "expire: %u\n", (unsigned) a->expire);
    return handle;
}

static inline void *vl_api_nat_control_ping_t_print (vl_api_nat_control_ping_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_control_ping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat_control_ping_reply_t_print (vl_api_nat_control_ping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_control_ping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "vpe_pid: %u\n", (unsigned) a->vpe_pid);
    return handle;
}

static inline void *vl_api_nat_show_config_t_print (vl_api_nat_show_config_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_show_config_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat_show_config_reply_t_print (vl_api_nat_show_config_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_show_config_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "static_mapping_only: %u\n", (unsigned) a->static_mapping_only);
    vl_print(handle, "static_mapping_connection_tracking: %u\n", (unsigned) a->static_mapping_connection_tracking);
    vl_print(handle, "deterministic: %u\n", (unsigned) a->deterministic);
    vl_print(handle, "translation_buckets: %u\n", (unsigned) a->translation_buckets);
    vl_print(handle, "translation_memory_size: %u\n", (unsigned) a->translation_memory_size);
    vl_print(handle, "user_buckets: %u\n", (unsigned) a->user_buckets);
    vl_print(handle, "user_memory_size: %u\n", (unsigned) a->user_memory_size);
    vl_print(handle, "max_translations_per_user: %u\n", (unsigned) a->max_translations_per_user);
    vl_print(handle, "outside_vrf_id: %u\n", (unsigned) a->outside_vrf_id);
    vl_print(handle, "inside_vrf_id: %u\n", (unsigned) a->inside_vrf_id);
    return handle;
}

static inline void *vl_api_nat_set_workers_t_print (vl_api_nat_set_workers_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_set_workers_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "worker_mask: %llu\n", (long long) a->worker_mask);
    return handle;
}

static inline void *vl_api_nat_set_workers_reply_t_print (vl_api_nat_set_workers_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_set_workers_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat_worker_dump_t_print (vl_api_nat_worker_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_worker_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat_worker_details_t_print (vl_api_nat_worker_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_worker_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "worker_index: %u\n", (unsigned) a->worker_index);
    vl_print(handle, "lcore_id: %u\n", (unsigned) a->lcore_id);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_ipfix_enable_disable_t_print (vl_api_nat_ipfix_enable_disable_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_ipfix_enable_disable_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "domain_id: %u\n", (unsigned) a->domain_id);
    vl_print(handle, "src_port: %u\n", (unsigned) a->src_port);
    vl_print(handle, "enable: %u\n", (unsigned) a->enable);
    return handle;
}

static inline void *vl_api_nat_ipfix_enable_disable_reply_t_print (vl_api_nat_ipfix_enable_disable_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_ipfix_enable_disable_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_add_del_address_range_t_print (vl_api_nat44_add_del_address_range_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_address_range_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "first_ip_address[%d]: %u\n", _i, a->first_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "last_ip_address[%d]: %u\n", _i, a->last_ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_nat44_add_del_address_range_reply_t_print (vl_api_nat44_add_del_address_range_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_address_range_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_address_dump_t_print (vl_api_nat44_address_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_address_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_address_details_t_print (vl_api_nat44_address_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_address_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_nat44_interface_add_del_feature_t_print (vl_api_nat44_interface_add_del_feature_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_add_del_feature_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_interface_add_del_feature_reply_t_print (vl_api_nat44_interface_add_del_feature_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_add_del_feature_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_interface_dump_t_print (vl_api_nat44_interface_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_interface_details_t_print (vl_api_nat44_interface_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_interface_add_del_output_feature_t_print (vl_api_nat44_interface_add_del_output_feature_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_add_del_output_feature_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_interface_add_del_output_feature_reply_t_print (vl_api_nat44_interface_add_del_output_feature_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_add_del_output_feature_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_interface_output_feature_dump_t_print (vl_api_nat44_interface_output_feature_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_output_feature_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_interface_output_feature_details_t_print (vl_api_nat44_interface_output_feature_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_output_feature_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_add_del_static_mapping_t_print (vl_api_nat44_add_del_static_mapping_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_static_mapping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "local_ip_address[%d]: %u\n", _i, a->local_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "external_ip_address[%d]: %u\n", _i, a->external_ip_address[_i]);
        }
    }
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "local_port: %u\n", (unsigned) a->local_port);
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "external_sw_if_index: %u\n", (unsigned) a->external_sw_if_index);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_nat44_add_del_static_mapping_reply_t_print (vl_api_nat44_add_del_static_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_static_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_static_mapping_dump_t_print (vl_api_nat44_static_mapping_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_static_mapping_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_static_mapping_details_t_print (vl_api_nat44_static_mapping_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_static_mapping_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "local_ip_address[%d]: %u\n", _i, a->local_ip_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "external_ip_address[%d]: %u\n", _i, a->external_ip_address[_i]);
        }
    }
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "local_port: %u\n", (unsigned) a->local_port);
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "external_sw_if_index: %u\n", (unsigned) a->external_sw_if_index);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_nat44_add_del_interface_addr_t_print (vl_api_nat44_add_del_interface_addr_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_interface_addr_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_add_del_interface_addr_reply_t_print (vl_api_nat44_add_del_interface_addr_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_interface_addr_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_interface_addr_dump_t_print (vl_api_nat44_interface_addr_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_addr_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_interface_addr_details_t_print (vl_api_nat44_interface_addr_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_interface_addr_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat44_user_dump_t_print (vl_api_nat44_user_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_user_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_user_details_t_print (vl_api_nat44_user_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_user_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "nsessions: %u\n", (unsigned) a->nsessions);
    vl_print(handle, "nstaticsessions: %u\n", (unsigned) a->nstaticsessions);
    return handle;
}

static inline void *vl_api_nat44_user_session_dump_t_print (vl_api_nat44_user_session_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_user_session_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ip_address[%d]: %u\n", _i, a->ip_address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_nat44_user_session_details_t_print (vl_api_nat44_user_session_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_user_session_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "outside_ip_address[%d]: %u\n", _i, a->outside_ip_address[_i]);
        }
    }
    vl_print(handle, "outside_port: %u\n", (unsigned) a->outside_port);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "inside_ip_address[%d]: %u\n", _i, a->inside_ip_address[_i]);
        }
    }
    vl_print(handle, "inside_port: %u\n", (unsigned) a->inside_port);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "is_static: %u\n", (unsigned) a->is_static);
    vl_print(handle, "last_heard: %llu\n", (long long) a->last_heard);
    vl_print(handle, "total_bytes: %llu\n", (long long) a->total_bytes);
    vl_print(handle, "total_pkts: %u\n", (unsigned) a->total_pkts);
    return handle;
}

static inline void *vl_api_nat44_lb_addr_port_t_print (vl_api_nat44_lb_addr_port_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_lb_addr_port_t:\n");
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "addr[%d]: %u\n", _i, a->addr[_i]);
        }
    }
    vl_print(handle, "port: %u\n", (unsigned) a->port);
    vl_print(handle, "probability: %u\n", (unsigned) a->probability);
    return handle;
}

static inline void *vl_api_nat44_add_del_lb_static_mapping_t_print (vl_api_nat44_add_del_lb_static_mapping_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_lb_static_mapping_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "external_addr[%d]: %u\n", _i, a->external_addr[_i]);
        }
    }
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "local_num: %u\n", (unsigned) a->local_num);
    vl_print(handle, "locals ----- \n");
    vl_api_nat44_lb_addr_port_t_print(a->locals, handle);
    vl_print(handle, "locals ----- END \n");
    return handle;
}

static inline void *vl_api_nat44_add_del_lb_static_mapping_reply_t_print (vl_api_nat44_add_del_lb_static_mapping_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_add_del_lb_static_mapping_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat44_lb_static_mapping_dump_t_print (vl_api_nat44_lb_static_mapping_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_lb_static_mapping_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat44_lb_static_mapping_details_t_print (vl_api_nat44_lb_static_mapping_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat44_lb_static_mapping_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "external_addr[%d]: %u\n", _i, a->external_addr[_i]);
        }
    }
    vl_print(handle, "external_port: %u\n", (unsigned) a->external_port);
    vl_print(handle, "protocol: %u\n", (unsigned) a->protocol);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "local_num: %u\n", (unsigned) a->local_num);
    vl_print(handle, "locals ----- \n");
    vl_api_nat44_lb_addr_port_t_print(a->locals, handle);
    vl_print(handle, "locals ----- END \n");
    return handle;
}

static inline void *vl_api_nat_det_add_del_map_t_print (vl_api_nat_det_add_del_map_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_add_del_map_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    vl_print(handle, "addr_only: %u\n", (unsigned) a->addr_only);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_plen: %u\n", (unsigned) a->in_plen);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_plen: %u\n", (unsigned) a->out_plen);
    return handle;
}

static inline void *vl_api_nat_det_add_del_map_reply_t_print (vl_api_nat_det_add_del_map_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_add_del_map_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat_det_forward_t_print (vl_api_nat_det_forward_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_forward_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_det_forward_reply_t_print (vl_api_nat_det_forward_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_forward_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "out_port_lo: %u\n", (unsigned) a->out_port_lo);
    vl_print(handle, "out_port_hi: %u\n", (unsigned) a->out_port_hi);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_det_reverse_t_print (vl_api_nat_det_reverse_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_reverse_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_det_reverse_reply_t_print (vl_api_nat_det_reverse_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_reverse_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_det_map_dump_t_print (vl_api_nat_det_map_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_map_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat_det_map_details_t_print (vl_api_nat_det_map_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_map_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_plen: %u\n", (unsigned) a->in_plen);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_plen: %u\n", (unsigned) a->out_plen);
    vl_print(handle, "sharing_ratio: %u\n", (unsigned) a->sharing_ratio);
    vl_print(handle, "ports_per_host: %u\n", (unsigned) a->ports_per_host);
    vl_print(handle, "ses_num: %u\n", (unsigned) a->ses_num);
    return handle;
}

static inline void *vl_api_nat_det_set_timeouts_t_print (vl_api_nat_det_set_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_set_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "tcp_established: %u\n", (unsigned) a->tcp_established);
    vl_print(handle, "tcp_transitory: %u\n", (unsigned) a->tcp_transitory);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    return handle;
}

static inline void *vl_api_nat_det_set_timeouts_reply_t_print (vl_api_nat_det_set_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_set_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat_det_get_timeouts_t_print (vl_api_nat_det_get_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_get_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat_det_get_timeouts_reply_t_print (vl_api_nat_det_get_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_get_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "tcp_established: %u\n", (unsigned) a->tcp_established);
    vl_print(handle, "tcp_transitory: %u\n", (unsigned) a->tcp_transitory);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    return handle;
}

static inline void *vl_api_nat_det_close_session_out_t_print (vl_api_nat_det_close_session_out_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_close_session_out_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "out_addr[%d]: %u\n", _i, a->out_addr[_i]);
        }
    }
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    return handle;
}

static inline void *vl_api_nat_det_close_session_out_reply_t_print (vl_api_nat_det_close_session_out_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_close_session_out_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat_det_close_session_in_t_print (vl_api_nat_det_close_session_in_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_close_session_in_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "in_addr[%d]: %u\n", _i, a->in_addr[_i]);
        }
    }
    vl_print(handle, "in_port: %u\n", (unsigned) a->in_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    return handle;
}

static inline void *vl_api_nat_det_close_session_in_reply_t_print (vl_api_nat_det_close_session_in_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_close_session_in_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat_det_session_dump_t_print (vl_api_nat_det_session_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_session_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_nat44: %u\n", (unsigned) a->is_nat44);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "user_addr[%d]: %u\n", _i, a->user_addr[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_nat_det_session_details_t_print (vl_api_nat_det_session_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat_det_session_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "in_port: %u\n", (unsigned) a->in_port);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ext_addr[%d]: %u\n", _i, a->ext_addr[_i]);
        }
    }
    vl_print(handle, "ext_port: %u\n", (unsigned) a->ext_port);
    vl_print(handle, "out_port: %u\n", (unsigned) a->out_port);
    vl_print(handle, "state: %u\n", (unsigned) a->state);
    vl_print(handle, "expire: %u\n", (unsigned) a->expire);
    return handle;
}

static inline void *vl_api_nat64_add_del_pool_addr_range_t_print (vl_api_nat64_add_del_pool_addr_range_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_pool_addr_range_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "start_addr[%d]: %u\n", _i, a->start_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "end_addr[%d]: %u\n", _i, a->end_addr[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_nat64_add_del_pool_addr_range_reply_t_print (vl_api_nat64_add_del_pool_addr_range_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_pool_addr_range_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat64_pool_addr_dump_t_print (vl_api_nat64_pool_addr_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_pool_addr_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat64_pool_addr_details_t_print (vl_api_nat64_pool_addr_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_pool_addr_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_nat64_add_del_interface_t_print (vl_api_nat64_add_del_interface_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_interface_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_nat64_add_del_interface_reply_t_print (vl_api_nat64_add_del_interface_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_interface_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat64_interface_dump_t_print (vl_api_nat64_interface_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_interface_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat64_interface_details_t_print (vl_api_nat64_interface_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_interface_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_inside: %u\n", (unsigned) a->is_inside);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_nat64_add_del_static_bib_t_print (vl_api_nat64_add_del_static_bib_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_static_bib_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "i_addr[%d]: %u\n", _i, a->i_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "o_addr[%d]: %u\n", _i, a->o_addr[_i]);
        }
    }
    vl_print(handle, "i_port: %u\n", (unsigned) a->i_port);
    vl_print(handle, "o_port: %u\n", (unsigned) a->o_port);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_nat64_add_del_static_bib_reply_t_print (vl_api_nat64_add_del_static_bib_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_static_bib_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat64_bib_dump_t_print (vl_api_nat64_bib_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_bib_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    return handle;
}

static inline void *vl_api_nat64_bib_details_t_print (vl_api_nat64_bib_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_bib_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "i_addr[%d]: %u\n", _i, a->i_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "o_addr[%d]: %u\n", _i, a->o_addr[_i]);
        }
    }
    vl_print(handle, "i_port: %u\n", (unsigned) a->i_port);
    vl_print(handle, "o_port: %u\n", (unsigned) a->o_port);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    vl_print(handle, "is_static: %u\n", (unsigned) a->is_static);
    vl_print(handle, "ses_num: %u\n", (unsigned) a->ses_num);
    return handle;
}

static inline void *vl_api_nat64_set_timeouts_t_print (vl_api_nat64_set_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_set_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    vl_print(handle, "tcp_trans: %u\n", (unsigned) a->tcp_trans);
    vl_print(handle, "tcp_est: %u\n", (unsigned) a->tcp_est);
    vl_print(handle, "tcp_incoming_syn: %u\n", (unsigned) a->tcp_incoming_syn);
    return handle;
}

static inline void *vl_api_nat64_set_timeouts_reply_t_print (vl_api_nat64_set_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_set_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat64_get_timeouts_t_print (vl_api_nat64_get_timeouts_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_get_timeouts_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat64_get_timeouts_reply_t_print (vl_api_nat64_get_timeouts_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_get_timeouts_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "udp: %u\n", (unsigned) a->udp);
    vl_print(handle, "icmp: %u\n", (unsigned) a->icmp);
    vl_print(handle, "tcp_trans: %u\n", (unsigned) a->tcp_trans);
    vl_print(handle, "tcp_est: %u\n", (unsigned) a->tcp_est);
    vl_print(handle, "tcp_incoming_syn: %u\n", (unsigned) a->tcp_incoming_syn);
    return handle;
}

static inline void *vl_api_nat64_st_dump_t_print (vl_api_nat64_st_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_st_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    return handle;
}

static inline void *vl_api_nat64_st_details_t_print (vl_api_nat64_st_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_st_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "il_addr[%d]: %u\n", _i, a->il_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "ol_addr[%d]: %u\n", _i, a->ol_addr[_i]);
        }
    }
    vl_print(handle, "il_port: %u\n", (unsigned) a->il_port);
    vl_print(handle, "ol_port: %u\n", (unsigned) a->ol_port);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "ir_addr[%d]: %u\n", _i, a->ir_addr[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 4; _i++) {
            vl_print(handle, "or_addr[%d]: %u\n", _i, a->or_addr[_i]);
        }
    }
    vl_print(handle, "r_port: %u\n", (unsigned) a->r_port);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "proto: %u\n", (unsigned) a->proto);
    return handle;
}

static inline void *vl_api_nat64_add_del_prefix_t_print (vl_api_nat64_add_del_prefix_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_prefix_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "prefix[%d]: %u\n", _i, a->prefix[_i]);
        }
    }
    vl_print(handle, "prefix_len: %u\n", (unsigned) a->prefix_len);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_nat64_add_del_prefix_reply_t_print (vl_api_nat64_add_del_prefix_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_add_del_prefix_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_nat64_prefix_dump_t_print (vl_api_nat64_prefix_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_prefix_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_nat64_prefix_details_t_print (vl_api_nat64_prefix_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_nat64_prefix_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "prefix[%d]: %u\n", _i, a->prefix[_i]);
        }
    }
    vl_print(handle, "prefix_len: %u\n", (unsigned) a->prefix_len);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_snat_add_address_range_t_endian (vl_api_snat_add_address_range_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->first_ip_address[0..15] = a->first_ip_address[0..15] (no-op) */
    /* a->last_ip_address[0..15] = a->last_ip_address[0..15] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_snat_add_address_range_reply_t_endian (vl_api_snat_add_address_range_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_address_dump_t_endian (vl_api_snat_address_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_address_details_t_endian (vl_api_snat_address_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_snat_interface_add_del_feature_t_endian (vl_api_snat_interface_add_del_feature_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_interface_add_del_feature_reply_t_endian (vl_api_snat_interface_add_del_feature_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_interface_dump_t_endian (vl_api_snat_interface_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_interface_details_t_endian (vl_api_snat_interface_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_interface_add_del_output_feature_t_endian (vl_api_snat_interface_add_del_output_feature_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_interface_add_del_output_feature_reply_t_endian (vl_api_snat_interface_add_del_output_feature_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_interface_output_feature_dump_t_endian (vl_api_snat_interface_output_feature_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_interface_output_feature_details_t_endian (vl_api_snat_interface_output_feature_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_add_static_mapping_t_endian (vl_api_snat_add_static_mapping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->addr_only = a->addr_only (no-op) */
    /* a->local_ip_address[0..15] = a->local_ip_address[0..15] (no-op) */
    /* a->external_ip_address[0..15] = a->external_ip_address[0..15] (no-op) */
    /* a->protocol = a->protocol (no-op) */
    a->local_port = clib_net_to_host_u16(a->local_port);
    a->external_port = clib_net_to_host_u16(a->external_port);
    a->external_sw_if_index = clib_net_to_host_u32(a->external_sw_if_index);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_snat_add_static_mapping_reply_t_endian (vl_api_snat_add_static_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_static_mapping_dump_t_endian (vl_api_snat_static_mapping_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_static_mapping_details_t_endian (vl_api_snat_static_mapping_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->addr_only = a->addr_only (no-op) */
    /* a->local_ip_address[0..15] = a->local_ip_address[0..15] (no-op) */
    /* a->external_ip_address[0..15] = a->external_ip_address[0..15] (no-op) */
    /* a->protocol = a->protocol (no-op) */
    a->local_port = clib_net_to_host_u16(a->local_port);
    a->external_port = clib_net_to_host_u16(a->external_port);
    a->external_sw_if_index = clib_net_to_host_u32(a->external_sw_if_index);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_snat_control_ping_t_endian (vl_api_snat_control_ping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_control_ping_reply_t_endian (vl_api_snat_control_ping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->vpe_pid = clib_net_to_host_u32(a->vpe_pid);
}

static inline void vl_api_snat_show_config_t_endian (vl_api_snat_show_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_show_config_reply_t_endian (vl_api_snat_show_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->static_mapping_only = a->static_mapping_only (no-op) */
    /* a->static_mapping_connection_tracking = a->static_mapping_connection_tracking (no-op) */
    /* a->deterministic = a->deterministic (no-op) */
    a->translation_buckets = clib_net_to_host_u32(a->translation_buckets);
    a->translation_memory_size = clib_net_to_host_u32(a->translation_memory_size);
    a->user_buckets = clib_net_to_host_u32(a->user_buckets);
    a->user_memory_size = clib_net_to_host_u32(a->user_memory_size);
    a->max_translations_per_user = clib_net_to_host_u32(a->max_translations_per_user);
    a->outside_vrf_id = clib_net_to_host_u32(a->outside_vrf_id);
    a->inside_vrf_id = clib_net_to_host_u32(a->inside_vrf_id);
}

static inline void vl_api_snat_set_workers_t_endian (vl_api_snat_set_workers_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->worker_mask = clib_net_to_host_u64(a->worker_mask);
}

static inline void vl_api_snat_set_workers_reply_t_endian (vl_api_snat_set_workers_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_worker_dump_t_endian (vl_api_snat_worker_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_worker_details_t_endian (vl_api_snat_worker_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->worker_index = clib_net_to_host_u32(a->worker_index);
    a->lcore_id = clib_net_to_host_u32(a->lcore_id);
    /* a->name[0..63] = a->name[0..63] (no-op) */
}

static inline void vl_api_snat_add_del_interface_addr_t_endian (vl_api_snat_add_del_interface_addr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_add_del_interface_addr_reply_t_endian (vl_api_snat_add_del_interface_addr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_interface_addr_dump_t_endian (vl_api_snat_interface_addr_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_interface_addr_details_t_endian (vl_api_snat_interface_addr_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_snat_ipfix_enable_disable_t_endian (vl_api_snat_ipfix_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_id = clib_net_to_host_u32(a->domain_id);
    a->src_port = clib_net_to_host_u16(a->src_port);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_snat_ipfix_enable_disable_reply_t_endian (vl_api_snat_ipfix_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_user_dump_t_endian (vl_api_snat_user_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_user_details_t_endian (vl_api_snat_user_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    a->nsessions = clib_net_to_host_u32(a->nsessions);
    a->nstaticsessions = clib_net_to_host_u32(a->nstaticsessions);
}

static inline void vl_api_snat_user_session_dump_t_endian (vl_api_snat_user_session_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->ip_address[0..15] = a->ip_address[0..15] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_snat_user_session_details_t_endian (vl_api_snat_user_session_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->outside_ip_address[0..15] = a->outside_ip_address[0..15] (no-op) */
    a->outside_port = clib_net_to_host_u16(a->outside_port);
    /* a->inside_ip_address[0..15] = a->inside_ip_address[0..15] (no-op) */
    a->inside_port = clib_net_to_host_u16(a->inside_port);
    a->protocol = clib_net_to_host_u16(a->protocol);
    /* a->is_static = a->is_static (no-op) */
    a->last_heard = clib_net_to_host_u64(a->last_heard);
    a->total_bytes = clib_net_to_host_u64(a->total_bytes);
    a->total_pkts = clib_net_to_host_u32(a->total_pkts);
}

static inline void vl_api_snat_add_det_map_t_endian (vl_api_snat_add_det_map_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->addr_only = a->addr_only (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    /* a->in_plen = a->in_plen (no-op) */
    /* a->out_addr[0..15] = a->out_addr[0..15] (no-op) */
    /* a->out_plen = a->out_plen (no-op) */
}

static inline void vl_api_snat_add_det_map_reply_t_endian (vl_api_snat_add_det_map_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_det_forward_t_endian (vl_api_snat_det_forward_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
}

static inline void vl_api_snat_det_forward_reply_t_endian (vl_api_snat_det_forward_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->out_port_lo = clib_net_to_host_u16(a->out_port_lo);
    a->out_port_hi = clib_net_to_host_u16(a->out_port_hi);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->out_addr[0..15] = a->out_addr[0..15] (no-op) */
}

static inline void vl_api_snat_det_reverse_t_endian (vl_api_snat_det_reverse_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->out_addr[0..15] = a->out_addr[0..15] (no-op) */
}

static inline void vl_api_snat_det_reverse_reply_t_endian (vl_api_snat_det_reverse_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
}

static inline void vl_api_snat_det_map_dump_t_endian (vl_api_snat_det_map_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_det_map_details_t_endian (vl_api_snat_det_map_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    /* a->in_plen = a->in_plen (no-op) */
    /* a->out_addr[0..15] = a->out_addr[0..15] (no-op) */
    /* a->out_plen = a->out_plen (no-op) */
    a->sharing_ratio = clib_net_to_host_u32(a->sharing_ratio);
    a->ports_per_host = clib_net_to_host_u16(a->ports_per_host);
    a->ses_num = clib_net_to_host_u32(a->ses_num);
}

static inline void vl_api_snat_det_set_timeouts_t_endian (vl_api_snat_det_set_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->udp = clib_net_to_host_u32(a->udp);
    a->tcp_established = clib_net_to_host_u32(a->tcp_established);
    a->tcp_transitory = clib_net_to_host_u32(a->tcp_transitory);
    a->icmp = clib_net_to_host_u32(a->icmp);
}

static inline void vl_api_snat_det_set_timeouts_reply_t_endian (vl_api_snat_det_set_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_det_get_timeouts_t_endian (vl_api_snat_det_get_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_snat_det_get_timeouts_reply_t_endian (vl_api_snat_det_get_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->udp = clib_net_to_host_u32(a->udp);
    a->tcp_established = clib_net_to_host_u32(a->tcp_established);
    a->tcp_transitory = clib_net_to_host_u32(a->tcp_transitory);
    a->icmp = clib_net_to_host_u32(a->icmp);
}

static inline void vl_api_snat_det_close_session_out_t_endian (vl_api_snat_det_close_session_out_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->out_addr[0..15] = a->out_addr[0..15] (no-op) */
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->ext_addr[0..15] = a->ext_addr[0..15] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
}

static inline void vl_api_snat_det_close_session_out_reply_t_endian (vl_api_snat_det_close_session_out_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_det_close_session_in_t_endian (vl_api_snat_det_close_session_in_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    a->in_port = clib_net_to_host_u16(a->in_port);
    /* a->ext_addr[0..15] = a->ext_addr[0..15] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
}

static inline void vl_api_snat_det_close_session_in_reply_t_endian (vl_api_snat_det_close_session_in_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_snat_det_session_dump_t_endian (vl_api_snat_det_session_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    /* a->user_addr[0..15] = a->user_addr[0..15] (no-op) */
}

static inline void vl_api_snat_det_session_details_t_endian (vl_api_snat_det_session_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_ip4 = a->is_ip4 (no-op) */
    a->in_port = clib_net_to_host_u16(a->in_port);
    /* a->ext_addr[0..15] = a->ext_addr[0..15] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->state = a->state (no-op) */
    a->expire = clib_net_to_host_u32(a->expire);
}

static inline void vl_api_nat_control_ping_t_endian (vl_api_nat_control_ping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat_control_ping_reply_t_endian (vl_api_nat_control_ping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->vpe_pid = clib_net_to_host_u32(a->vpe_pid);
}

static inline void vl_api_nat_show_config_t_endian (vl_api_nat_show_config_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat_show_config_reply_t_endian (vl_api_nat_show_config_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->static_mapping_only = a->static_mapping_only (no-op) */
    /* a->static_mapping_connection_tracking = a->static_mapping_connection_tracking (no-op) */
    /* a->deterministic = a->deterministic (no-op) */
    a->translation_buckets = clib_net_to_host_u32(a->translation_buckets);
    a->translation_memory_size = clib_net_to_host_u32(a->translation_memory_size);
    a->user_buckets = clib_net_to_host_u32(a->user_buckets);
    a->user_memory_size = clib_net_to_host_u32(a->user_memory_size);
    a->max_translations_per_user = clib_net_to_host_u32(a->max_translations_per_user);
    a->outside_vrf_id = clib_net_to_host_u32(a->outside_vrf_id);
    a->inside_vrf_id = clib_net_to_host_u32(a->inside_vrf_id);
}

static inline void vl_api_nat_set_workers_t_endian (vl_api_nat_set_workers_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->worker_mask = clib_net_to_host_u64(a->worker_mask);
}

static inline void vl_api_nat_set_workers_reply_t_endian (vl_api_nat_set_workers_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat_worker_dump_t_endian (vl_api_nat_worker_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat_worker_details_t_endian (vl_api_nat_worker_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->worker_index = clib_net_to_host_u32(a->worker_index);
    a->lcore_id = clib_net_to_host_u32(a->lcore_id);
    /* a->name[0..63] = a->name[0..63] (no-op) */
}

static inline void vl_api_nat_ipfix_enable_disable_t_endian (vl_api_nat_ipfix_enable_disable_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->domain_id = clib_net_to_host_u32(a->domain_id);
    a->src_port = clib_net_to_host_u16(a->src_port);
    /* a->enable = a->enable (no-op) */
}

static inline void vl_api_nat_ipfix_enable_disable_reply_t_endian (vl_api_nat_ipfix_enable_disable_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_add_del_address_range_t_endian (vl_api_nat44_add_del_address_range_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->first_ip_address[0..3] = a->first_ip_address[0..3] (no-op) */
    /* a->last_ip_address[0..3] = a->last_ip_address[0..3] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_nat44_add_del_address_range_reply_t_endian (vl_api_nat44_add_del_address_range_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_address_dump_t_endian (vl_api_nat44_address_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_address_details_t_endian (vl_api_nat44_address_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->ip_address[0..3] = a->ip_address[0..3] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_nat44_interface_add_del_feature_t_endian (vl_api_nat44_interface_add_del_feature_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_interface_add_del_feature_reply_t_endian (vl_api_nat44_interface_add_del_feature_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_interface_dump_t_endian (vl_api_nat44_interface_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_interface_details_t_endian (vl_api_nat44_interface_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_interface_add_del_output_feature_t_endian (vl_api_nat44_interface_add_del_output_feature_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_interface_add_del_output_feature_reply_t_endian (vl_api_nat44_interface_add_del_output_feature_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_interface_output_feature_dump_t_endian (vl_api_nat44_interface_output_feature_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_interface_output_feature_details_t_endian (vl_api_nat44_interface_output_feature_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_add_del_static_mapping_t_endian (vl_api_nat44_add_del_static_mapping_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->addr_only = a->addr_only (no-op) */
    /* a->local_ip_address[0..3] = a->local_ip_address[0..3] (no-op) */
    /* a->external_ip_address[0..3] = a->external_ip_address[0..3] (no-op) */
    /* a->protocol = a->protocol (no-op) */
    a->local_port = clib_net_to_host_u16(a->local_port);
    a->external_port = clib_net_to_host_u16(a->external_port);
    a->external_sw_if_index = clib_net_to_host_u32(a->external_sw_if_index);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_nat44_add_del_static_mapping_reply_t_endian (vl_api_nat44_add_del_static_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_static_mapping_dump_t_endian (vl_api_nat44_static_mapping_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_static_mapping_details_t_endian (vl_api_nat44_static_mapping_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->addr_only = a->addr_only (no-op) */
    /* a->local_ip_address[0..3] = a->local_ip_address[0..3] (no-op) */
    /* a->external_ip_address[0..3] = a->external_ip_address[0..3] (no-op) */
    /* a->protocol = a->protocol (no-op) */
    a->local_port = clib_net_to_host_u16(a->local_port);
    a->external_port = clib_net_to_host_u16(a->external_port);
    a->external_sw_if_index = clib_net_to_host_u32(a->external_sw_if_index);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_nat44_add_del_interface_addr_t_endian (vl_api_nat44_add_del_interface_addr_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_add_del_interface_addr_reply_t_endian (vl_api_nat44_add_del_interface_addr_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_interface_addr_dump_t_endian (vl_api_nat44_interface_addr_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_interface_addr_details_t_endian (vl_api_nat44_interface_addr_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat44_user_dump_t_endian (vl_api_nat44_user_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat44_user_details_t_endian (vl_api_nat44_user_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->ip_address[0..3] = a->ip_address[0..3] (no-op) */
    a->nsessions = clib_net_to_host_u32(a->nsessions);
    a->nstaticsessions = clib_net_to_host_u32(a->nstaticsessions);
}

static inline void vl_api_nat44_user_session_dump_t_endian (vl_api_nat44_user_session_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->ip_address[0..3] = a->ip_address[0..3] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_nat44_user_session_details_t_endian (vl_api_nat44_user_session_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->outside_ip_address[0..3] = a->outside_ip_address[0..3] (no-op) */
    a->outside_port = clib_net_to_host_u16(a->outside_port);
    /* a->inside_ip_address[0..3] = a->inside_ip_address[0..3] (no-op) */
    a->inside_port = clib_net_to_host_u16(a->inside_port);
    a->protocol = clib_net_to_host_u16(a->protocol);
    /* a->is_static = a->is_static (no-op) */
    a->last_heard = clib_net_to_host_u64(a->last_heard);
    a->total_bytes = clib_net_to_host_u64(a->total_bytes);
    a->total_pkts = clib_net_to_host_u32(a->total_pkts);
}

/***** manual: vl_api_nat44_lb_addr_port_t_endian  *****/

/***** manual: vl_api_nat44_add_del_lb_static_mapping_t_endian  *****/

static inline void vl_api_nat44_add_del_lb_static_mapping_reply_t_endian (vl_api_nat44_add_del_lb_static_mapping_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat44_lb_static_mapping_dump_t_endian (vl_api_nat44_lb_static_mapping_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

/***** manual: vl_api_nat44_lb_static_mapping_details_t_endian  *****/

static inline void vl_api_nat_det_add_del_map_t_endian (vl_api_nat_det_add_del_map_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->addr_only = a->addr_only (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    /* a->in_plen = a->in_plen (no-op) */
    /* a->out_addr[0..3] = a->out_addr[0..3] (no-op) */
    /* a->out_plen = a->out_plen (no-op) */
}

static inline void vl_api_nat_det_add_del_map_reply_t_endian (vl_api_nat_det_add_del_map_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat_det_forward_t_endian (vl_api_nat_det_forward_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
}

static inline void vl_api_nat_det_forward_reply_t_endian (vl_api_nat_det_forward_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->out_port_lo = clib_net_to_host_u16(a->out_port_lo);
    a->out_port_hi = clib_net_to_host_u16(a->out_port_hi);
    /* a->out_addr[0..3] = a->out_addr[0..3] (no-op) */
}

static inline void vl_api_nat_det_reverse_t_endian (vl_api_nat_det_reverse_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->out_addr[0..3] = a->out_addr[0..3] (no-op) */
}

static inline void vl_api_nat_det_reverse_reply_t_endian (vl_api_nat_det_reverse_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
}

static inline void vl_api_nat_det_map_dump_t_endian (vl_api_nat_det_map_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat_det_map_details_t_endian (vl_api_nat_det_map_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    /* a->in_plen = a->in_plen (no-op) */
    /* a->out_addr[0..3] = a->out_addr[0..3] (no-op) */
    /* a->out_plen = a->out_plen (no-op) */
    a->sharing_ratio = clib_net_to_host_u32(a->sharing_ratio);
    a->ports_per_host = clib_net_to_host_u16(a->ports_per_host);
    a->ses_num = clib_net_to_host_u32(a->ses_num);
}

static inline void vl_api_nat_det_set_timeouts_t_endian (vl_api_nat_det_set_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->udp = clib_net_to_host_u32(a->udp);
    a->tcp_established = clib_net_to_host_u32(a->tcp_established);
    a->tcp_transitory = clib_net_to_host_u32(a->tcp_transitory);
    a->icmp = clib_net_to_host_u32(a->icmp);
}

static inline void vl_api_nat_det_set_timeouts_reply_t_endian (vl_api_nat_det_set_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat_det_get_timeouts_t_endian (vl_api_nat_det_get_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat_det_get_timeouts_reply_t_endian (vl_api_nat_det_get_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->udp = clib_net_to_host_u32(a->udp);
    a->tcp_established = clib_net_to_host_u32(a->tcp_established);
    a->tcp_transitory = clib_net_to_host_u32(a->tcp_transitory);
    a->icmp = clib_net_to_host_u32(a->icmp);
}

static inline void vl_api_nat_det_close_session_out_t_endian (vl_api_nat_det_close_session_out_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->out_addr[0..3] = a->out_addr[0..3] (no-op) */
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->ext_addr[0..3] = a->ext_addr[0..3] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
}

static inline void vl_api_nat_det_close_session_out_reply_t_endian (vl_api_nat_det_close_session_out_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat_det_close_session_in_t_endian (vl_api_nat_det_close_session_in_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->in_addr[0..15] = a->in_addr[0..15] (no-op) */
    a->in_port = clib_net_to_host_u16(a->in_port);
    /* a->ext_addr[0..15] = a->ext_addr[0..15] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
}

static inline void vl_api_nat_det_close_session_in_reply_t_endian (vl_api_nat_det_close_session_in_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat_det_session_dump_t_endian (vl_api_nat_det_session_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_nat44 = a->is_nat44 (no-op) */
    /* a->user_addr[0..15] = a->user_addr[0..15] (no-op) */
}

static inline void vl_api_nat_det_session_details_t_endian (vl_api_nat_det_session_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->in_port = clib_net_to_host_u16(a->in_port);
    /* a->ext_addr[0..3] = a->ext_addr[0..3] (no-op) */
    a->ext_port = clib_net_to_host_u16(a->ext_port);
    a->out_port = clib_net_to_host_u16(a->out_port);
    /* a->state = a->state (no-op) */
    a->expire = clib_net_to_host_u32(a->expire);
}

static inline void vl_api_nat64_add_del_pool_addr_range_t_endian (vl_api_nat64_add_del_pool_addr_range_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->start_addr[0..3] = a->start_addr[0..3] (no-op) */
    /* a->end_addr[0..3] = a->end_addr[0..3] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_nat64_add_del_pool_addr_range_reply_t_endian (vl_api_nat64_add_del_pool_addr_range_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat64_pool_addr_dump_t_endian (vl_api_nat64_pool_addr_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat64_pool_addr_details_t_endian (vl_api_nat64_pool_addr_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->address[0..3] = a->address[0..3] (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_nat64_add_del_interface_t_endian (vl_api_nat64_add_del_interface_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_inside = a->is_inside (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_nat64_add_del_interface_reply_t_endian (vl_api_nat64_add_del_interface_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat64_interface_dump_t_endian (vl_api_nat64_interface_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat64_interface_details_t_endian (vl_api_nat64_interface_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_inside = a->is_inside (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_nat64_add_del_static_bib_t_endian (vl_api_nat64_add_del_static_bib_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->i_addr[0..15] = a->i_addr[0..15] (no-op) */
    /* a->o_addr[0..3] = a->o_addr[0..3] (no-op) */
    a->i_port = clib_net_to_host_u16(a->i_port);
    a->o_port = clib_net_to_host_u16(a->o_port);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->proto = a->proto (no-op) */
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_nat64_add_del_static_bib_reply_t_endian (vl_api_nat64_add_del_static_bib_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat64_bib_dump_t_endian (vl_api_nat64_bib_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->proto = a->proto (no-op) */
}

static inline void vl_api_nat64_bib_details_t_endian (vl_api_nat64_bib_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->i_addr[0..15] = a->i_addr[0..15] (no-op) */
    /* a->o_addr[0..3] = a->o_addr[0..3] (no-op) */
    a->i_port = clib_net_to_host_u16(a->i_port);
    a->o_port = clib_net_to_host_u16(a->o_port);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->proto = a->proto (no-op) */
    /* a->is_static = a->is_static (no-op) */
    a->ses_num = clib_net_to_host_u32(a->ses_num);
}

static inline void vl_api_nat64_set_timeouts_t_endian (vl_api_nat64_set_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->udp = clib_net_to_host_u32(a->udp);
    a->icmp = clib_net_to_host_u32(a->icmp);
    a->tcp_trans = clib_net_to_host_u32(a->tcp_trans);
    a->tcp_est = clib_net_to_host_u32(a->tcp_est);
    a->tcp_incoming_syn = clib_net_to_host_u32(a->tcp_incoming_syn);
}

static inline void vl_api_nat64_set_timeouts_reply_t_endian (vl_api_nat64_set_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat64_get_timeouts_t_endian (vl_api_nat64_get_timeouts_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat64_get_timeouts_reply_t_endian (vl_api_nat64_get_timeouts_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->udp = clib_net_to_host_u32(a->udp);
    a->icmp = clib_net_to_host_u32(a->icmp);
    a->tcp_trans = clib_net_to_host_u32(a->tcp_trans);
    a->tcp_est = clib_net_to_host_u32(a->tcp_est);
    a->tcp_incoming_syn = clib_net_to_host_u32(a->tcp_incoming_syn);
}

static inline void vl_api_nat64_st_dump_t_endian (vl_api_nat64_st_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->proto = a->proto (no-op) */
}

static inline void vl_api_nat64_st_details_t_endian (vl_api_nat64_st_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->il_addr[0..15] = a->il_addr[0..15] (no-op) */
    /* a->ol_addr[0..3] = a->ol_addr[0..3] (no-op) */
    a->il_port = clib_net_to_host_u16(a->il_port);
    a->ol_port = clib_net_to_host_u16(a->ol_port);
    /* a->ir_addr[0..15] = a->ir_addr[0..15] (no-op) */
    /* a->or_addr[0..3] = a->or_addr[0..3] (no-op) */
    a->r_port = clib_net_to_host_u16(a->r_port);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->proto = a->proto (no-op) */
}

static inline void vl_api_nat64_add_del_prefix_t_endian (vl_api_nat64_add_del_prefix_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->prefix[0..15] = a->prefix[0..15] (no-op) */
    /* a->prefix_len = a->prefix_len (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_nat64_add_del_prefix_reply_t_endian (vl_api_nat64_add_del_prefix_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_nat64_prefix_dump_t_endian (vl_api_nat64_prefix_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_nat64_prefix_details_t_endian (vl_api_nat64_prefix_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    /* a->prefix[0..15] = a->prefix[0..15] (no-op) */
    /* a->prefix_len = a->prefix_len (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(nat.api, 0x2bfabde2)

#endif

