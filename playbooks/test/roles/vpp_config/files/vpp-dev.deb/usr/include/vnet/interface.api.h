/*
 * VLIB API definitions Wed Nov 15 17:02:21 2017
 * Input file: vnet/interface.api.h
 * Automatically generated: please edit the input file NOT this file!
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)||defined(vl_msg_name_crc_list)
/* ok, something was selected */
#else
#warning no content included from vnet/interface.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_SW_INTERFACE_SET_FLAGS, vl_api_sw_interface_set_flags_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_FLAGS_REPLY, vl_api_sw_interface_set_flags_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MTU, vl_api_sw_interface_set_mtu_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MTU_REPLY, vl_api_sw_interface_set_mtu_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_EVENT, vl_api_sw_interface_event_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_EVENTS, vl_api_want_interface_events_t_handler)
vl_msg_id(VL_API_WANT_INTERFACE_EVENTS_REPLY, vl_api_want_interface_events_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_DETAILS, vl_api_sw_interface_details_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_DUMP, vl_api_sw_interface_dump_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_ADD_DEL_ADDRESS, vl_api_sw_interface_add_del_address_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_ADD_DEL_ADDRESS_REPLY, vl_api_sw_interface_add_del_address_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_TABLE, vl_api_sw_interface_set_table_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_TABLE_REPLY, vl_api_sw_interface_set_table_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_GET_TABLE, vl_api_sw_interface_get_table_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_GET_TABLE_REPLY, vl_api_sw_interface_get_table_reply_t_handler)
/* typeonly: vlib_counter */
/* typeonly: vnet_combined_counter */
/* typeonly: vnet_simple_counter */
vl_msg_id(VL_API_VNET_INTERFACE_SIMPLE_COUNTERS, vl_api_vnet_interface_simple_counters_t_handler)
vl_msg_id(VL_API_VNET_INTERFACE_COMBINED_COUNTERS, vl_api_vnet_interface_combined_counters_t_handler)
vl_msg_id(VL_API_VNET_PER_INTERFACE_SIMPLE_COUNTERS, vl_api_vnet_per_interface_simple_counters_t_handler)
vl_msg_id(VL_API_VNET_PER_INTERFACE_COMBINED_COUNTERS, vl_api_vnet_per_interface_combined_counters_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_UNNUMBERED, vl_api_sw_interface_set_unnumbered_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_UNNUMBERED_REPLY, vl_api_sw_interface_set_unnumbered_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_CLEAR_STATS, vl_api_sw_interface_clear_stats_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_CLEAR_STATS_REPLY, vl_api_sw_interface_clear_stats_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAG_ADD_DEL, vl_api_sw_interface_tag_add_del_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_TAG_ADD_DEL_REPLY, vl_api_sw_interface_tag_add_del_reply_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MAC_ADDRESS, vl_api_sw_interface_set_mac_address_t_handler)
vl_msg_id(VL_API_SW_INTERFACE_SET_MAC_ADDRESS_REPLY, vl_api_sw_interface_set_mac_address_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_sw_interface_set_flags_t, 1)
vl_msg_name(vl_api_sw_interface_set_flags_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_mtu_t, 1)
vl_msg_name(vl_api_sw_interface_set_mtu_reply_t, 1)
vl_msg_name(vl_api_sw_interface_event_t, 1)
vl_msg_name(vl_api_want_interface_events_t, 1)
vl_msg_name(vl_api_want_interface_events_reply_t, 1)
vl_msg_name(vl_api_sw_interface_details_t, 1)
vl_msg_name(vl_api_sw_interface_dump_t, 1)
vl_msg_name(vl_api_sw_interface_add_del_address_t, 1)
vl_msg_name(vl_api_sw_interface_add_del_address_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_table_t, 1)
vl_msg_name(vl_api_sw_interface_set_table_reply_t, 1)
vl_msg_name(vl_api_sw_interface_get_table_t, 1)
vl_msg_name(vl_api_sw_interface_get_table_reply_t, 1)
/* typeonly: vlib_counter */
/* typeonly: vnet_combined_counter */
/* typeonly: vnet_simple_counter */
vl_msg_name(vl_api_vnet_interface_simple_counters_t, 1)
vl_msg_name(vl_api_vnet_interface_combined_counters_t, 1)
vl_msg_name(vl_api_vnet_per_interface_simple_counters_t, 1)
vl_msg_name(vl_api_vnet_per_interface_combined_counters_t, 1)
vl_msg_name(vl_api_sw_interface_set_unnumbered_t, 1)
vl_msg_name(vl_api_sw_interface_set_unnumbered_reply_t, 1)
vl_msg_name(vl_api_sw_interface_clear_stats_t, 1)
vl_msg_name(vl_api_sw_interface_clear_stats_reply_t, 1)
vl_msg_name(vl_api_sw_interface_tag_add_del_t, 1)
vl_msg_name(vl_api_sw_interface_tag_add_del_reply_t, 1)
vl_msg_name(vl_api_sw_interface_set_mac_address_t, 1)
vl_msg_name(vl_api_sw_interface_set_mac_address_reply_t, 1)
#endif


/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_interface \
_(VL_API_SW_INTERFACE_SET_FLAGS, sw_interface_set_flags, f890584a) \
_(VL_API_SW_INTERFACE_SET_FLAGS_REPLY, sw_interface_set_flags_reply, dfbf3afa) \
_(VL_API_SW_INTERFACE_SET_MTU, sw_interface_set_mtu, 535dab1d) \
_(VL_API_SW_INTERFACE_SET_MTU_REPLY, sw_interface_set_mtu_reply, 0cc22552) \
_(VL_API_SW_INTERFACE_EVENT, sw_interface_event, bf7f46f2) \
_(VL_API_WANT_INTERFACE_EVENTS, want_interface_events, a0cbf57e) \
_(VL_API_WANT_INTERFACE_EVENTS_REPLY, want_interface_events_reply, 33788c73) \
_(VL_API_SW_INTERFACE_DETAILS, sw_interface_details, e2d855bb) \
_(VL_API_SW_INTERFACE_DUMP, sw_interface_dump, 9a2f9d4d) \
_(VL_API_SW_INTERFACE_ADD_DEL_ADDRESS, sw_interface_add_del_address, 4e24d2df) \
_(VL_API_SW_INTERFACE_ADD_DEL_ADDRESS_REPLY, sw_interface_add_del_address_reply, abe29452) \
_(VL_API_SW_INTERFACE_SET_TABLE, sw_interface_set_table, a94df510) \
_(VL_API_SW_INTERFACE_SET_TABLE_REPLY, sw_interface_set_table_reply, 99df273c) \
_(VL_API_SW_INTERFACE_GET_TABLE, sw_interface_get_table, f5a1d557) \
_(VL_API_SW_INTERFACE_GET_TABLE_REPLY, sw_interface_get_table_reply, ab44111d) \
_(VL_API_VNET_INTERFACE_SIMPLE_COUNTERS, vnet_interface_simple_counters, 302f0983) \
_(VL_API_VNET_INTERFACE_COMBINED_COUNTERS, vnet_interface_combined_counters, d82426e3) \
_(VL_API_VNET_PER_INTERFACE_SIMPLE_COUNTERS, vnet_per_interface_simple_counters, 7df05633) \
_(VL_API_VNET_PER_INTERFACE_COMBINED_COUNTERS, vnet_per_interface_combined_counters, bf35dfbe) \
_(VL_API_SW_INTERFACE_SET_UNNUMBERED, sw_interface_set_unnumbered, ee0047b0) \
_(VL_API_SW_INTERFACE_SET_UNNUMBERED_REPLY, sw_interface_set_unnumbered_reply, 5b2275e1) \
_(VL_API_SW_INTERFACE_CLEAR_STATS, sw_interface_clear_stats, 9600fd50) \
_(VL_API_SW_INTERFACE_CLEAR_STATS_REPLY, sw_interface_clear_stats_reply, 21f50dd9) \
_(VL_API_SW_INTERFACE_TAG_ADD_DEL, sw_interface_tag_add_del, 50ae8d92) \
_(VL_API_SW_INTERFACE_TAG_ADD_DEL_REPLY, sw_interface_tag_add_del_reply, 761cbcb0) \
_(VL_API_SW_INTERFACE_SET_MAC_ADDRESS, sw_interface_set_mac_address, e4f22660) \
_(VL_API_SW_INTERFACE_SET_MAC_ADDRESS_REPLY, sw_interface_set_mac_address_reply, 9dc8a452) 
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_flags {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 admin_up_down;
}) vl_api_sw_interface_set_flags_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_flags_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_flags_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mtu {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u16 mtu;
}) vl_api_sw_interface_set_mtu_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mtu_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_mtu_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_event {
    u16 _vl_msg_id;
    u32 client_index;
    u32 pid;
    u32 sw_if_index;
    u8 admin_up_down;
    u8 link_up_down;
    u8 deleted;
}) vl_api_sw_interface_event_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_events {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 enable_disable;
    u32 pid;
}) vl_api_want_interface_events_t;

typedef VL_API_PACKED(struct _vl_api_want_interface_events_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_want_interface_events_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_details {
    u16 _vl_msg_id;
    u32 context;
    u32 sw_if_index;
    u32 sup_sw_if_index;
    u32 l2_address_length;
    u8 l2_address[8];
    u8 interface_name[64];
    u8 admin_up_down;
    u8 link_up_down;
    u8 link_duplex;
    u8 link_speed;
    u16 link_mtu;
    u32 sub_id;
    u8 sub_dot1ad;
    u8 sub_dot1ah;
    u8 sub_number_of_tags;
    u16 sub_outer_vlan_id;
    u16 sub_inner_vlan_id;
    u8 sub_exact_match;
    u8 sub_default;
    u8 sub_outer_vlan_id_any;
    u8 sub_inner_vlan_id_any;
    u32 vtr_op;
    u32 vtr_push_dot1q;
    u32 vtr_tag1;
    u32 vtr_tag2;
    u8 tag[64];
    u16 outer_tag;
    u8 b_dmac[6];
    u8 b_smac[6];
    u16 b_vlanid;
    u32 i_sid;
}) vl_api_sw_interface_details_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_dump {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name_filter_valid;
    u8 name_filter[49];
}) vl_api_sw_interface_dump_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_add_del_address {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_add;
    u8 is_ipv6;
    u8 del_all;
    u8 address_length;
    u8 address[16];
}) vl_api_sw_interface_add_del_address_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_add_del_address_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_add_del_address_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
    u32 vrf_id;
}) vl_api_sw_interface_set_table_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_table_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_get_table {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 is_ipv6;
}) vl_api_sw_interface_get_table_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_get_table_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
    u32 vrf_id;
}) vl_api_sw_interface_get_table_reply_t;

typedef VL_API_PACKED(struct _vl_api_vlib_counter {
    u64 packets;
    u64 bytes;
}) vl_api_vlib_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_combined_counter {
    u32 sw_if_index;
    u64 rx_packets;
    u64 rx_bytes;
    u64 tx_packets;
    u64 tx_bytes;
}) vl_api_vnet_combined_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_simple_counter {
    u32 sw_if_index;
    u64 drop;
    u64 punt;
    u64 rx_ip4;
    u64 rx_ip6;
    u64 rx_no_buffer;
    u64 rx_miss;
    u64 rx_error;
    u64 tx_error;
    u64 rx_mpls;
}) vl_api_vnet_simple_counter_t;

typedef VL_API_PACKED(struct _vl_api_vnet_interface_simple_counters {
    u16 _vl_msg_id;
    u8 vnet_counter_type;
    u32 first_sw_if_index;
    u32 count;
    u64 data[0];
}) vl_api_vnet_interface_simple_counters_t;

typedef VL_API_PACKED(struct _vl_api_vnet_interface_combined_counters {
    u16 _vl_msg_id;
    u8 vnet_counter_type;
    u32 first_sw_if_index;
    u32 count;
    vl_api_vlib_counter_t data[0];
}) vl_api_vnet_interface_combined_counters_t;

typedef VL_API_PACKED(struct _vl_api_vnet_per_interface_simple_counters {
    u16 _vl_msg_id;
    u32 count;
    u32 timestamp;
    vl_api_vnet_simple_counter_t data[0];
}) vl_api_vnet_per_interface_simple_counters_t;

typedef VL_API_PACKED(struct _vl_api_vnet_per_interface_combined_counters {
    u16 _vl_msg_id;
    u32 count;
    u32 timestamp;
    vl_api_vnet_combined_counter_t data[0];
}) vl_api_vnet_per_interface_combined_counters_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_unnumbered {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u32 unnumbered_sw_if_index;
    u8 is_add;
}) vl_api_sw_interface_set_unnumbered_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_unnumbered_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_unnumbered_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_clear_stats {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
}) vl_api_sw_interface_clear_stats_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_clear_stats_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_clear_stats_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_tag_add_del {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 is_add;
    u32 sw_if_index;
    u8 tag[64];
}) vl_api_sw_interface_tag_add_del_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_tag_add_del_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_tag_add_del_reply_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mac_address {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u32 sw_if_index;
    u8 mac_address[6];
}) vl_api_sw_interface_set_mac_address_t;

typedef VL_API_PACKED(struct _vl_api_sw_interface_set_mac_address_reply {
    u16 _vl_msg_id;
    u32 context;
    i32 retval;
}) vl_api_sw_interface_set_mac_address_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_sw_interface_set_flags_t_print (vl_api_sw_interface_set_flags_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_flags_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "admin_up_down: %u\n", (unsigned) a->admin_up_down);
    return handle;
}

static inline void *vl_api_sw_interface_set_flags_reply_t_print (vl_api_sw_interface_set_flags_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_flags_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_mtu_t_print (vl_api_sw_interface_set_mtu_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mtu_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "mtu: %u\n", (unsigned) a->mtu);
    return handle;
}

static inline void *vl_api_sw_interface_set_mtu_reply_t_print (vl_api_sw_interface_set_mtu_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mtu_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_event_t_print (vl_api_sw_interface_event_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_event_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "admin_up_down: %u\n", (unsigned) a->admin_up_down);
    vl_print(handle, "link_up_down: %u\n", (unsigned) a->link_up_down);
    vl_print(handle, "deleted: %u\n", (unsigned) a->deleted);
    return handle;
}

static inline void *vl_api_want_interface_events_t_print (vl_api_want_interface_events_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_events_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "enable_disable: %u\n", (unsigned) a->enable_disable);
    vl_print(handle, "pid: %u\n", (unsigned) a->pid);
    return handle;
}

static inline void *vl_api_want_interface_events_reply_t_print (vl_api_want_interface_events_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_want_interface_events_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_details_t_print (vl_api_sw_interface_details_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_details_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "sup_sw_if_index: %u\n", (unsigned) a->sup_sw_if_index);
    vl_print(handle, "l2_address_length: %u\n", (unsigned) a->l2_address_length);
    {
        int _i;
        for (_i = 0; _i < 8; _i++) {
            vl_print(handle, "l2_address[%d]: %u\n", _i, a->l2_address[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "interface_name[%d]: %u\n", _i, a->interface_name[_i]);
        }
    }
    vl_print(handle, "admin_up_down: %u\n", (unsigned) a->admin_up_down);
    vl_print(handle, "link_up_down: %u\n", (unsigned) a->link_up_down);
    vl_print(handle, "link_duplex: %u\n", (unsigned) a->link_duplex);
    vl_print(handle, "link_speed: %u\n", (unsigned) a->link_speed);
    vl_print(handle, "link_mtu: %u\n", (unsigned) a->link_mtu);
    vl_print(handle, "sub_id: %u\n", (unsigned) a->sub_id);
    vl_print(handle, "sub_dot1ad: %u\n", (unsigned) a->sub_dot1ad);
    vl_print(handle, "sub_dot1ah: %u\n", (unsigned) a->sub_dot1ah);
    vl_print(handle, "sub_number_of_tags: %u\n", (unsigned) a->sub_number_of_tags);
    vl_print(handle, "sub_outer_vlan_id: %u\n", (unsigned) a->sub_outer_vlan_id);
    vl_print(handle, "sub_inner_vlan_id: %u\n", (unsigned) a->sub_inner_vlan_id);
    vl_print(handle, "sub_exact_match: %u\n", (unsigned) a->sub_exact_match);
    vl_print(handle, "sub_default: %u\n", (unsigned) a->sub_default);
    vl_print(handle, "sub_outer_vlan_id_any: %u\n", (unsigned) a->sub_outer_vlan_id_any);
    vl_print(handle, "sub_inner_vlan_id_any: %u\n", (unsigned) a->sub_inner_vlan_id_any);
    vl_print(handle, "vtr_op: %u\n", (unsigned) a->vtr_op);
    vl_print(handle, "vtr_push_dot1q: %u\n", (unsigned) a->vtr_push_dot1q);
    vl_print(handle, "vtr_tag1: %u\n", (unsigned) a->vtr_tag1);
    vl_print(handle, "vtr_tag2: %u\n", (unsigned) a->vtr_tag2);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "tag[%d]: %u\n", _i, a->tag[_i]);
        }
    }
    vl_print(handle, "outer_tag: %u\n", (unsigned) a->outer_tag);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "b_dmac[%d]: %u\n", _i, a->b_dmac[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "b_smac[%d]: %u\n", _i, a->b_smac[_i]);
        }
    }
    vl_print(handle, "b_vlanid: %u\n", (unsigned) a->b_vlanid);
    vl_print(handle, "i_sid: %u\n", (unsigned) a->i_sid);
    return handle;
}

static inline void *vl_api_sw_interface_dump_t_print (vl_api_sw_interface_dump_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_dump_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "name_filter_valid: %u\n", (unsigned) a->name_filter_valid);
    {
        int _i;
        for (_i = 0; _i < 49; _i++) {
            vl_print(handle, "name_filter[%d]: %u\n", _i, a->name_filter[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sw_interface_add_del_address_t_print (vl_api_sw_interface_add_del_address_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_add_del_address_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "del_all: %u\n", (unsigned) a->del_all);
    vl_print(handle, "address_length: %u\n", (unsigned) a->address_length);
    {
        int _i;
        for (_i = 0; _i < 16; _i++) {
            vl_print(handle, "address[%d]: %u\n", _i, a->address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sw_interface_add_del_address_reply_t_print (vl_api_sw_interface_add_del_address_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_add_del_address_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_table_t_print (vl_api_sw_interface_set_table_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_table_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

static inline void *vl_api_sw_interface_set_table_reply_t_print (vl_api_sw_interface_set_table_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_table_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_get_table_t_print (vl_api_sw_interface_get_table_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_get_table_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "is_ipv6: %u\n", (unsigned) a->is_ipv6);
    return handle;
}

static inline void *vl_api_sw_interface_get_table_reply_t_print (vl_api_sw_interface_get_table_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_get_table_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "vrf_id: %u\n", (unsigned) a->vrf_id);
    return handle;
}

/***** manual: vl_api_vlib_counter_t_print  *****/

/***** manual: vl_api_vnet_combined_counter_t_print  *****/

/***** manual: vl_api_vnet_simple_counter_t_print  *****/

/***** manual: vl_api_vnet_interface_simple_counters_t_print  *****/

/***** manual: vl_api_vnet_interface_combined_counters_t_print  *****/

/***** manual: vl_api_vnet_per_interface_simple_counters_t_print  *****/

/***** manual: vl_api_vnet_per_interface_combined_counters_t_print  *****/

static inline void *vl_api_sw_interface_set_unnumbered_t_print (vl_api_sw_interface_set_unnumbered_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_unnumbered_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    vl_print(handle, "unnumbered_sw_if_index: %u\n", (unsigned) a->unnumbered_sw_if_index);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    return handle;
}

static inline void *vl_api_sw_interface_set_unnumbered_reply_t_print (vl_api_sw_interface_set_unnumbered_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_unnumbered_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_clear_stats_t_print (vl_api_sw_interface_clear_stats_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_clear_stats_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    return handle;
}

static inline void *vl_api_sw_interface_clear_stats_reply_t_print (vl_api_sw_interface_clear_stats_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_clear_stats_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_tag_add_del_t_print (vl_api_sw_interface_tag_add_del_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_tag_add_del_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "is_add: %u\n", (unsigned) a->is_add);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "tag[%d]: %u\n", _i, a->tag[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sw_interface_tag_add_del_reply_t_print (vl_api_sw_interface_tag_add_del_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_tag_add_del_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

static inline void *vl_api_sw_interface_set_mac_address_t_print (vl_api_sw_interface_set_mac_address_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mac_address_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "sw_if_index: %u\n", (unsigned) a->sw_if_index);
    {
        int _i;
        for (_i = 0; _i < 6; _i++) {
            vl_print(handle, "mac_address[%d]: %u\n", _i, a->mac_address[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_sw_interface_set_mac_address_reply_t_print (vl_api_sw_interface_set_mac_address_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_sw_interface_set_mac_address_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_sw_interface_set_flags_t_endian (vl_api_sw_interface_set_flags_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->admin_up_down = a->admin_up_down (no-op) */
}

static inline void vl_api_sw_interface_set_flags_reply_t_endian (vl_api_sw_interface_set_flags_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_mtu_t_endian (vl_api_sw_interface_set_mtu_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->mtu = clib_net_to_host_u16(a->mtu);
}

static inline void vl_api_sw_interface_set_mtu_reply_t_endian (vl_api_sw_interface_set_mtu_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_event_t_endian (vl_api_sw_interface_event_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->pid = clib_net_to_host_u32(a->pid);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->admin_up_down = a->admin_up_down (no-op) */
    /* a->link_up_down = a->link_up_down (no-op) */
    /* a->deleted = a->deleted (no-op) */
}

static inline void vl_api_want_interface_events_t_endian (vl_api_want_interface_events_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->enable_disable = clib_net_to_host_u32(a->enable_disable);
    a->pid = clib_net_to_host_u32(a->pid);
}

static inline void vl_api_want_interface_events_reply_t_endian (vl_api_want_interface_events_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_details_t_endian (vl_api_sw_interface_details_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->sup_sw_if_index = clib_net_to_host_u32(a->sup_sw_if_index);
    a->l2_address_length = clib_net_to_host_u32(a->l2_address_length);
    /* a->l2_address[0..7] = a->l2_address[0..7] (no-op) */
    /* a->interface_name[0..63] = a->interface_name[0..63] (no-op) */
    /* a->admin_up_down = a->admin_up_down (no-op) */
    /* a->link_up_down = a->link_up_down (no-op) */
    /* a->link_duplex = a->link_duplex (no-op) */
    /* a->link_speed = a->link_speed (no-op) */
    a->link_mtu = clib_net_to_host_u16(a->link_mtu);
    a->sub_id = clib_net_to_host_u32(a->sub_id);
    /* a->sub_dot1ad = a->sub_dot1ad (no-op) */
    /* a->sub_dot1ah = a->sub_dot1ah (no-op) */
    /* a->sub_number_of_tags = a->sub_number_of_tags (no-op) */
    a->sub_outer_vlan_id = clib_net_to_host_u16(a->sub_outer_vlan_id);
    a->sub_inner_vlan_id = clib_net_to_host_u16(a->sub_inner_vlan_id);
    /* a->sub_exact_match = a->sub_exact_match (no-op) */
    /* a->sub_default = a->sub_default (no-op) */
    /* a->sub_outer_vlan_id_any = a->sub_outer_vlan_id_any (no-op) */
    /* a->sub_inner_vlan_id_any = a->sub_inner_vlan_id_any (no-op) */
    a->vtr_op = clib_net_to_host_u32(a->vtr_op);
    a->vtr_push_dot1q = clib_net_to_host_u32(a->vtr_push_dot1q);
    a->vtr_tag1 = clib_net_to_host_u32(a->vtr_tag1);
    a->vtr_tag2 = clib_net_to_host_u32(a->vtr_tag2);
    /* a->tag[0..63] = a->tag[0..63] (no-op) */
    a->outer_tag = clib_net_to_host_u16(a->outer_tag);
    /* a->b_dmac[0..5] = a->b_dmac[0..5] (no-op) */
    /* a->b_smac[0..5] = a->b_smac[0..5] (no-op) */
    a->b_vlanid = clib_net_to_host_u16(a->b_vlanid);
    a->i_sid = clib_net_to_host_u32(a->i_sid);
}

static inline void vl_api_sw_interface_dump_t_endian (vl_api_sw_interface_dump_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->name_filter_valid = a->name_filter_valid (no-op) */
    /* a->name_filter[0..48] = a->name_filter[0..48] (no-op) */
}

static inline void vl_api_sw_interface_add_del_address_t_endian (vl_api_sw_interface_add_del_address_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_add = a->is_add (no-op) */
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    /* a->del_all = a->del_all (no-op) */
    /* a->address_length = a->address_length (no-op) */
    /* a->address[0..15] = a->address[0..15] (no-op) */
}

static inline void vl_api_sw_interface_add_del_address_reply_t_endian (vl_api_sw_interface_add_del_address_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_table_t_endian (vl_api_sw_interface_set_table_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

static inline void vl_api_sw_interface_set_table_reply_t_endian (vl_api_sw_interface_set_table_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_get_table_t_endian (vl_api_sw_interface_get_table_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->is_ipv6 = a->is_ipv6 (no-op) */
}

static inline void vl_api_sw_interface_get_table_reply_t_endian (vl_api_sw_interface_get_table_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->vrf_id = clib_net_to_host_u32(a->vrf_id);
}

/***** manual: vl_api_vlib_counter_t_endian  *****/

/***** manual: vl_api_vnet_combined_counter_t_endian  *****/

/***** manual: vl_api_vnet_simple_counter_t_endian  *****/

/***** manual: vl_api_vnet_interface_simple_counters_t_endian  *****/

/***** manual: vl_api_vnet_interface_combined_counters_t_endian  *****/

/***** manual: vl_api_vnet_per_interface_simple_counters_t_endian  *****/

/***** manual: vl_api_vnet_per_interface_combined_counters_t_endian  *****/

static inline void vl_api_sw_interface_set_unnumbered_t_endian (vl_api_sw_interface_set_unnumbered_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    a->unnumbered_sw_if_index = clib_net_to_host_u32(a->unnumbered_sw_if_index);
    /* a->is_add = a->is_add (no-op) */
}

static inline void vl_api_sw_interface_set_unnumbered_reply_t_endian (vl_api_sw_interface_set_unnumbered_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_clear_stats_t_endian (vl_api_sw_interface_clear_stats_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
}

static inline void vl_api_sw_interface_clear_stats_reply_t_endian (vl_api_sw_interface_clear_stats_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_tag_add_del_t_endian (vl_api_sw_interface_tag_add_del_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    /* a->is_add = a->is_add (no-op) */
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->tag[0..63] = a->tag[0..63] (no-op) */
}

static inline void vl_api_sw_interface_tag_add_del_reply_t_endian (vl_api_sw_interface_tag_add_del_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

static inline void vl_api_sw_interface_set_mac_address_t_endian (vl_api_sw_interface_set_mac_address_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->sw_if_index = clib_net_to_host_u32(a->sw_if_index);
    /* a->mac_address[0..5] = a->mac_address[0..5] (no-op) */
}

static inline void vl_api_sw_interface_set_mac_address_reply_t_endian (vl_api_sw_interface_set_mac_address_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(interface.api, 0x89847d0a)

#endif

